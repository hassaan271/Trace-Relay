import type { Metadata, Viewport } from "next"
import "@fontsource-variable/inter"
import "@fontsource-variable/space-grotesk"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import { MotionProvider } from "@/components/motion-provider"

export const metadata: Metadata = {
  title: "TRACE RELAY",
  description: "Healthcare records, follow-ups, and clinical continuity in one place.",
  icons: {
    icon: [
      { url: "/icon-light-32x32.png", media: "(prefers-color-scheme: light)" },
      { url: "/icon-dark-32x32.png", media: "(prefers-color-scheme: dark)" },
      { url: "/icon.svg", type: "image/svg+xml" },
    ],
    apple: "/apple-icon.png",
  },
}

export const viewport: Viewport = {
  themeColor: "#05080d",
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="motion" suppressHydrationWarning>
      <body>
        {/* One theme source for login, intro and dashboards: class on <html>, dark by default. */}
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem={false} storageKey="trace-relay-theme" disableTransitionOnChange>
          <MotionProvider />
          {children}
        </ThemeProvider>
      </body>
    </html>
  )
}
