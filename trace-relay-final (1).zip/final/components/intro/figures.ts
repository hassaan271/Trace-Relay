import * as THREE from "three"
import { RoundedBoxGeometry } from "three/examples/jsm/geometries/RoundedBoxGeometry.js"

/**
 * TRACE RELAY intro: people + equipment.
 *
 * Everything here is built from the same ingredients as the rest of the scene
 * (glass-ish solids, hairline cyan edges, soft glows) so it keeps the UI's
 * language, but people now have a real anatomy: tapered torso, neck, head with
 * eyes / brows / nose / ears / hair, jointed arms with a two-bone reach solver,
 * legs, shoes, and role-specific clothing and props.
 *
 *   doctor  : white lab coat, glasses, stethoscope, tablet, pointing arm
 *   patient : hoodie, backpack, wristband, phone (standing) or lying on the CT bed
 *   tech    : teal scrubs, ID lanyard, cap + mask, working the console
 *
 * Equipment: extruded CT gantry with a real bore, live display, spinning tube
 * + fan beam, motorised table with pedestal; control console with two monitors;
 * doctor's desk with lamp, mug, folders, plant; instrument cart; padlock.
 */

export type Kit = {
  dark: boolean
  cyan: THREE.Color
  ink: THREE.Color
  blue: THREE.Color
  bg: THREE.Color
  text: string
  paper: string
  glass: THREE.Material
  glassSolid: THREE.Material
  lineMat: THREE.LineBasicMaterial
  glowSolid: THREE.MeshBasicMaterial
  glowSoft: THREE.MeshBasicMaterial
  glowBlend: THREE.Blending
  track: <T extends { dispose(): void }>(o: T) => T
  edges: (m: THREE.Mesh, angle?: number) => THREE.Mesh
  panel: (w: number, h: number, d: number, mat?: THREE.Material, r?: number) => THREE.Mesh
  makeHalo: (size: number, color: THREE.Color, opacity: number) => THREE.Sprite
  mkTex: (c: HTMLCanvasElement) => THREE.CanvasTexture
  css: (c: THREE.Color) => string
}

const clampN = (x: number, a: number, b: number) => Math.min(b, Math.max(a, x))

/* ═══════════════════════════ humans ═══════════════════════════ */

export type Role = "doctor" | "patient" | "tech"

export type Human = {
  g: THREE.Group
  core: THREE.Sprite
  head: THREE.Group
  torso: THREE.Group
  /** +x and -x arms (local to the figure) */
  shP: THREE.Group
  elP: THREE.Group
  shN: THREE.Group
  elN: THREE.Group
  handP: THREE.Group
  handN: THREE.Group
  eyes: THREE.Group[]
  headPos: THREE.Vector3
  props: { phone?: THREE.Group; tablet?: THREE.Group; band?: THREE.Mesh }
  seed: number
}

const DOWN = new THREE.Vector3(0, -1, 0)
const _n = new THREE.Vector3(), _p = new THREE.Vector3(), _u = new THREE.Vector3(), _a = new THREE.Vector3(), _v = new THREE.Vector3()
const _qs = new THREE.Quaternion(), _qe = new THREE.Quaternion(), _qi = new THREE.Quaternion()
const L1 = 0.6
const L2 = 0.62

const PALETTE = {
  doctor: { top: ["#d6ebf4", "#ffffff"], legs: ["#16384a", "#2d5870"], shoe: ["#0c1a22", "#16242d"], hair: "#1d2a33", skin: "#cf9a80" },
  patient: { top: ["#2b7fd8", "#3d8fe6"], legs: ["#1b3b66", "#31598f"], shoe: ["#d8e8f0", "#f4f9fb"], hair: "#4a2c1c", skin: "#e6bca4" },
  tech: { top: ["#10a9be", "#14b1c6"], legs: ["#0d7f92", "#0f8da1"], shoe: ["#e8f2f6", "#ffffff"], hair: "#232a30", skin: "#9a6a52" },
} as const

export function buildHuman(k: Kit, role: Role, opts: { lying?: boolean; seed?: number } = {}): Human {
  const { dark, track, ink, cyan, glowSolid, lineMat } = k
  const pal = PALETTE[role]
  const di = dark ? 0 : 1
  const g = new THREE.Group()
  const std = (c: string | THREE.Color, rough = 0.6, metal = 0.04) =>
    track(new THREE.MeshStandardMaterial({ color: c, roughness: rough, metalness: metal }))
  const skin = std(pal.skin, 0.62, 0)
  const topMat = std(pal.top[di], role === "doctor" ? 0.5 : 0.7)
  const legMat = std(pal.legs[di], 0.75)
  const shoeMat = std(pal.shoe[di], 0.5)
  const hairMat = std(pal.hair, 0.8)
  const darkMat = std("#0d1a22", 0.5)
  const hull = track(new THREE.MeshBasicMaterial({ color: ink, transparent: true, opacity: dark ? 0.5 : 0.36, side: THREE.BackSide, depthWrite: false }))

  const inflate = (geo: THREE.BufferGeometry, d: number) => {
    const c = geo.clone()
    const p = c.attributes.position as THREE.BufferAttribute
    const n = c.attributes.normal as THREE.BufferAttribute
    for (let i = 0; i < p.count; i++) p.setXYZ(i, p.getX(i) + n.getX(i) * d, p.getY(i) + n.getY(i) * d, p.getZ(i) + n.getZ(i) * d)
    return track(c)
  }
  /** solid mesh with a thin cyan contour (inverted hull) */
  const part = (geo: THREE.BufferGeometry, mat: THREE.Material, outline = 0.02) => {
    track(geo)
    const m = new THREE.Mesh(geo, mat)
    if (outline > 0) m.add(new THREE.Mesh(inflate(geo, outline), hull))
    return m
  }
  const lathe = (pts: number[][], mat: THREE.Material, zScale: number, outline = 0.02) => {
    const m = part(new THREE.LatheGeometry(pts.map(([r, y]) => new THREE.Vector2(r, y)), 40), mat, outline)
    m.scale.z = zScale
    return m
  }
  const limb = (len: number, r: number, mat: THREE.Material, sz = 1) => {
    const m = part(new THREE.CapsuleGeometry(r, len, 4, 14), mat)
    m.position.y = -len / 2
    m.scale.z = sz
    return m
  }
  const sphere = (r: number, mat: THREE.Material, sx = 1, sy = 1, sz = 1, outline = 0) => {
    const m = part(new THREE.SphereGeometry(r, 20, 14), mat, outline)
    m.scale.set(sx, sy, sz)
    return m
  }
  const radiusAt = (pts: number[][], y: number) => {
    for (let i = 0; i < pts.length - 1; i++) {
      const [r0, y0] = pts[i], [r1, y1] = pts[i + 1]
      if (y >= y0 && y <= y1) return r0 + ((y - y0) / (y1 - y0 || 1)) * (r1 - r0)
    }
    return pts[pts.length - 1][0]
  }

  /* ── legs ── */
  const leg = (side: 1 | -1) => {
    const hip = new THREE.Group(); hip.position.set(side * 0.2, 1.45, 0)
    hip.add(limb(0.72, 0.175, legMat))
    const knee = new THREE.Group(); knee.position.y = -0.72
    knee.add(limb(0.62, 0.135, legMat))
    const foot = part(new THREE.CapsuleGeometry(0.1, 0.24, 4, 10), shoeMat, 0.016)
    foot.rotation.x = Math.PI / 2; foot.scale.set(1.12, 1, 1); foot.position.set(0, -0.63, 0.1)
    knee.add(foot)
    hip.add(knee)
    return hip
  }
  g.add(leg(1), leg(-1))
  const pelvis = sphere(0.3, legMat, 1, 0.72, 0.78, 0.016); pelvis.position.y = 1.5
  g.add(pelvis)

  /* ── torso + clothing ── */
  const torso = new THREE.Group(); torso.position.y = 1.5; g.add(torso)
  const body = [[0.02, 0], [0.25, 0], [0.29, 0.2], [0.33, 0.5], [0.355, 0.78], [0.34, 0.95], [0.26, 1.04], [0.15, 1.09], [0.1, 1.1]]
  let torsoZ = 0.72
  if (role === "doctor") {
    const coat = [[0.02, -0.95], [0.47, -0.95], [0.45, -0.6], [0.39, -0.2], [0.33, 0.2], [0.35, 0.5], [0.375, 0.78], [0.36, 0.95], [0.28, 1.04], [0.17, 1.09], [0.14, 1.1]]
    torsoZ = 0.74
    // shirt under the coat, coat over it
    const shirt = lathe(body, std(dark ? "#7fd0e0" : "#bfe9f2", 0.6), 0.7, 0)
    torso.add(shirt)
    torso.add(lathe(coat, topMat, torsoZ))
    // centre seam + lapels + buttons
    const seam: THREE.Vector3[] = []
    for (let y = -0.9; y <= 0.62; y += 0.1) seam.push(new THREE.Vector3(0, y, radiusAt(coat, y) * torsoZ + 0.004))
    torso.add(new THREE.Line(track(new THREE.BufferGeometry().setFromPoints(seam)), lineMat))
    for (const s of [1, -1]) {
      const pts = [new THREE.Vector3(s * 0.13, 1.06, 0.15), new THREE.Vector3(s * 0.1, 0.84, 0.235), new THREE.Vector3(0, 0.6, radiusAt(coat, 0.6) * torsoZ + 0.004)]
      torso.add(new THREE.Line(track(new THREE.BufferGeometry().setFromPoints(pts)), lineMat))
      // collar
      const col = new THREE.Mesh(track(new RoundedBoxGeometry(0.17, 0.13, 0.04, 2, 0.015)), topMat)
      col.position.set(s * 0.1, 1.07, 0.13); col.rotation.set(0.35, -s * 0.55, -s * 0.55)
      k.edges(col, 40)
      torso.add(col)
    }
    // chest pocket + badge
    const pk = new THREE.LineLoop(track(new THREE.BufferGeometry().setFromPoints([
      new THREE.Vector3(0, 0, 0), new THREE.Vector3(0.2, 0, 0), new THREE.Vector3(0.2, -0.18, 0), new THREE.Vector3(0, -0.18, 0),
    ])), lineMat)
    pk.position.set(-0.3, 0.8, 0.205); pk.rotation.y = -0.55
    torso.add(pk)
    const badge = new THREE.Group(); badge.position.set(0.21, 0.76, 0.232); badge.rotation.y = 0.5
    badge.add(new THREE.Mesh(track(new THREE.BoxGeometry(0.04, 0.14, 0.012)), glowSolid), new THREE.Mesh(track(new THREE.BoxGeometry(0.14, 0.04, 0.012)), glowSolid))
    torso.add(badge)
    // stethoscope
    const steth = new THREE.Group()
    const metal = std(dark ? "#9fb7c4" : "#6c8796", 0.3, 0.7)
    const neckRing = part(new THREE.TorusGeometry(0.205, 0.02, 8, 36), darkMat, 0)
    neckRing.rotation.x = Math.PI / 2 + 0.25; neckRing.position.set(0, 1.0, 0.02)
    steth.add(neckRing)
    const cord = (sx: number) => new THREE.Mesh(track(new THREE.TubeGeometry(new THREE.CatmullRomCurve3([
      new THREE.Vector3(sx * 0.2, 1.04, 0.09), new THREE.Vector3(sx * 0.17, 0.82, 0.2), new THREE.Vector3(sx * 0.1, 0.55, 0.26), new THREE.Vector3(0.0, 0.42, 0.265),
    ]), 20, 0.012, 6)), darkMat)
    steth.add(cord(1), cord(-1))
    const chestPiece = new THREE.Mesh(track(new THREE.CylinderGeometry(0.055, 0.055, 0.025, 20)), metal)
    chestPiece.rotation.x = Math.PI / 2; chestPiece.position.set(0, 0.4, 0.268)
    steth.add(chestPiece)
    torso.add(steth)
  } else if (role === "patient") {
    const hood = [[0.02, -0.1], [0.31, -0.1], [0.34, 0.2], [0.36, 0.5], [0.37, 0.78], [0.35, 0.95], [0.27, 1.04], [0.16, 1.09], [0.13, 1.1]]
    torsoZ = 0.75
    torso.add(lathe(hood, topMat, torsoZ))
    // hood ring around the neck, kangaroo pocket, cuff-line
    const hoodRing = part(new THREE.TorusGeometry(0.2, 0.075, 10, 28, Math.PI * 1.4), topMat, 0.012)
    hoodRing.rotation.set(Math.PI / 2, 0, Math.PI * 0.8); hoodRing.position.set(0, 1.0, -0.03)
    torso.add(hoodRing)
    const pocket = k.edges(new THREE.Mesh(track(new RoundedBoxGeometry(0.5, 0.22, 0.05, 2, 0.04)), topMat), 40)
    pocket.position.set(0, 0.2, 0.245)
    torso.add(pocket)
    for (const s of [1, -1]) {
      const lace = new THREE.Mesh(track(new THREE.CylinderGeometry(0.008, 0.008, 0.3, 6)), std("#e8f2f6"))
      lace.position.set(s * 0.07, 0.86, 0.225); lace.rotation.z = s * 0.05
      torso.add(lace)
    }
    // backpack
    const bp = k.edges(new THREE.Mesh(track(new RoundedBoxGeometry(0.6, 0.8, 0.26, 3, 0.09)), std(dark ? "#164a86" : "#2a6bb8", 0.7)), 40)
    bp.position.set(0, 0.52, -0.34)
    const bpFront = k.edges(new THREE.Mesh(track(new RoundedBoxGeometry(0.4, 0.3, 0.1, 2, 0.04)), std(dark ? "#1d5fa8" : "#3a80d0", 0.7)), 40)
    bpFront.position.set(0, -0.18, 0.15); bp.add(bpFront)
    torso.add(bp)
  } else {
    torso.add(lathe(body, topMat, torsoZ))
    // V-neck trim, lanyard + ID card
    const vN = [new THREE.Vector3(-0.13, 1.06, 0.15), new THREE.Vector3(0, 0.84, 0.215), new THREE.Vector3(0.13, 1.06, 0.15)]
    torso.add(new THREE.Line(track(new THREE.BufferGeometry().setFromPoints(vN)), lineMat))
    for (const s of [1, -1]) {
      const pts = [new THREE.Vector3(s * 0.13, 1.08, 0.12), new THREE.Vector3(s * 0.08, 0.85, 0.225), new THREE.Vector3(0, 0.62, 0.26)]
      torso.add(new THREE.Mesh(track(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 12, 0.009, 5)), glowSolid))
    }
    const card = k.edges(new THREE.Mesh(track(new RoundedBoxGeometry(0.17, 0.23, 0.02, 2, 0.02)), std(k.paper, 0.5)), 40)
    card.position.set(0, 0.5, 0.262)
    const cc = new THREE.Group(); cc.position.set(0, 0.03, 0.012)
    cc.add(new THREE.Mesh(track(new THREE.BoxGeometry(0.03, 0.09, 0.006)), glowSolid), new THREE.Mesh(track(new THREE.BoxGeometry(0.09, 0.03, 0.006)), glowSolid))
    card.add(cc); torso.add(card)
  }

  /* ── neck + head ── */
  const neck = part(new THREE.CylinderGeometry(0.09, 0.105, 0.36, 18), skin, 0.012)
  neck.position.y = 2.66; g.add(neck)

  const headPos = new THREE.Vector3(0, 2.84, 0)
  const head = new THREE.Group(); head.position.copy(headPos); g.add(head)
  const skull = sphere(0.33, skin, 0.9, 1.1, 1.0, 0.014); skull.position.y = 0.22
  const jaw = sphere(0.2, skin, 0.98, 0.95, 1.0); jaw.position.set(0, 0.02, 0.1)
  const nose = sphere(0.045, skin, 1, 1.2, 1.2); nose.position.set(0, 0.15, 0.335)
  head.add(skull, jaw, nose)
  for (const s of [1, -1]) {
    const ear = sphere(0.07, skin, 0.5, 1, 0.8); ear.position.set(s * 0.3, 0.19, -0.01)
    head.add(ear)
  }
  const eyes: THREE.Group[] = []
  const white = std("#f4f8fa", 0.4)
  for (const s of [1, -1]) {
    const eye = new THREE.Group(); eye.position.set(s * 0.125, 0.24, 0.282)
    const sc = sphere(0.05, white, 1, 0.8, 0.5); sc.position.z = -0.005
    const pu = sphere(0.027, darkMat, 1, 1, 0.5); pu.position.z = 0.018
    const hi = new THREE.Mesh(track(new THREE.SphereGeometry(0.008, 6, 6)), glowSolid); hi.position.set(0.008, 0.01, 0.03)
    eye.add(sc, pu, hi)
    eye.rotation.y = s * 0.28
    head.add(eye); eyes.push(eye)
    const brow = part(new THREE.CapsuleGeometry(0.012, 0.075, 3, 6), hairMat, 0)
    brow.rotation.z = Math.PI / 2 + s * 0.12; brow.position.set(s * 0.125, 0.325, 0.287); brow.rotation.y = s * 0.28
    head.add(brow)
  }
  const mouth = new THREE.Mesh(track(new THREE.TorusGeometry(0.055, 0.008, 6, 14, Math.PI)), std("#a8574f", 0.6))
  mouth.rotation.z = Math.PI; mouth.position.set(0, 0.075, 0.3)
  head.add(mouth)

  // hair / cap
  const cap = part(new THREE.SphereGeometry(0.345, 28, 18, 0, Math.PI * 2, 0, Math.PI * (role === "tech" ? 0.56 : 0.46)), role === "tech" ? topMat : hairMat, 0.012)
  cap.scale.set(0.93, 1.12, 1.05); cap.position.y = 0.22; cap.rotation.x = 0.3
  head.add(cap)
  if (role === "patient") {
    const long = part(new THREE.CapsuleGeometry(0.17, 0.55, 5, 12), hairMat, 0)
    long.scale.set(1.25, 1, 0.75); long.position.set(0, -0.08, -0.2)
    head.add(long)
    const fringe = part(new THREE.SphereGeometry(0.1, 12, 10), hairMat, 0)
    fringe.scale.set(2.1, 0.55, 0.8); fringe.position.set(0.06, 0.4, 0.24); fringe.rotation.z = -0.3
    head.add(fringe)
  }
  if (role === "doctor") {
    // glasses
    const gm = std(dark ? "#9fe8f2" : "#0b4f63", 0.3, 0.5)
    for (const s of [1, -1]) {
      const r = new THREE.Mesh(track(new THREE.TorusGeometry(0.068, 0.009, 6, 24)), gm)
      r.position.set(s * 0.125, 0.24, 0.305); r.rotation.y = s * 0.28
      head.add(r)
      const arm = new THREE.Mesh(track(new THREE.CylinderGeometry(0.006, 0.006, 0.3, 5)), gm)
      arm.rotation.x = Math.PI / 2; arm.position.set(s * 0.275, 0.24, 0.15)
      head.add(arm)
    }
    const bridge = new THREE.Mesh(track(new THREE.CylinderGeometry(0.006, 0.006, 0.07, 5)), gm)
    bridge.rotation.z = Math.PI / 2; bridge.position.set(0, 0.255, 0.318)
    head.add(bridge)
  }
  if (role === "tech") {
    const mask = k.edges(new THREE.Mesh(track(new RoundedBoxGeometry(0.3, 0.12, 0.06, 2, 0.03)), std("#e8f2f6", 0.7)), 40)
    mask.position.set(0, -0.14, 0.2); mask.rotation.x = 0.35
    head.add(mask)
  }

  /* ── arms ── */
  const longSleeve = role !== "tech"
  const arm = (side: 1 | -1) => {
    const sh = new THREE.Group(); sh.position.set(side * 0.44, 2.46, 0)
    sh.add(sphere(0.135, topMat, 1, 1, 1, 0.014))
    sh.add(limb(0.6, role === "doctor" ? 0.12 : 0.108, topMat))
    const el = new THREE.Group(); el.position.y = -0.6; sh.add(el)
    el.add(sphere(0.1, longSleeve ? topMat : skin))
    const fore = limb(0.5, 0.078, skin); el.add(fore)
    if (longSleeve) {
      const sl = limb(0.36, role === "doctor" ? 0.108 : 0.1, topMat); el.add(sl)
      const cuff = part(new THREE.TorusGeometry(role === "doctor" ? 0.108 : 0.1, 0.02, 8, 20), topMat, 0)
      cuff.rotation.x = Math.PI / 2; cuff.position.y = -0.36; el.add(cuff)
    }
    const hand = new THREE.Group(); hand.position.y = -0.58; el.add(hand)
    const palm = sphere(0.085, skin, 0.9, 1.25, 0.55, 0.01); palm.position.y = -0.05
    const thumb = part(new THREE.CapsuleGeometry(0.022, 0.07, 3, 6), skin, 0)
    thumb.position.set(-side * 0.075, -0.03, 0.03); thumb.rotation.z = -side * 0.5; thumb.rotation.x = -0.4
    const fingers = part(new THREE.CapsuleGeometry(0.03, 0.06, 3, 8), skin, 0)
    fingers.rotation.z = Math.PI / 2; fingers.scale.set(1, 1, 0.8); fingers.position.set(0, -0.13, 0.005)
    hand.add(palm, thumb, fingers)
    return { sh, el, hand }
  }
  const aP = arm(1), aN = arm(-1)
  g.add(aP.sh, aN.sh)

  const props: Human["props"] = {}
  if (role === "doctor") {
    const tab = new THREE.Group()
    const body2 = k.edges(new THREE.Mesh(track(new RoundedBoxGeometry(0.46, 0.64, 0.04, 2, 0.03)), std(dark ? "#0b1d29" : "#dbe9ef", 0.4, 0.3)), 40)
    const scr = new THREE.Mesh(track(new THREE.PlaneGeometry(0.4, 0.58)), glowSoft(k))
    scr.position.z = 0.023
    tab.add(body2, scr)
    tab.position.set(0.0, -0.1, 0.1); tab.rotation.set(-1.1, 0, 0.1)
    aN.hand.add(tab)
    props.tablet = tab
  }
  if (role === "patient") {
    const phone = new THREE.Group()
    const pb = k.edges(new THREE.Mesh(track(new RoundedBoxGeometry(0.17, 0.31, 0.025, 2, 0.025)), std("#0b1d29", 0.3, 0.4)), 40)
    const ps = new THREE.Mesh(track(new THREE.PlaneGeometry(0.145, 0.275)), new THREE.MeshBasicMaterial({ color: cyan, transparent: true, opacity: 0.85 }))
    ps.position.z = 0.014
    phone.add(pb, ps, k.makeHalo(0.7, cyan, 0.5))
    phone.position.set(0.0, -0.08, 0.06); phone.rotation.set(-0.5, 0, 0)
    aP.hand.add(phone)
    props.phone = phone
    const band = new THREE.Mesh(track(new THREE.TorusGeometry(0.085, 0.017, 8, 24)), glowSolid)
    band.rotation.x = Math.PI / 2; band.position.y = -0.46
    aN.el.add(band)
    props.band = band
  }

  const core = k.makeHalo(2.1, cyan, 0.4); core.position.set(0, 1.9, -0.35); g.add(core)

  if (opts.lying) eyes.forEach((e) => e.scale.y = 0.08)

  return {
    g, core, head, torso,
    shP: aP.sh, elP: aP.el, shN: aN.sh, elN: aN.el, handP: aP.hand, handN: aN.hand,
    eyes, headPos, props, seed: opts.seed ?? 0,
  }
}

function glowSoft(k: Kit) {
  return new THREE.MeshBasicMaterial({ color: k.cyan, transparent: true, opacity: k.dark ? 0.5 : 0.4, depthWrite: false })
}

/**
 * Two-bone reach: puts the hand of one arm on `target` (figure-local coordinates).
 * `hint` says which way the elbow should point. `k` is the easing factor for this frame.
 */
export function reach(h: Human, positive: boolean, target: THREE.Vector3, hint: THREE.Vector3, ease: number) {
  const sh = positive ? h.shP : h.shN
  const el = positive ? h.elP : h.elN
  _n.copy(target).sub(sh.position)
  const d = clampN(_n.length(), 0.3, L1 + L2 - 0.02)
  _n.normalize()
  const alpha = Math.acos(clampN((L1 * L1 + d * d - L2 * L2) / (2 * L1 * d), -1, 1))
  const gamma = Math.acos(clampN((L2 * L2 + d * d - L1 * L1) / (2 * L2 * d), -1, 1))
  _p.copy(hint); _p.addScaledVector(_n, -_p.dot(_n))
  if (_p.lengthSq() < 1e-6) _p.set(0, -1, 0)
  _p.normalize()
  _u.copy(_n).multiplyScalar(Math.cos(alpha)).addScaledVector(_p, Math.sin(alpha))
  _qs.setFromUnitVectors(DOWN, _u)
  _a.crossVectors(_u, _n)
  if (_a.lengthSq() < 1e-6) _a.set(1, 0, 0)
  else _a.normalize()
  _qi.copy(_qs).invert()
  _a.applyQuaternion(_qi)
  _qe.setFromAxisAngle(_a, alpha + gamma)
  sh.quaternion.slerp(_qs, ease)
  el.quaternion.slerp(_qe, ease)
}

/** arm relaxed at the side, with a faint sway */
export function restTarget(h: Human, positive: boolean, T: number, out: THREE.Vector3) {
  const s = positive ? 1 : -1
  const sh = positive ? h.shP : h.shN
  return out.set(
    sh.position.x + s * 0.1 + Math.sin(T * 0.8 + h.seed + s) * 0.015,
    sh.position.y - 1.08 + Math.sin(T * 1.1 + h.seed) * 0.012,
    sh.position.z + 0.06,
  )
}

/** Head follows a figure-local point, eased, with limited range. */
export function look(h: Human, target: THREE.Vector3, ease: number, T: number) {
  _v.copy(target).sub(h.headPos)
  const yaw = clampN(Math.atan2(_v.x, _v.z), -0.9, 0.9)
  const pitch = clampN(-Math.atan2(_v.y - 0.2, Math.hypot(_v.x, _v.z)), -0.35, 0.4)
  h.head.rotation.y += (yaw - h.head.rotation.y) * ease
  h.head.rotation.x += (pitch - h.head.rotation.x) * ease
  h.head.rotation.z = Math.sin(T * 0.6 + h.seed) * 0.018
}

/** breathing + blinking */
export function idle(h: Human, T: number, closedEyes = false) {
  const b = Math.sin(T * 1.7 + h.seed)
  h.torso.scale.set(1 + b * 0.008, 1 + b * 0.01, 1 + b * 0.018)
  const open = closedEyes ? 0.08 : (T + h.seed * 2.3) % 3.6 < 0.13 ? 0.1 : 1
  for (const e of h.eyes) e.scale.y += (open - e.scale.y) * 0.6
}

/* ═══════════════════════════ equipment ═══════════════════════════ */

const rrect = (g: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) => {
  g.beginPath(); g.moveTo(x + r, y)
  g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r)
  g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath()
}

/** CT gantry with a real bore, live status display, spinning tube + fan beam, status lamps. */
export function buildScanner(k: Kit) {
  const { dark, track, ink, cyan, glowSolid, lineMat } = k
  const g = new THREE.Group()
  const W = 3.9, H = 3.7, R = 0.6, BORE = 0.95
  const x0 = -W / 2, x1 = W / 2, y0 = -H / 2, y1 = H / 2
  const sh = new THREE.Shape()
  sh.moveTo(x0 + R, y0); sh.lineTo(x1 - R, y0); sh.absarc(x1 - R, y0 + R, R, -Math.PI / 2, 0, false)
  sh.lineTo(x1, y1 - R); sh.absarc(x1 - R, y1 - R, R, 0, Math.PI / 2, false)
  sh.lineTo(x0 + R, y1); sh.absarc(x0 + R, y1 - R, R, Math.PI / 2, Math.PI, false)
  sh.lineTo(x0, y0 + R); sh.absarc(x0 + R, y0 + R, R, Math.PI, Math.PI * 1.5, false)
  const hole = new THREE.Path(); hole.absarc(0, 0, BORE, 0, Math.PI * 2, true); sh.holes.push(hole)
  const geo = track(new THREE.ExtrudeGeometry(sh, { depth: 0.9, bevelEnabled: true, bevelThickness: 0.08, bevelSize: 0.08, bevelSegments: 3, curveSegments: 48 }))
  geo.translate(0, 0, -0.45)
  const shell = new THREE.Mesh(geo, track(new THREE.MeshStandardMaterial({ color: dark ? "#16485e" : "#eaf4f8", roughness: 0.35, metalness: 0.18 })))
  k.edges(shell, 38)
  g.add(shell)

  // bore liner
  const liner = new THREE.Mesh(track(new THREE.CylinderGeometry(BORE - 0.06, BORE - 0.06, 1.0, 56, 1, true)),
    track(new THREE.MeshStandardMaterial({ color: dark ? "#071c28" : "#c9dde6", roughness: 0.6, side: THREE.DoubleSide })))
  liner.rotation.x = Math.PI / 2
  g.add(liner)

  // front trim: glow ring, outer bezel, tick marks
  const ring = new THREE.Mesh(track(new THREE.TorusGeometry(BORE + 0.01, 0.03, 8, 96)), glowSolid); ring.position.z = 0.54
  const bezel = new THREE.Mesh(track(new THREE.TorusGeometry(1.5, 0.018, 6, 96)), track(new THREE.MeshBasicMaterial({ color: ink })))
  bezel.position.z = 0.54
  const tk: number[] = []
  for (let i = 0; i < 72; i++) {
    const a = (i / 72) * Math.PI * 2, r0 = 1.14, r1 = i % 6 === 0 ? 1.28 : 1.21
    tk.push(Math.cos(a) * r0, Math.sin(a) * r0, 0.54, Math.cos(a) * r1, Math.sin(a) * r1, 0.54)
  }
  const ticks = new THREE.LineSegments(track(new THREE.BufferGeometry().setAttribute("position", new THREE.Float32BufferAttribute(tk, 3))), lineMat)
  const arcTop = new THREE.Mesh(track(new THREE.TorusGeometry(1.38, 0.035, 8, 48, Math.PI * 0.55)), glowSolid)
  arcTop.rotation.z = Math.PI * 0.225; arcTop.position.z = 0.54
  g.add(ring, bezel, ticks, arcTop)

  // side vents
  const vp: number[] = []
  for (const s of [-1, 1]) for (let i = 0; i < 7; i++) {
    const y = -1.4 + i * 0.16
    vp.push(s * 1.42, y, 0.545, s * 1.78, y, 0.545)
  }
  g.add(new THREE.LineSegments(track(new THREE.BufferGeometry().setAttribute("position", new THREE.Float32BufferAttribute(vp, 3))), lineMat))

  // spinning tube: glowing detector arc + bright tube head + fan beam
  const spin = new THREE.Mesh(track(new THREE.TorusGeometry(BORE - 0.1, 0.07, 4, 36, Math.PI * 0.5)), k.track(k.glowSoft.clone()))
  spin.position.z = 0.02
  const tubeHead = new THREE.Mesh(track(new THREE.BoxGeometry(0.16, 0.2, 0.3)), glowSolid)
  tubeHead.position.set(BORE - 0.1, 0, 0)
  spin.add(tubeHead, k.makeHalo(0.7, cyan, 0.8))
  ;(spin.children[1] as THREE.Sprite).position.set(BORE - 0.1, 0, 0)
  const beamShape = new THREE.Shape(); beamShape.moveTo(BORE - 0.1, 0); beamShape.lineTo(-(BORE - 0.1), 0.62); beamShape.lineTo(-(BORE - 0.1), -0.62); beamShape.closePath()
  const beam = new THREE.Mesh(track(new THREE.ShapeGeometry(beamShape)), track(new THREE.MeshBasicMaterial({ color: cyan, transparent: true, opacity: 0, depthWrite: false, side: THREE.DoubleSide, blending: k.glowBlend })))
  spin.add(beam)
  g.add(spin)
  const disc = new THREE.Mesh(track(new THREE.CircleGeometry(BORE - 0.1, 48)), k.track(k.glowSoft.clone()))
  g.add(disc)

  // alignment lasers
  const laser = track(new THREE.MeshBasicMaterial({ color: "#35c9a1", transparent: true, opacity: 0.8 }))
  const lh = new THREE.Mesh(track(new THREE.BoxGeometry(1.5, 0.012, 0.01)), laser); lh.position.set(0, 0, 0.535)
  const lv = new THREE.Mesh(track(new THREE.BoxGeometry(0.012, 1.5, 0.01)), laser); lv.position.set(0, 0, 0.535)
  g.add(lh, lv)

  // status display
  const dc = document.createElement("canvas"); dc.width = 512; dc.height = 150
  const dg = dc.getContext("2d")!
  const dtex = k.mkTex(dc)
  const display = new THREE.Mesh(track(new THREE.PlaneGeometry(1.7, 0.5)), new THREE.MeshBasicMaterial({ map: dtex, toneMapped: false }))
  display.position.set(0, 1.5, 0.545)
  const dispFrame = new THREE.LineSegments(track(new THREE.EdgesGeometry(display.geometry)), lineMat)
  display.add(dispFrame)
  g.add(display)
  let lastKey = ""
  const drawDisplay = (prog: number, scanning: boolean) => {
    const key = `${Math.round(prog * 50)}|${scanning}`
    if (key === lastKey) return
    lastKey = key
    dg.clearRect(0, 0, 512, 150)
    dg.fillStyle = dark ? "#04141c" : "#f6fbfd"; rrect(dg, 2, 2, 508, 146, 18); dg.fill()
    dg.strokeStyle = k.css(ink); dg.lineWidth = 3; dg.stroke()
    dg.textBaseline = "middle"
    dg.fillStyle = k.text; dg.font = '600 34px "Space Grotesk Variable","Inter Variable",system-ui,sans-serif'
    dg.fillText("CT · CHEST", 26, 44)
    dg.globalAlpha = 0.6; dg.font = '500 22px "Inter Variable",system-ui,sans-serif'
    dg.fillText("120 kV · 200 mA", 26, 82); dg.globalAlpha = 1
    dg.fillStyle = scanning ? k.css(cyan) : "#35c9a1"
    dg.beginPath(); dg.arc(366, 44, 8, 0, 7); dg.fill()
    dg.font = '600 24px "Inter Variable",system-ui,sans-serif'
    dg.fillText(scanning ? "SCANNING" : prog > 0.98 ? "COMPLETE" : "READY", 384, 45)
    dg.fillStyle = dark ? "rgba(190,225,245,.16)" : "rgba(40,80,110,.16)"; rrect(dg, 26, 108, 460, 16, 8); dg.fill()
    dg.fillStyle = k.css(cyan); rrect(dg, 26, 108, Math.max(16, 460 * prog), 16, 8); dg.fill()
    dtex.needsUpdate = true
  }
  drawDisplay(0, false)

  // status lamps
  const lamps: THREE.Mesh[] = []
  for (const s of [-1, 1]) {
    const m = new THREE.Mesh(track(new THREE.SphereGeometry(0.06, 12, 10)), track(new THREE.MeshBasicMaterial({ color: "#35c9a1" })))
    m.position.set(s * 1.65, 1.55, 0.56)
    const h = k.makeHalo(0.55, cyan, 0.5); m.add(h)
    lamps.push(m); g.add(m)
  }
  const setStatus = (scanning: boolean, T: number) => {
    const pulse = 0.65 + 0.35 * Math.sin(T * 5)
    for (const l of lamps) {
      ;(l.material as THREE.MeshBasicMaterial).color.set(scanning ? "#ffb347" : "#35c9a1")
      l.scale.setScalar(scanning ? 0.9 + 0.3 * pulse : 1)
    }
    laser.opacity = scanning ? 0.25 : 0.8
  }

  return { g, spin, beam, disc, drawDisplay, setStatus, BORE }
}

/** Motorised patient table (moves) + fixed pedestal. */
export function buildBed(k: Kit) {
  const { track, glow } = { track: k.track, glow: k.glowSolid }
  const bed = new THREE.Group()
  bed.add(k.panel(1.15, 0.1, 4.4, k.glass, 0.05))
  const pad = k.panel(0.98, 0.07, 3.5, k.track(new THREE.MeshStandardMaterial({ color: k.dark ? "#1a5a74" : "#d3e6ee", roughness: 0.7 })), 0.04)
  pad.position.set(0, 0.085, 0.3); bed.add(pad)
  const pillow = k.panel(0.55, 0.12, 0.6, k.track(new THREE.MeshStandardMaterial({ color: k.dark ? "#cfe3ee" : "#ffffff", roughness: 0.9 })), 0.05)
  pillow.position.set(0, 0.17, -1.3); bed.add(pillow)
  for (const s of [-1, 1]) {
    const rail = new THREE.Mesh(track(new THREE.BoxGeometry(0.03, 0.03, 4.0)), glow); rail.position.set(s * 0.55, 0.0, 0)
    bed.add(rail)
  }
  // restraint strap across the legs
  const strap = new THREE.Mesh(track(new THREE.BoxGeometry(1.0, 0.025, 0.12)), track(new THREE.MeshStandardMaterial({ color: k.dark ? "#0b1d29" : "#51707f" })))
  strap.position.set(0, 0.14, 1.3); bed.add(strap)

  const pedestal = new THREE.Group()
  const base = k.panel(1.9, 0.14, 1.7, k.glassSolid, 0.05); base.position.y = 0.29
  const col = k.panel(1.0, 0.92, 1.05, k.glass, 0.06); col.position.y = 0.76
  const cap = k.panel(1.3, 0.1, 1.3, k.glassSolid, 0.04); cap.position.y = 1.19
  const strip = new THREE.Mesh(track(new THREE.BoxGeometry(0.7, 0.03, 0.01)), glow); strip.position.set(0, 0.85, 0.54)
  pedestal.add(base, col, cap, strip)
  return { bed, pedestal }
}

function monitorTex(k: Kit, kind: "slice" | "vitals") {
  const c = document.createElement("canvas"); c.width = 512; c.height = 320
  const g = c.getContext("2d")!
  g.fillStyle = k.dark ? "#04141c" : "#0b2230"; g.fillRect(0, 0, 512, 320)
  g.strokeStyle = k.css(k.cyan); g.globalAlpha = 0.18; g.lineWidth = 1
  for (let x = 0; x < 512; x += 32) { g.beginPath(); g.moveTo(x, 0); g.lineTo(x, 320); g.stroke() }
  for (let y = 0; y < 320; y += 32) { g.beginPath(); g.moveTo(0, y); g.lineTo(512, y); g.stroke() }
  g.globalAlpha = 1
  if (kind === "slice") {
    const cx = 256, cy = 168
    const gr = g.createRadialGradient(cx, cy, 20, cx, cy, 140)
    gr.addColorStop(0, "rgba(200,240,250,.5)"); gr.addColorStop(1, "rgba(80,180,210,.12)")
    g.fillStyle = gr; g.beginPath(); g.ellipse(cx, cy, 150, 112, 0, 0, 7); g.fill()
    g.strokeStyle = "rgba(210,245,255,.8)"; g.lineWidth = 3; g.stroke()
    g.fillStyle = "rgba(4,20,28,.85)"
    g.beginPath(); g.ellipse(cx - 62, cy - 4, 40, 58, 0.15, 0, 7); g.fill()
    g.beginPath(); g.ellipse(cx + 62, cy - 4, 40, 58, -0.15, 0, 7); g.fill()
    g.fillStyle = "rgba(230,250,255,.9)"; g.beginPath(); g.arc(cx, cy + 48, 14, 0, 7); g.fill()
    g.beginPath(); g.ellipse(cx + 8, cy - 4, 22, 28, 0, 0, 7); g.fill()
    g.strokeStyle = k.css(k.cyan); g.lineWidth = 1.5
    g.beginPath(); g.moveTo(cx, 40); g.lineTo(cx, 296); g.moveTo(80, cy); g.lineTo(432, cy); g.stroke()
    g.fillStyle = k.css(k.cyan); g.font = '600 20px "Inter Variable",system-ui,sans-serif'; g.fillText("AXIAL 042/128", 18, 28)
    g.fillText("W 1500  L -600", 18, 304)
  } else {
    g.fillStyle = "#e8f2f6"; g.font = '600 20px "Inter Variable",system-ui,sans-serif'; g.fillText("PATIENT · VITALS", 18, 28)
    g.strokeStyle = k.css(k.cyan); g.lineWidth = 3; g.beginPath()
    for (let x = 0; x < 360; x++) {
      const p = (x % 90) / 90
      const y = p > 0.35 && p < 0.4 ? -(p - 0.35) / 0.05 * 34 : p >= 0.4 && p < 0.46 ? -34 + (p - 0.4) / 0.06 * 62 : p >= 0.46 && p < 0.5 ? 28 - (p - 0.46) / 0.04 * 28 : 0
      g.lineTo(18 + x, 112 + y)
    }
    g.stroke()
    g.strokeStyle = "#35c9a1"; g.beginPath()
    for (let x = 0; x < 360; x++) g.lineTo(18 + x, 200 + Math.sin(x / 16) * 14 * Math.exp(-((x % 120) / 80)))
    g.stroke()
    g.font = '700 54px "Space Grotesk Variable","Inter Variable",sans-serif'
    g.fillStyle = k.css(k.cyan); g.fillText("72", 400, 100); g.fillStyle = "#35c9a1"; g.fillText("98", 400, 200)
    g.fillStyle = "#e8f2f6"; g.globalAlpha = 0.6; g.font = '500 18px "Inter Variable",sans-serif'
    g.fillText("HR bpm", 400, 130); g.fillText("SpO₂ %", 400, 230); g.globalAlpha = 1
  }
  return k.mkTex(c)
}

/** Technician's console: desk, two monitors on arms, keyboard, mouse. Front (where the operator stands) is +z. */
export function buildConsole(k: Kit) {
  const { track } = k
  const g = new THREE.Group()
  const body = k.panel(2.3, 0.95, 0.9, k.glass, 0.06); body.position.y = 0.475
  const top = k.panel(2.4, 0.08, 1.0, k.glassSolid, 0.04); top.position.y = 0.97
  g.add(body, top)
  const kneeCut = new THREE.Mesh(track(new THREE.BoxGeometry(0.9, 0.5, 0.04)), k.glowSolid); kneeCut.position.set(0, 0.45, 0.46); kneeCut.scale.y = 0.02
  g.add(kneeCut)
  const mons = [monitorTex(k, "slice"), monitorTex(k, "vitals")]
  mons.forEach((t, i) => {
    const m = new THREE.Group(); m.position.set(i === 0 ? -0.55 : 0.55, 1.62, -0.2); m.rotation.y = i === 0 ? 0.18 : -0.18
    const frame = k.panel(1.02, 0.66, 0.06, k.glassSolid, 0.04)
    const scr = new THREE.Mesh(track(new THREE.PlaneGeometry(0.94, 0.58)), new THREE.MeshBasicMaterial({ map: t, toneMapped: false })); scr.position.z = 0.034
    const stem = new THREE.Mesh(track(new THREE.CylinderGeometry(0.035, 0.035, 0.5, 8)), k.glassSolid); stem.position.set(0, -0.55, -0.03)
    m.add(frame, scr, stem)
    g.add(m)
  })
  const kb = k.panel(0.9, 0.035, 0.3, k.glassSolid, 0.02); kb.position.set(0, 1.03, 0.25)
  const keys: number[] = []
  for (let r = 0; r < 4; r++) keys.push(-0.4, 0.0, -0.1 + r * 0.065, 0.4, 0.0, -0.1 + r * 0.065)
  const kbLines = new THREE.LineSegments(track(new THREE.BufferGeometry().setAttribute("position", new THREE.Float32BufferAttribute(keys, 3))), k.lineMat)
  kbLines.position.y = 0.02; kbLines.position.z = 0.15; kb.add(kbLines)
  g.add(kb)
  const mouse = k.panel(0.09, 0.035, 0.14, k.glassSolid, 0.03); mouse.position.set(0.75, 1.03, 0.28); g.add(mouse)
  // two hand anchors on the keyboard
  const aL = new THREE.Object3D(); aL.position.set(-0.22, 1.1, 0.27)
  const aR = new THREE.Object3D(); aR.position.set(0.22, 1.1, 0.27)
  g.add(aL, aR)
  const anchorMon = new THREE.Object3D(); anchorMon.position.set(0, 1.65, -0.1); g.add(anchorMon)
  return { g, aL, aR, anchorMon, mouse }
}

/** Doctor's desk with keyboard, tablet, lamp, mug, folders, plant. Origin on the floor, centred. */
export function buildDesk(k: Kit) {
  const { track } = k
  const g = new THREE.Group()
  const top = k.panel(5.0, 0.1, 1.5, k.glassSolid, 0.05); top.position.y = 1.05
  g.add(top)
  for (const s of [-1, 1]) { const l = k.panel(0.12, 1.0, 1.3, k.glass, 0.04); l.position.set(s * 2.35, 0.5, 0); g.add(l) }
  const back = k.panel(4.6, 0.7, 0.05, k.glass, 0.03); back.position.set(0, 0.62, -0.62); g.add(back)
  const kb = k.panel(1.2, 0.035, 0.38, k.glassSolid, 0.02); kb.position.set(0.3, 1.13, 0.35)
  const kk: number[] = []
  for (let r = 0; r < 4; r++) kk.push(-0.55, 0, -0.14 + r * 0.085, 0.55, 0, -0.14 + r * 0.085)
  const kl = new THREE.LineSegments(track(new THREE.BufferGeometry().setAttribute("position", new THREE.Float32BufferAttribute(kk, 3))), k.lineMat)
  kl.position.y = 0.02; kb.add(kl)
  g.add(kb)
  // tablet on a stand
  const tab = k.panel(0.8, 0.55, 0.04, k.glassSolid, 0.03); tab.position.set(-1.35, 1.4, 0.15); tab.rotation.x = -0.25
  const tscr = new THREE.Mesh(track(new THREE.PlaneGeometry(0.72, 0.47)), new THREE.MeshBasicMaterial({ map: monitorTex(k, "vitals"), toneMapped: false })); tscr.position.z = 0.023
  tab.add(tscr); g.add(tab)
  // lamp
  const lamp = new THREE.Group(); lamp.position.set(2.1, 1.1, -0.3)
  const lb = new THREE.Mesh(track(new THREE.CylinderGeometry(0.16, 0.2, 0.05, 20)), k.glassSolid)
  const arm1 = new THREE.Mesh(track(new THREE.CylinderGeometry(0.015, 0.015, 0.8, 6)), k.glassSolid); arm1.position.set(0.1, 0.4, 0); arm1.rotation.z = -0.25
  const arm2 = new THREE.Mesh(track(new THREE.CylinderGeometry(0.015, 0.015, 0.7, 6)), k.glassSolid); arm2.position.set(-0.12, 0.95, 0); arm2.rotation.z = 1.15
  const shade = new THREE.Mesh(track(new THREE.ConeGeometry(0.17, 0.22, 20, 1, true)), track(new THREE.MeshStandardMaterial({ color: k.dark ? "#16485e" : "#dbe9ef", side: THREE.DoubleSide })))
  shade.position.set(-0.4, 1.2, 0); shade.rotation.z = 0.35
  const bulb = new THREE.Mesh(track(new THREE.SphereGeometry(0.05, 10, 8)), k.glowSolid); bulb.position.set(-0.42, 1.12, 0)
  bulb.add(k.makeHalo(1.0, k.cyan, 0.6))
  lamp.add(lb, arm1, arm2, shade, bulb); g.add(lamp)
  // mug
  const mug = new THREE.Group(); mug.position.set(-0.55, 1.1, 0.2)
  mug.add(new THREE.Mesh(track(new THREE.CylinderGeometry(0.09, 0.08, 0.17, 20)), track(new THREE.MeshStandardMaterial({ color: k.dark ? "#cfe3ee" : "#ffffff", roughness: 0.4 }))))
  const handle = new THREE.Mesh(track(new THREE.TorusGeometry(0.05, 0.013, 6, 14, Math.PI)), k.glowSolid); handle.rotation.z = -Math.PI / 2; handle.position.x = 0.09
  mug.add(handle); mug.position.y += 0.085
  g.add(mug)
  // folders
  const cols = ["#00b8cc", "#168bff", "#35c9a1"]
  cols.forEach((c, i) => {
    const f = k.edges(new THREE.Mesh(track(new RoundedBoxGeometry(0.6, 0.04, 0.8, 2, 0.01)), track(new THREE.MeshStandardMaterial({ color: c, roughness: 0.6 }))), 40)
    f.position.set(1.55, 1.12 + i * 0.045, 0.3); f.rotation.y = (i - 1) * 0.12
    g.add(f)
  })
  // plant
  const plant = new THREE.Group(); plant.position.set(-2.05, 1.1, -0.25)
  plant.add(new THREE.Mesh(track(new THREE.CylinderGeometry(0.14, 0.1, 0.2, 14)), track(new THREE.MeshStandardMaterial({ color: k.dark ? "#cfe3ee" : "#ffffff", roughness: 0.6 }))))
  const leaf = track(new THREE.MeshStandardMaterial({ color: "#2fae8a", roughness: 0.6 }))
  for (let i = 0; i < 7; i++) {
    const l = new THREE.Mesh(track(new THREE.SphereGeometry(0.1, 10, 8)), leaf)
    const a = (i / 7) * Math.PI * 2
    l.scale.set(0.5, 1.5, 0.12); l.position.set(Math.cos(a) * 0.08, 0.28 + (i % 2) * 0.07, Math.sin(a) * 0.08)
    l.rotation.set(Math.sin(a) * 0.5, 0, -Math.cos(a) * 0.5)
    plant.add(l)
  }
  g.add(plant)
  return g
}

/** Wheeled instrument cart with trays, bottles and a small light. */
export function buildCart(k: Kit) {
  const { track } = k
  const g = new THREE.Group()
  const top = k.panel(0.95, 0.05, 0.6, k.glassSolid, 0.03); top.position.y = 1.0
  const mid = k.panel(0.95, 0.04, 0.6, k.glass, 0.03); mid.position.y = 0.55
  g.add(top, mid)
  for (const [x, z] of [[-0.44, -0.27], [0.44, -0.27], [-0.44, 0.27], [0.44, 0.27]]) {
    const post = new THREE.Mesh(track(new THREE.CylinderGeometry(0.02, 0.02, 0.9, 6)), k.glowSolid); post.position.set(x, 0.55, z); g.add(post)
    const wheel = new THREE.Mesh(track(new THREE.CylinderGeometry(0.07, 0.07, 0.05, 14)), k.glassSolid); wheel.rotation.z = Math.PI / 2; wheel.position.set(x, 0.07, z); g.add(wheel)
  }
  const mats = ["#00b8cc", "#168bff", "#ffffff"].map((c) => track(new THREE.MeshStandardMaterial({ color: c, roughness: 0.4, transparent: true, opacity: 0.9 })))
  for (let i = 0; i < 4; i++) {
    const b = new THREE.Mesh(track(new THREE.CylinderGeometry(0.045, 0.045, 0.16 + (i % 2) * 0.05, 12)), mats[i % 3]); b.position.set(-0.3 + i * 0.12, 1.1 + (i % 2) * 0.025, -0.1); g.add(b)
    const cap = new THREE.Mesh(track(new THREE.CylinderGeometry(0.03, 0.03, 0.04, 10)), k.glassSolid); cap.position.set(-0.3 + i * 0.12, 1.2 + (i % 2) * 0.05, -0.1); g.add(cap)
  }
  const tray = k.edges(new THREE.Mesh(track(new RoundedBoxGeometry(0.4, 0.03, 0.28, 2, 0.01)), k.glass), 40); tray.position.set(0.22, 1.05, 0.12); g.add(tray)
  const box = k.edges(new THREE.Mesh(track(new RoundedBoxGeometry(0.3, 0.14, 0.2, 2, 0.02)), track(new THREE.MeshStandardMaterial({ color: "#e8f2f6" }))), 40); box.position.set(-0.2, 0.64, 0); g.add(box)
  const cross = new THREE.Group(); cross.position.set(0, 0, 0.101)
  cross.add(new THREE.Mesh(track(new THREE.BoxGeometry(0.03, 0.09, 0.005)), k.glowSolid), new THREE.Mesh(track(new THREE.BoxGeometry(0.09, 0.03, 0.005)), k.glowSolid))
  box.add(cross)
  return g
}

/** Consent padlock: shackle lifts when `open` goes 0 -> 1. */
export function buildLock(k: Kit) {
  const { track } = k
  const g = new THREE.Group()
  const body = k.edges(new THREE.Mesh(track(new RoundedBoxGeometry(0.9, 0.7, 0.3, 3, 0.1)), k.glass), 40)
  const shackle = new THREE.Group(); shackle.position.set(0.25, 0.35, 0)
  const sh = new THREE.Mesh(track(new THREE.TorusGeometry(0.25, 0.05, 8, 24, Math.PI)), k.glowSolid); sh.position.x = -0.25
  shackle.add(sh)
  const keyhole = new THREE.Group(); keyhole.position.z = 0.16
  keyhole.add(new THREE.Mesh(track(new THREE.CircleGeometry(0.07, 18)), k.glowSolid))
  const kslot = new THREE.Mesh(track(new THREE.BoxGeometry(0.04, 0.16, 0.002)), k.glowSolid); kslot.position.y = -0.1; keyhole.add(kslot)
  g.add(body, shackle, keyhole, k.makeHalo(2.2, k.cyan, 0.35))
  const set = (open: number) => {
    shackle.position.y = 0.35 + open * 0.14
    shackle.rotation.y = -open * 1.0
  }
  return { g, set }
}
