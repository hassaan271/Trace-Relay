# Trace Relay (login + 3D intro + dashboards)

    pnpm install
    pnpm dev        # http://localhost:3000

Flow: `/` plays the 3D intro (Esc or "Skip intro" to skip) then the login page.
Sign in (`.dr` -> /doctor, `.patient` -> /patient, `.org` -> /diagnostic) or "Continue as guest".
Dashboards live at `/patient`, `/doctor`, `/diagnostic` (role switcher in the sidebar).

Intro people + equipment: `components/intro/figures.ts`; timeline + camera: `components/intro/trace-intro-scene.tsx`.
Theme: one next-themes provider (class on <html>, dark by default) shared by login, intro and dashboards.
