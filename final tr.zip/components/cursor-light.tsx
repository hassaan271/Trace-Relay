"use client"

import { useEffect, useRef } from "react"
import { gsap } from "gsap"

/**
 * Minimal cursor light.
 * A single soft, low-opacity glow that drifts smoothly behind the pointer.
 *
 * Performance: this used to redraw a full-screen canvas every frame. It is now
 * one small <div> with a CSS radial gradient that GSAP moves with transforms,
 * so the work stays on the compositor and nothing is repainted.
 *
 * - gsap.quickTo gives the smooth follow with no per-move allocations.
 * - Pointer position never touches React state.
 * - Disabled for touch / coarse pointers and prefers-reduced-motion.
 */

const IDLE_FADE_DELAY = 0.6 // seconds after last move before fading

export function CursorLight() {
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const el = ref.current
    if (!el) return

    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)")
    const coarse = window.matchMedia("(pointer: coarse)")
    if (reduced.matches || coarse.matches) return

    gsap.set(el, { xPercent: -50, yPercent: -50, x: -1000, y: -1000, opacity: 0 })

    const moveX = gsap.quickTo(el, "x", { duration: 0.6, ease: "power3.out" })
    const moveY = gsap.quickTo(el, "y", { duration: 0.6, ease: "power3.out" })
    const fade = gsap.quickTo(el, "opacity", { duration: 0.5, ease: "power2.out" })

    const idle = gsap.delayedCall(IDLE_FADE_DELAY, () => fade(0)).pause()
    let hasPosition = false

    const onMove = (e: PointerEvent) => {
      if (e.pointerType === "touch") return
      if (!hasPosition) {
        gsap.set(el, { x: e.clientX, y: e.clientY })
        hasPosition = true
      }
      moveX(e.clientX)
      moveY(e.clientY)
      fade(1)
      idle.restart(true)
    }
    const onLeave = () => fade(0)

    window.addEventListener("pointermove", onMove, { passive: true })
    document.documentElement.addEventListener("pointerleave", onLeave)

    return () => {
      window.removeEventListener("pointermove", onMove)
      document.documentElement.removeEventListener("pointerleave", onLeave)
      idle.kill()
      gsap.killTweensOf(el)
    }
  }, [])

  return <div ref={ref} className="cursor-light" aria-hidden="true" />
}
