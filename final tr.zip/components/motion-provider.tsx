"use client"

import { useEffect } from "react"
import { usePathname } from "next/navigation"
import Lenis from "lenis"
import { gsap } from "gsap"
import { ScrollTrigger } from "gsap/ScrollTrigger"

if (typeof window !== "undefined") {
  gsap.registerPlugin(ScrollTrigger)
  // Mobile URL-bar show/hide fires resize events; refreshing on them causes jank.
  ScrollTrigger.config({ ignoreMobileResize: true })
}

/**
 * Smooth scrolling (Lenis) + scroll-triggered reveals (GSAP ScrollTrigger).
 *
 * One animation loop: Lenis is driven by gsap.ticker, and ScrollTrigger is
 * updated from Lenis' scroll event, so scrolling, reveals, the background scene
 * and the cursor light all share the same frame instead of racing each other.
 *
 * Reveals: any element with `data-reveal` fades/slides in once as it enters the
 * viewport. CSS hides it first (see globals.css) so there is no flash. Elements
 * entering together are staggered. Nothing here runs under prefers-reduced-motion.
 */
export function MotionProvider() {
  const pathname = usePathname()

  // Smooth scroll: created once for the whole app.
  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return

    const lenis = new Lenis({
      autoRaf: false, // GSAP's ticker drives it
      lerp: 0.12, // responsive follow, no "waiting" before the page moves
      smoothWheel: true, // wheel/trackpad only: touch stays native, which is the most responsive on phones
      anchors: { offset: -96 }, // in-page links (#features, ...) glide; matches the .anchor scroll margin
    })

    lenis.on("scroll", ScrollTrigger.update)
    const tick = (time: number) => lenis.raf(time * 1000)
    gsap.ticker.add(tick)
    gsap.ticker.lagSmoothing(0) // stops GSAP "catching up" after a slow frame, which reads as a stutter

    return () => {
      gsap.ticker.remove(tick)
      lenis.destroy()
    }
  }, [])

  // Reveals: rebuilt for each page, since route changes swap the content.
  useEffect(() => {
    if (!document.documentElement.classList.contains("motion")) return

    const targets = gsap.utils.toArray<HTMLElement>("[data-reveal]")
    if (!targets.length) return

    const ctx = gsap.context(() => {
      ScrollTrigger.batch(targets, {
        start: "top 92%",
        once: true,
        interval: 0.08,
        onEnter: (batch) => {
          gsap.fromTo(
            batch,
            { opacity: 0, y: 28 },
            {
              opacity: 1,
              y: 0,
              duration: 0.8,
              ease: "power3.out",
              stagger: 0.07,
              overwrite: true,
              onComplete: () => {
                // Hand the element back to CSS so hover transforms and transitions work again.
                batch.forEach((el) => {
                  el.setAttribute("data-revealed", "")
                  gsap.set(el, { clearProps: "opacity,transform" })
                })
              },
            },
          )
        },
      })
    })

    return () => {
      ctx.revert()
      targets.forEach((el) => el.removeAttribute("data-revealed"))
    }
  }, [pathname])

  return null
}
