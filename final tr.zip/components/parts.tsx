import Link from "next/link"
import { ArrowRight, ArrowUpRight, type LucideIcon } from "lucide-react"
import { cn } from "@/lib/utils"

export type Tone = "ok" | "warn" | "bad" | "info" | "ai"

export function StatusBadge({ tone, children }: { tone: Tone; children: React.ReactNode }) {
  return <span className={cn("badge", `badge-${tone}`)}>{children}</span>
}

/** Marks illustrative data so it is never mistaken for real records. */
export function SampleDataNote() {
  return (
    <span className="inline-flex items-center gap-2 rounded-lg border border-dashed border-line px-2.5 py-1 text-[12px] text-ink-3">
      Sample data · not connected to a backend
    </span>
  )
}

export function PageHeading({
  eyebrow,
  title,
  description,
  action,
}: {
  eyebrow: string
  title: string
  description: string
  action?: React.ReactNode
}) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-4" data-reveal>
      <div className="min-w-0">
        <p className="t-eyebrow mb-2">{eyebrow}</p>
        <h1 className="t-page-title">{title}</h1>
        <p className="t-body mt-2 max-w-[60ch]">{description}</p>
      </div>
      <div className="flex flex-wrap items-center gap-3">
        <SampleDataNote />
        {action}
      </div>
    </div>
  )
}

export function MetricCard({
  icon: Icon,
  value,
  label,
  note,
  href,
}: {
  icon: LucideIcon
  value: string
  label: string
  note: string
  href?: string
}) {
  const body = (
    <>
      <span className="grid h-12 w-12 flex-none place-items-center rounded-xl border border-line bg-[var(--cyan-soft)] text-cyan">
        <Icon className="h-[22px] w-[22px]" strokeWidth={1.6} aria-hidden="true" />
      </span>
      <span className="min-w-0">
        <span className="t-metric block">{value}</span>
        <span className="mt-2 block text-[14.5px] text-ink">{label}</span>
        <span className="mt-1 block text-[12.5px] text-ink-3">{note}</span>
      </span>
    </>
  )
  const cls = "glass glass-interactive flex items-start gap-4 p-5"
  return href ? (
    <Link href={href} className={cls} data-reveal>
      {body}
    </Link>
  ) : (
    <div className={cls} data-reveal>
      {body}
    </div>
  )
}

export function Panel({
  title,
  description,
  action,
  className,
  children,
  dense,
}: {
  title: string
  description?: string
  action?: React.ReactNode
  className?: string
  children: React.ReactNode
  dense?: boolean
}) {
  return (
    <section className={cn(dense ? "glass-dense" : "glass", "p-5", className)} data-reveal>
      <header className="mb-4 flex items-start justify-between gap-3">
        <div className="min-w-0">
          <h2 className="t-panel">{title}</h2>
          {description && <p className="t-body mt-0.5 text-[13.5px]">{description}</p>}
        </div>
        {action}
      </header>
      {children}
    </section>
  )
}

export function ViewAll({ href }: { href: string }) {
  return (
    <Link href={href} className="btn btn-secondary btn-sm">
      View all <ArrowRight aria-hidden="true" />
    </Link>
  )
}

export function RowAction({ href, children = "View" }: { href: string; children?: React.ReactNode }) {
  return (
    <Link href={href} className="inline-flex items-center gap-1 text-ink-2 transition-colors hover:text-cyan">
      {children} <ArrowUpRight className="h-3.5 w-3.5" aria-hidden="true" />
    </Link>
  )
}
