import { CalendarClock, FileCheck2, Stethoscope, Upload } from "lucide-react"
import { MetricCard, PageHeading, Panel, RowAction, StatusBadge, ViewAll, type Tone } from "@/components/parts"

const schedule = [
  { time: "09:00", scan: "MRI Brain", patient: "P-20931", room: "Suite 2" },
  { time: "10:30", scan: "Chest X-ray", patient: "P-20877", room: "Room 1" },
  { time: "12:00", scan: "Abdominal Ultrasound", patient: "P-20654", room: "Room 3" },
  { time: "14:15", scan: "CT Chest", patient: "P-20402", room: "Suite 1" },
]

const reports: { id: string; patient: string; study: string; date: string; status: string; tone: Tone; action: string }[] = [
  { id: "R-5521", patient: "P-20402", study: "CT Chest", date: "04 Mar 2026", status: "Awaiting upload", tone: "warn", action: "Upload" },
  { id: "R-5518", patient: "P-20877", study: "Chest X-ray", date: "04 Mar 2026", status: "Ready for release", tone: "info", action: "Review" },
  { id: "R-5509", patient: "P-20310", study: "Lipid Profile", date: "02 Mar 2026", status: "Released", tone: "ok", action: "View" },
  { id: "R-5497", patient: "P-20188", study: "MRI Knee", date: "27 Feb 2026", status: "Overdue", tone: "bad", action: "Upload" },
]

export function DiagnosticDashboard() {
  return (
    <>
      <PageHeading
        eyebrow="Diagnostic centre dashboard"
        title="Today at Northstar Lab"
        description="Bookings, report uploads, and releases for today's operations."
        action={
          <button type="button" className="btn btn-primary">
            <Upload aria-hidden="true" /> Upload report
          </button>
        }
      />

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <MetricCard icon={CalendarClock} value="21" label="Today's bookings" note="4 scans remaining" href="/diagnostic/bookings" />
        <MetricCard icon={Upload} value="7" label="Awaiting upload" note="2 overdue" href="/diagnostic/reports" />
        <MetricCard icon={FileCheck2} value="5" label="Ready for release" note="Needs review" href="/diagnostic/reports" />
        <MetricCard icon={Stethoscope} value="11" label="Pending follow-ups" note="3 due this week" href="/diagnostic/follow-up-queue" />
      </div>

      <div className="mt-4 grid grid-cols-1 gap-4 xl:grid-cols-[minmax(0,1fr)_minmax(0,1.6fr)]">
        <Panel title="Scan schedule" description="Today's appointments by time." action={<ViewAll href="/diagnostic/scan-tracking" />}>
          <ul className="divide-y divide-[var(--border)]">
            {schedule.map((s) => (
              <li key={s.time} className="flex items-center gap-4 py-3">
                <span className="w-12 flex-none text-[14px] font-medium tabular-nums text-ink">{s.time}</span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[14px] text-ink">{s.scan}</span>
                  <span className="block truncate text-[12.5px] text-ink-3">{s.patient}</span>
                </span>
                <span className="flex-none text-[12.5px] text-ink-3">{s.room}</span>
              </li>
            ))}
          </ul>
        </Panel>

        <Panel title="Recent reports" description="Status and next action for each report." dense action={<ViewAll href="/diagnostic/reports" />}>
          <div className="table-scroll">
            <table className="data-table">
              <thead>
                <tr>
                  <th scope="col">Report</th>
                  <th scope="col">Patient</th>
                  <th scope="col">Study</th>
                  <th scope="col">Scan date</th>
                  <th scope="col">Status</th>
                  <th scope="col">Actions</th>
                </tr>
              </thead>
              <tbody>
                {reports.map((r) => (
                  <tr key={r.id}>
                    <td>{r.id}</td>
                    <td>{r.patient}</td>
                    <td>{r.study}</td>
                    <td>{r.date}</td>
                    <td><StatusBadge tone={r.tone}>{r.status}</StatusBadge></td>
                    <td><RowAction href="/diagnostic/reports">{r.action}</RowAction></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Panel>
      </div>
    </>
  )
}
