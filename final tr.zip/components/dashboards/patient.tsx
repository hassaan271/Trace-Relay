import { Bell, Calendar, FileText, TrendingUp, Upload } from "lucide-react"
import { MetricCard, PageHeading, Panel, RowAction, StatusBadge, ViewAll, type Tone } from "@/components/parts"

const timeline = [
  { label: "Report added", date: "12 Feb", state: "done" },
  { label: "Clinical review", date: "18 Feb", state: "done" },
  { label: "Follow-up", date: "04 Mar", state: "done" },
  { label: "Appointment", date: "08 Mar", state: "current" },
  { label: "Report due", date: "20 Mar", state: "upcoming" },
] as const

const recordTypes = [
  { label: "Lab Reports", value: 10 },
  { label: "Imaging", value: 8 },
  { label: "Prescriptions", value: 4 },
  { label: "Others", value: 2 },
]

const records: { doc: string; type: string; source: string; date: string; status: string; tone: Tone }[] = [
  { doc: "CBC + Metabolic Panel", type: "Lab report", source: "Apex Diagnostics", date: "04 Mar 2026", status: "Processing", tone: "warn" },
  { doc: "Chest CT Scan Report", type: "Imaging", source: "Northstar Medical Centre", date: "28 Feb 2026", status: "Report available", tone: "info" },
  { doc: "Lipid Profile", type: "Lab report", source: "City Care Labs", date: "21 Feb 2026", status: "Completed", tone: "ok" },
]

function Donut() {
  const total = recordTypes.reduce((s, r) => s + r.value, 0)
  const r = 52
  const c = 2 * Math.PI * r
  // Cyan leads; remaining segments stay in quiet blue-grays.
  const shades = ["var(--cyan)", "color-mix(in srgb, var(--cyan) 45%, var(--text-3))", "color-mix(in srgb, var(--text-3) 85%, transparent)", "color-mix(in srgb, var(--text-3) 50%, transparent)"]
  let offset = 0
  return (
    <div className="flex flex-wrap items-center gap-6">
      <div className="relative h-[140px] w-[140px] flex-none">
        <svg viewBox="0 0 140 140" className="h-full w-full -rotate-90" role="img" aria-label={`${total} records in total`}>
          <circle cx="70" cy="70" r={r} fill="none" stroke="var(--border)" strokeWidth="14" />
          {recordTypes.map((t, i) => {
            const len = (t.value / total) * c
            const el = (
              <circle
                key={t.label}
                cx="70"
                cy="70"
                r={r}
                fill="none"
                stroke={shades[i]}
                strokeWidth="14"
                strokeDasharray={`${Math.max(len - 3, 0)} ${c - Math.max(len - 3, 0)}`}
                strokeDashoffset={-offset}
              />
            )
            offset += len
            return el
          })}
        </svg>
        <div className="absolute inset-0 grid place-content-center text-center">
          <span className="text-[26px] font-semibold leading-none">{total}</span>
          <span className="mt-1 text-[12px] text-ink-3">Total</span>
        </div>
      </div>
      <ul className="min-w-[160px] flex-1 space-y-3">
        {recordTypes.map((t, i) => (
          <li key={t.label} className="flex items-center gap-3 text-[13.5px]">
            <span className="h-2 w-2 flex-none rounded-full" style={{ background: shades[i] }} aria-hidden="true" />
            <span className="flex-1 text-ink-2">{t.label}</span>
            <span className="font-medium text-ink">{t.value}</span>
          </li>
        ))}
      </ul>
    </div>
  )
}

export function PatientDashboard() {
  return (
    <>
      <PageHeading
        eyebrow="Patient dashboard"
        title="Welcome back, Aarav"
        description="Your health records, appointments, and follow-ups in one place."
        action={
          <button type="button" className="btn btn-primary">
            <Upload aria-hidden="true" /> Upload medical record
          </button>
        }
      />

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <MetricCard icon={FileText} value="24" label="Medical documents" note="3 added this month" href="/patient/records" />
        <MetricCard icon={Calendar} value="2" label="Upcoming appointments" note="Next: 08 Mar 2026" href="/patient/appointments" />
        <MetricCard icon={Bell} value="3" label="Open follow-ups" note="1 due soon" href="/patient/passports" />
        <MetricCard icon={TrendingUp} value="8" label="Recent records" note="Updated this week" href="/patient/records" />
      </div>

      <div className="mt-4 grid grid-cols-1 gap-4 xl:grid-cols-[minmax(0,1.9fr)_minmax(0,1fr)]">
        <Panel title="Health timeline" description="Your recent activity and upcoming events." action={<ViewAll href="/patient/records" />}>
          <ol className="relative mt-6 grid grid-cols-5 gap-2 pb-2" aria-label="Health timeline">
            <span className="absolute left-[10%] right-[10%] top-[5px] h-px bg-line" aria-hidden="true" />
            {timeline.map((e) => (
              <li key={e.label} className="relative flex flex-col items-center text-center">
                <span
                  className={
                    e.state === "current"
                      ? "z-10 h-3 w-3 rounded-full bg-cyan shadow-[0_0_14px_var(--cyan)]"
                      : e.state === "done"
                        ? "z-10 h-2.5 w-2.5 rounded-full border border-line bg-ink-3"
                        : "z-10 h-2.5 w-2.5 rounded-full border border-line bg-[var(--bg-2)]"
                  }
                  aria-hidden="true"
                />
                <span className={`mt-4 text-[12.5px] ${e.state === "current" ? "font-medium text-ink" : "text-ink-2"}`}>
                  {e.label}
                  {e.state === "current" && <span className="sr-only"> (current)</span>}
                </span>
                <span className="mt-1 text-[12px] text-ink-3">{e.date}</span>
              </li>
            ))}
          </ol>
        </Panel>

        <Panel title="Record types">
          <Donut />
        </Panel>
      </div>

      <Panel
        className="mt-4"
        dense
        title="Recent medical records"
        description="Latest activity from your authorized workspace."
        action={<ViewAll href="/patient/records" />}
      >
        <div className="table-scroll">
          <table className="data-table">
            <thead>
              <tr>
                <th scope="col">Document</th>
                <th scope="col">Type</th>
                <th scope="col">Source</th>
                <th scope="col">Report date</th>
                <th scope="col">Status</th>
                <th scope="col">Actions</th>
              </tr>
            </thead>
            <tbody>
              {records.map((r) => (
                <tr key={r.doc}>
                  <td>{r.doc}</td>
                  <td>{r.type}</td>
                  <td>{r.source}</td>
                  <td>{r.date}</td>
                  <td>
                    <StatusBadge tone={r.tone}>{r.status}</StatusBadge>
                  </td>
                  <td>
                    <RowAction href="/patient/records" />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>
    </>
  )
}
