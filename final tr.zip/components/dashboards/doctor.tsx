import { Bell, ClipboardCheck, FileText, Users, UserCheck, Sparkles } from "lucide-react"
import { MetricCard, PageHeading, Panel, RowAction, StatusBadge, ViewAll, type Tone } from "@/components/parts"

const patients: { name: string; id: string; lastReport: string; open: string; status: string; tone: Tone }[] = [
  { name: "Aarav Rao", id: "P-10482", lastReport: "Chest CT · 28 Feb", open: "1 follow-up", status: "Review pending", tone: "warn" },
  { name: "Nisha Verma", id: "P-10377", lastReport: "Lipid profile · 26 Feb", open: "None", status: "Reviewed", tone: "ok" },
  { name: "Karan Mehta", id: "P-10215", lastReport: "HbA1c · 21 Feb", open: "2 follow-ups", status: "Overdue", tone: "bad" },
]

const loop: { step: string; detail: string; meta: string }[] = [
  { step: "Original clinical finding", detail: "4 mm right lower lobe nodule noted on chest CT.", meta: "Report · 28 Feb 2026" },
  { step: "Required follow-up", detail: "Repeat low-dose CT in 3 months.", meta: "Due 28 May 2026 · Owner: Dr. Meera S." },
  { step: "Subsequent evidence", detail: "No follow-up imaging received yet.", meta: "Awaiting upload" },
]

const followUps: { patient: string; item: string; due: string; owner: string; status: string; tone: Tone }[] = [
  { patient: "Karan Mehta", item: "Repeat HbA1c", due: "02 Mar 2026", owner: "Dr. Meera S.", status: "Overdue", tone: "bad" },
  { patient: "Aarav Rao", item: "Repeat low-dose CT", due: "28 May 2026", owner: "Dr. Meera S.", status: "Scheduled", tone: "info" },
  { patient: "Nisha Verma", item: "Lipid recheck", due: "20 Mar 2026", owner: "Dr. Arjun P.", status: "Due soon", tone: "warn" },
]

export function DoctorDashboard() {
  return (
    <>
      <PageHeading
        eyebrow="Clinician dashboard"
        title="Good evening, Dr. Meera"
        description="Patient records, pending reviews, and follow-ups that need your decision."
      />

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <MetricCard icon={Users} value="128" label="Accessible patients" note="Shared with consent" href="/doctor/patients" />
        <MetricCard icon={FileText} value="17" label="Open reports" note="5 new today" href="/doctor/records" />
        <MetricCard icon={ClipboardCheck} value="6" label="Pending reviews" note="2 marked urgent" href="/doctor/review-queue" />
        <MetricCard icon={Bell} value="9" label="Follow-ups due" note="3 overdue" href="/doctor/passports" />
      </div>

      <div className="mt-4 grid grid-cols-1 gap-4 xl:grid-cols-[minmax(0,1.5fr)_minmax(0,1fr)]">
        <Panel
          title="Clinical Loop Passport"
          description="Finding → follow-up → evidence → review, with an explicit human decision."
          action={<StatusBadge tone="warn">Open</StatusBadge>}
        >
          <ol className="space-y-3">
            {loop.map((s, i) => (
              <li key={s.step} className="glass-secondary flex gap-4 p-4">
                <span className="grid h-7 w-7 flex-none place-items-center rounded-full border border-line text-[12px] font-medium text-ink-2">
                  {i + 1}
                </span>
                <div className="min-w-0">
                  <p className="text-[12px] font-medium uppercase tracking-[0.08em] text-ink-3">{s.step}</p>
                  <p className="mt-1 text-[14px] text-ink">{s.detail}</p>
                  <p className="mt-1 text-[12.5px] text-ink-3">{s.meta}</p>
                </div>
              </li>
            ))}

            {/* AI suggestion: visually distinct, dashed, never styled as a decision */}
            <li className="flex gap-4 rounded-[14px] border border-dashed p-4" style={{ borderColor: "color-mix(in srgb, var(--blue) 45%, transparent)" }}>
              <span className="grid h-7 w-7 flex-none place-items-center rounded-full text-blue">
                <Sparkles className="h-4 w-4" aria-hidden="true" />
              </span>
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <StatusBadge tone="ai">AI suggestion · unconfirmed</StatusBadge>
                </div>
                <p className="mt-2 text-[14px] text-ink">Suggested: flag as high priority because the follow-up window closes in under 90 days.</p>
                <p className="mt-1 text-[12.5px] text-ink-3">Generated from the report text. It has no effect until a clinician decides.</p>
              </div>
            </li>

            {/* Human review decision */}
            <li className="glass-secondary flex flex-wrap items-center justify-between gap-3 p-4">
              <div>
                <p className="text-[12px] font-medium uppercase tracking-[0.08em] text-ink-3">Review decision</p>
                <p className="mt-1 text-[14px] text-ink">Awaiting clinician review</p>
              </div>
              <div className="flex gap-2">
                <button type="button" className="btn btn-secondary btn-sm">Request evidence</button>
                <button type="button" className="btn btn-primary btn-sm">
                  <UserCheck aria-hidden="true" /> Confirm decision
                </button>
              </div>
            </li>
          </ol>
        </Panel>

        <Panel title="Recent patient activity" description="Latest changes across accessible patients." action={<ViewAll href="/doctor/patients" />}>
          <ul className="divide-y divide-[var(--border)]">
            {[
              ["Aarav Rao", "Chest CT report added", "2 h ago"],
              ["Karan Mehta", "Follow-up marked overdue", "Yesterday"],
              ["Nisha Verma", "Review completed", "Yesterday"],
              ["Aarav Rao", "Shared access granted", "2 days ago"],
            ].map(([who, what, when]) => (
              <li key={who + what} className="flex items-center justify-between gap-3 py-3 text-[13.5px]">
                <span className="min-w-0">
                  <span className="block truncate text-ink">{who}</span>
                  <span className="block truncate text-ink-3">{what}</span>
                </span>
                <span className="flex-none text-[12.5px] text-ink-3">{when}</span>
              </li>
            ))}
          </ul>
        </Panel>
      </div>

      <Panel className="mt-4" dense title="Accessible patients" description="Records you have been given access to." action={<ViewAll href="/doctor/patients" />}>
        <div className="table-scroll">
          <table className="data-table">
            <thead>
              <tr>
                <th scope="col">Patient</th>
                <th scope="col">ID</th>
                <th scope="col">Latest report</th>
                <th scope="col">Open items</th>
                <th scope="col">Status</th>
                <th scope="col">Actions</th>
              </tr>
            </thead>
            <tbody>
              {patients.map((p) => (
                <tr key={p.id}>
                  <td>{p.name}</td>
                  <td>{p.id}</td>
                  <td>{p.lastReport}</td>
                  <td>{p.open}</td>
                  <td><StatusBadge tone={p.tone}>{p.status}</StatusBadge></td>
                  <td><RowAction href="/doctor/patients">Open</RowAction></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>

      <Panel className="mt-4" dense title="Follow-ups" description="Owner and due date for each open loop." action={<ViewAll href="/doctor/passports" />}>
        <div className="table-scroll">
          <table className="data-table">
            <thead>
              <tr>
                <th scope="col">Patient</th>
                <th scope="col">Follow-up</th>
                <th scope="col">Due</th>
                <th scope="col">Owner</th>
                <th scope="col">Status</th>
                <th scope="col">Actions</th>
              </tr>
            </thead>
            <tbody>
              {followUps.map((f) => (
                <tr key={f.patient + f.item}>
                  <td>{f.patient}</td>
                  <td>{f.item}</td>
                  <td>{f.due}</td>
                  <td>{f.owner}</td>
                  <td><StatusBadge tone={f.tone}>{f.status}</StatusBadge></td>
                  <td><RowAction href="/doctor/passports">Review</RowAction></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>
    </>
  )
}
