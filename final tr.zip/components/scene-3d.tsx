"use client"

import { useEffect, useRef } from "react"
import { gsap } from "gsap"

/**
 * Calm ambient background: a few large, soft glows drifting slowly at different
 * depths, with sparse dust specks floating upward. Raw WebGL, no dependencies.
 *
 * - Always moving, never busy: full drift cycles take 30 to 60 seconds.
 * - Depth parallax: near glows shift more than far ones when the pointer moves
 *   or the page scrolls (both eased, small amplitude).
 * - Dark and light palettes follow the `.dark` class on <html>.
 * - Performance: the scene is only soft gradients, so it renders at half
 *   resolution (the browser upscales it) and at 30fps, driven by the shared
 *   GSAP ticker so it never fights Lenis / ScrollTrigger for frames.
 * - prefers-reduced-motion draws one still frame. No WebGL -> CSS gradient stays.
 */

type Props = { intensity?: number }

const GLOW_VS = `
attribute vec2 aPos;
varying vec2 vUv;
void main() {
  vUv = aPos * 0.5 + 0.5;
  gl_Position = vec4(aPos, 0.0, 1.0);
}
`

// Five soft orbs. Each has a base position, depth (0 far .. 1 near), radius and colour slot.
const GLOW_FS = `
precision mediump float;
varying vec2 vUv;
uniform float uTime;
uniform float uAspect;
uniform vec2 uPar;
uniform float uScroll;
uniform float uK;
uniform vec3 uC0;
uniform vec3 uC1;
uniform vec3 uC2;

vec4 orb(vec2 p, vec2 base, float depth, float rad, float sp, float ph, vec3 col) {
  vec2 c = base;
  c.x *= uAspect * 0.8;
  c += vec2(sin(uTime * sp + ph), cos(uTime * sp * 0.8 + ph * 1.7)) * (0.14 + 0.1 * depth);
  c += uPar * (0.03 + 0.09 * depth);
  c.y += uScroll * (0.2 + 0.5 * depth);
  float r = rad * (1.0 + 0.06 * sin(uTime * 0.11 + ph * 3.0));
  float d = length(p - c) / r;
  float w = exp(-d * d * 1.6) * (0.55 + 0.45 * depth);
  return vec4(col * w, w);
}

void main() {
  vec2 p = (vUv * 2.0 - 1.0) * vec2(uAspect, 1.0);
  vec4 a = orb(p, vec2( 0.55,  0.55), 0.25, 0.95, 0.060, 0.0, uC0);
  vec4 b = orb(p, vec2(-0.70, -0.25), 0.55, 0.80, 0.050, 2.1, uC1);
  vec4 c = orb(p, vec2( 0.15, -0.70), 0.85, 0.60, 0.070, 4.2, uC2);
  vec4 d = orb(p, vec2(-0.35,  0.70), 0.40, 0.70, 0.045, 1.2, uC0);
  vec4 e = orb(p, vec2( 0.85, -0.15), 0.70, 0.55, 0.065, 3.3, uC1);
  vec4 s = a + b + c + d + e;
  float alpha = clamp(s.a * 0.62 * uK, 0.0, 0.62);
  vec3 col = s.rgb / max(s.a, 0.0001);
  gl_FragColor = vec4(col, alpha);
}
`

const DUST_VS = `
attribute vec3 aSeed;
uniform float uTime;
uniform float uScale;
uniform vec2 uPar;
uniform float uAspect;
varying float vA;
void main() {
  float rise = fract(aSeed.y + uTime * (0.006 + aSeed.z * 0.008));
  vec2 p;
  p.x = (aSeed.x * 2.0 - 1.0) + sin(uTime * 0.12 + aSeed.z * 20.0) * 0.03;
  p.y = rise * 2.4 - 1.2;
  p += uPar * (0.02 + aSeed.z * 0.06);
  gl_Position = vec4(p, 0.0, 1.0);
  gl_PointSize = (1.4 + aSeed.z * 2.2) * uScale;
  float twinkle = 0.55 + 0.45 * sin(uTime * 0.5 + aSeed.x * 40.0);
  vA = sin(rise * 3.14159) * twinkle * (0.35 + 0.65 * aSeed.z);
}
`

const DUST_FS = `
precision mediump float;
uniform vec3 uHi;
uniform float uK;
varying float vA;
void main() {
  float d = length(gl_PointCoord - 0.5);
  float soft = smoothstep(0.5, 0.0, d);
  gl_FragColor = vec4(uHi, soft * vA * 0.85 * uK);
}
`

// Theme palettes (0..1 rgb)
const DARK = {
  c0: [0.0, 0.72, 0.84],
  c1: [0.18, 0.4, 0.9],
  c2: [0.42, 0.28, 0.72],
  hi: [0.85, 0.96, 1.0],
  gain: 1,
}
const LIGHT = {
  c0: [0.0, 0.62, 0.75],
  c1: [0.25, 0.5, 0.9],
  c2: [0.55, 0.45, 0.82],
  hi: [0.1, 0.35, 0.5],
  gain: 0.75,
}

export function Scene3D({ intensity = 1 }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const gl = canvas.getContext("webgl", { alpha: true, antialias: false, premultipliedAlpha: false, powerPreference: "low-power" })
    if (!gl || gl.isContextLost()) return

    const compile = (type: number, src: string) => {
      const s = gl.createShader(type)!
      gl.shaderSource(s, src)
      gl.compileShader(s)
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) {
        // A lost context reports failure with an empty log; fall back to the CSS gradient silently.
        const log = gl.getShaderInfoLog(s)
        if (log && !gl.isContextLost()) console.error(log)
        return null
      }
      return s
    }
    const link = (vs: string, fs: string) => {
      const v = compile(gl.VERTEX_SHADER, vs)
      const f = compile(gl.FRAGMENT_SHADER, fs)
      if (!v || !f) return null
      const p = gl.createProgram()!
      gl.attachShader(p, v)
      gl.attachShader(p, f)
      gl.linkProgram(p)
      if (!gl.getProgramParameter(p, gl.LINK_STATUS)) {
        console.error(gl.getProgramInfoLog(p))
        return null
      }
      return p
    }

    const glowP = link(GLOW_VS, GLOW_FS)
    const dustP = link(DUST_VS, DUST_FS)
    if (!glowP || !dustP) return
    canvas.dataset.ready = "true"

    // Full-screen triangle for the glows
    const quad = gl.createBuffer()
    gl.bindBuffer(gl.ARRAY_BUFFER, quad)
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW)

    // Sparse dust (deterministic so it looks the same each load)
    const small = window.innerWidth < 720
    const DUST_N = small ? 26 : 60
    const seeds = new Float32Array(DUST_N * 3)
    let s0 = 11
    const rnd = () => ((s0 = (s0 * 16807) % 2147483647) - 1) / 2147483646
    for (let i = 0; i < seeds.length; i++) seeds[i] = rnd()
    const dustBuf = gl.createBuffer()
    gl.bindBuffer(gl.ARRAY_BUFFER, dustBuf)
    gl.bufferData(gl.ARRAY_BUFFER, seeds, gl.STATIC_DRAW)

    const g = {
      pos: gl.getAttribLocation(glowP, "aPos"),
      t: gl.getUniformLocation(glowP, "uTime"),
      asp: gl.getUniformLocation(glowP, "uAspect"),
      par: gl.getUniformLocation(glowP, "uPar"),
      sc: gl.getUniformLocation(glowP, "uScroll"),
      k: gl.getUniformLocation(glowP, "uK"),
      c0: gl.getUniformLocation(glowP, "uC0"),
      c1: gl.getUniformLocation(glowP, "uC1"),
      c2: gl.getUniformLocation(glowP, "uC2"),
    }
    const d = {
      seed: gl.getAttribLocation(dustP, "aSeed"),
      t: gl.getUniformLocation(dustP, "uTime"),
      s: gl.getUniformLocation(dustP, "uScale"),
      par: gl.getUniformLocation(dustP, "uPar"),
      asp: gl.getUniformLocation(dustP, "uAspect"),
      hi: gl.getUniformLocation(dustP, "uHi"),
      k: gl.getUniformLocation(dustP, "uK"),
    }

    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)")
    let palette = DARK
    const readTheme = () => {
      palette = document.documentElement.classList.contains("dark") ? DARK : LIGHT
    }
    readTheme()
    const themeObserver = new MutationObserver(() => {
      readTheme()
      if (reduced.matches) still()
    })
    themeObserver.observe(document.documentElement, { attributes: true, attributeFilter: ["class"] })

    // Soft gradients don't need native resolution: 0.5x is visually identical
    // and cuts fragment work by 75%.
    const RENDER_SCALE = 0.5
    let w = window.innerWidth
    let h = window.innerHeight
    const resize = (force = false) => {
      const nw = window.innerWidth
      const nh = window.innerHeight
      // Ignore mobile URL-bar show/hide: reallocating the canvas mid-scroll causes flicker and jank.
      if (!force && nw === w && Math.abs(nh - h) < 150) return
      w = nw
      h = nh
      canvas.width = Math.max(2, Math.floor(w * RENDER_SCALE))
      canvas.height = Math.max(2, Math.floor(h * RENDER_SCALE))
      gl.viewport(0, 0, canvas.width, canvas.height)
    }
    resize(true)

    // Eased pointer and scroll (very gentle)
    const target = { x: 0, y: 0, s: 0 }
    const cur = { x: 0, y: 0, s: 0 }
    const readScroll = () => {
      const max = document.documentElement.scrollHeight - window.innerHeight
      target.s = max > 0 ? Math.min(Math.max(window.scrollY / max, 0), 1) : 0
    }
    const onMove = (e: PointerEvent) => {
      target.x = (e.clientX / w) * 2 - 1
      target.y = -((e.clientY / h) * 2 - 1)
    }
    readScroll()

    gl.enable(gl.BLEND)
    gl.blendFuncSeparate(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA, gl.ONE, gl.ONE_MINUS_SRC_ALPHA)
    gl.clearColor(0, 0, 0, 0)

    // Time-based easing so motion looks the same at any frame rate.
    const ease = (rate: number, dt: number) => 1 - Math.pow(1 - rate, dt * 60)

    const draw = (t: number, dt: number) => {
      cur.x += (target.x - cur.x) * ease(0.025, dt)
      cur.y += (target.y - cur.y) * ease(0.025, dt)
      cur.s += (target.s - cur.s) * ease(0.035, dt)
      const aspect = w / h
      const k = intensity * palette.gain

      gl.clear(gl.COLOR_BUFFER_BIT)

      // soft glows
      gl.useProgram(glowP)
      gl.bindBuffer(gl.ARRAY_BUFFER, quad)
      gl.enableVertexAttribArray(g.pos)
      gl.vertexAttribPointer(g.pos, 2, gl.FLOAT, false, 0, 0)
      gl.uniform1f(g.t, t)
      gl.uniform1f(g.asp, aspect)
      gl.uniform2f(g.par, cur.x, cur.y)
      gl.uniform1f(g.sc, cur.s)
      gl.uniform1f(g.k, k)
      gl.uniform3fv(g.c0, palette.c0)
      gl.uniform3fv(g.c1, palette.c1)
      gl.uniform3fv(g.c2, palette.c2)
      gl.drawArrays(gl.TRIANGLES, 0, 3)
      gl.disableVertexAttribArray(g.pos)

      // dust
      gl.useProgram(dustP)
      gl.bindBuffer(gl.ARRAY_BUFFER, dustBuf)
      gl.enableVertexAttribArray(d.seed)
      gl.vertexAttribPointer(d.seed, 3, gl.FLOAT, false, 0, 0)
      gl.uniform1f(d.t, t)
      gl.uniform1f(d.s, RENDER_SCALE * 1.6)
      gl.uniform2f(d.par, cur.x, cur.y)
      gl.uniform1f(d.asp, aspect)
      gl.uniform3fv(d.hi, palette.hi)
      gl.uniform1f(d.k, k)
      gl.drawArrays(gl.POINTS, 0, DUST_N)
      gl.disableVertexAttribArray(d.seed)
    }

    // 30fps off the shared GSAP ticker (same loop Lenis and ScrollTrigger use).
    const FRAME = 1 / 30
    let last = -1
    let first = -1
    const tick = (time: number) => {
      if (last >= 0 && time - last < FRAME * 0.9) return
      if (first < 0) first = time
      const dt = last < 0 ? FRAME : Math.min(time - last, 0.1)
      last = time
      draw(time - first, dt)
    }
    let running = false
    const play = () => {
      if (reduced.matches || running) return
      running = true
      last = -1
      gsap.ticker.add(tick)
    }
    const pause = () => {
      if (!running) return
      running = false
      gsap.ticker.remove(tick)
    }
    // Reduced motion: one still frame (large dt snaps the easing to its target).
    const still = () => {
      pause()
      draw(8, 100)
    }
    const sync = () => (reduced.matches ? still() : play())
    sync()

    const onResize = () => {
      resize()
      if (reduced.matches) still()
    }
    const onScroll = () => {
      readScroll()
      if (reduced.matches) still()
    }

    window.addEventListener("pointermove", onMove, { passive: true })
    window.addEventListener("scroll", onScroll, { passive: true })
    window.addEventListener("resize", onResize)
    reduced.addEventListener("change", sync)

    return () => {
      pause()
      themeObserver.disconnect()
      window.removeEventListener("pointermove", onMove)
      window.removeEventListener("scroll", onScroll)
      window.removeEventListener("resize", onResize)
      reduced.removeEventListener("change", sync)
      delete canvas.dataset.ready
      // Free resources but keep the context alive: losing it would break the
      // remount React performs in Strict Mode (getContext returns the lost context).
      gl.deleteBuffer(quad)
      gl.deleteBuffer(dustBuf)
      gl.deleteProgram(glowP)
      gl.deleteProgram(dustP)
    }
  }, [intensity])

  return <canvas ref={canvasRef} className="scene-3d" aria-hidden="true" />
}
