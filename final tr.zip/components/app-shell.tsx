"use client"

import Link from "next/link"
import { useState } from "react"
import { usePathname, useRouter } from "next/navigation"
import { Bell, ChevronRight, LogOut, Menu, Search, X } from "lucide-react"
import { ROLES, type NavItem, type RoleKey } from "@/lib/roles"
import { ThemeToggle } from "@/components/theme-toggle"
import { Scene3D } from "@/components/scene-3d"
import { CursorLight } from "@/components/cursor-light"
import { cn } from "@/lib/utils"

function Wordmark() {
  return (
    <Link href="/" className="font-display inline-block px-1 text-[17px] font-semibold tracking-[0.04em] text-ink" aria-label="TRACE RELAY home">
      TRACE <span className="text-cyan">RELAY</span>
    </Link>
  )
}

function NavLink({ role, item, onNavigate }: { role: RoleKey; item: NavItem; onNavigate: () => void }) {
  const pathname = usePathname()
  const href = item.slug ? `/${role}/${item.slug}` : `/${role}`
  const active = pathname === href
  const Icon = item.icon
  return (
    <Link href={href} className="nav-item" aria-current={active ? "page" : undefined} onClick={onNavigate}>
      <Icon aria-hidden="true" />
      <span className="flex-1 truncate">{item.label}</span>
      {active && <ChevronRight className="!h-4 !w-4 text-ink-2" aria-hidden="true" />}
    </Link>
  )
}

function SidebarContent({ role, onNavigate }: { role: RoleKey; onNavigate: () => void }) {
  const cfg = ROLES[role]
  const router = useRouter()
  return (
    <div className="flex h-full flex-col">
      <div className="flex h-[66px] items-center px-5">
        <Wordmark />
      </div>

      <div className="px-5 pb-1">
        <p className="t-label leading-snug">Your medical history, connected across your care journey.</p>
      </div>

      <div className="px-3 pt-4">
        <p className="t-label px-2 pb-1.5" id="role-switch-label">Switch role (demo only)</p>
        <div role="group" aria-labelledby="role-switch-label" className="glass-secondary grid grid-cols-3 gap-1 p-1">
          {Object.values(ROLES).map((r) => (
            <Link
              key={r.key}
              href={`/${r.key}`}
              aria-current={r.key === role ? "true" : undefined}
              onClick={onNavigate}
              className={cn(
                "grid min-h-9 place-items-center rounded-lg px-1 text-center text-[12px] leading-tight transition-colors",
                r.key === role ? "bg-[var(--cyan-soft)] font-semibold text-ink" : "text-ink-2 hover:bg-[var(--row-hover)]",
              )}
            >
              {r.key === "doctor" ? "Doctor / Hospital" : r.key === "diagnostic" ? "Diagnostic Centre" : "Patient"}
            </Link>
          ))}
        </div>
      </div>

      <nav aria-label={`${cfg.label} navigation`} className="flex flex-1 flex-col px-3 pb-3">
        <p className="t-eyebrow px-3 pb-2 pt-5">{cfg.navLabel}</p>
        <div className="flex flex-col gap-1.5">
          {cfg.primary.map((item) => (
            <NavLink key={item.label} role={role} item={item} onNavigate={onNavigate} />
          ))}
        </div>

        <div className="mx-3 my-5 h-px bg-line" />

        <div className="flex flex-col gap-1.5">
          {cfg.secondary.map((item) => (
            <NavLink key={item.label} role={role} item={item} onNavigate={onNavigate} />
          ))}
        </div>

        <div className="mt-auto pt-6">
          <div className="glass-secondary flex items-center gap-3 p-3">
            <span className="grid h-10 w-10 flex-none place-items-center rounded-full border border-line bg-[var(--cyan-soft)] text-[13px] font-semibold">
              {cfg.profile.initials}
            </span>
            <span className="min-w-0 flex-1 leading-tight">
              <span className="block truncate text-[14px] font-medium">{cfg.profile.name}</span>
              <span className="block truncate text-[12.5px] text-ink-3">{cfg.profile.role}</span>
            </span>
            <button
              type="button"
              className="icon-btn h-8 w-8 flex-none"
              onClick={() => {
                onNavigate()
                router.push("/")
              }}
              aria-label="Log out"
              title="Log out"
            >
              <LogOut className="h-4 w-4" aria-hidden="true" />
            </button>
          </div>
        </div>
      </nav>
    </div>
  )
}

export function AppShell({ role, children }: { role: RoleKey; children: React.ReactNode }) {
  const cfg = ROLES[role]
  const [open, setOpen] = useState(false)
  const close = () => setOpen(false)

  return (
    <>
      <div className="app-bg" aria-hidden="true" />
      <Scene3D intensity={0.55} />
      <CursorLight />

      <div className="flex min-h-screen gap-5 p-3 lg:p-5">
        {/* Desktop sidebar */}
        <aside data-lenis-prevent className="glass sticky top-5 hidden h-[calc(100vh-40px)] w-[290px] flex-none overflow-y-auto lg:block xl:w-[290px]">
          <SidebarContent role={role} onNavigate={close} />
        </aside>

        {/* Mobile drawer */}
        {open && (
          <div className="fixed inset-0 z-50 lg:hidden" role="dialog" aria-modal="true" aria-label="Navigation">
            <button className="absolute inset-0 bg-black/60" aria-label="Close navigation" onClick={close} />
            <aside data-lenis-prevent className="glass-float absolute inset-y-3 left-3 w-[290px] max-w-[85vw] overflow-y-auto">
              <button className="icon-btn absolute right-2 top-2.5" onClick={close} aria-label="Close navigation">
                <X />
              </button>
              <SidebarContent role={role} onNavigate={close} />
            </aside>
          </div>
        )}

        <div className="flex min-w-0 flex-1 flex-col">
          {/* Header */}
          <header className="flex h-[66px] flex-none items-center gap-3 lg:h-[70px]">
            <button className="icon-btn lg:hidden" onClick={() => setOpen(true)} aria-label="Open navigation">
              <Menu />
            </button>
            <label className="search-field max-w-[640px] flex-1">
              <Search className="h-[18px] w-[18px] flex-none text-ink-2" aria-hidden="true" />
              <span className="sr-only">Search</span>
              <input type="search" placeholder={cfg.searchPlaceholder} aria-label={cfg.searchPlaceholder} />
            </label>
            <div className="ml-auto flex items-center gap-1">
              <button className="icon-btn relative" aria-label="Notifications">
                <Bell />
                <span className="absolute right-2.5 top-2.5 h-1.5 w-1.5 rounded-full bg-cyan" aria-hidden="true" />
              </button>
              <ThemeToggle />
              <span
                className="ml-1 grid h-10 w-10 place-items-center rounded-full border border-line bg-[var(--surface)] text-[13px] font-semibold"
                aria-label={`Signed in as ${cfg.profile.name}`}
              >
                {cfg.profile.initials}
              </span>
            </div>
          </header>

          <main className={cn("flex-1 pb-6 pt-2 lg:px-3")}>{children}</main>
        </div>
      </div>
    </>
  )
}
