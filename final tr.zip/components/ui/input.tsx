import * as React from "react"
import { cn } from "@/lib/utils"
export function Input({ className, type, ...props }: React.ComponentProps<"input">) { return <input type={type} className={cn("flex h-9 w-full rounded-md border bg-transparent px-3 py-1 text-sm shadow-sm", className)} {...props} /> }
