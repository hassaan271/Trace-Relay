import * as React from "react"
import { cn } from "@/lib/utils"
export function Textarea({ className, ...props }: React.ComponentProps<"textarea">) { return <textarea className={cn("flex min-h-20 w-full rounded-md border bg-transparent px-3 py-2 text-sm", className)} {...props} /> }
