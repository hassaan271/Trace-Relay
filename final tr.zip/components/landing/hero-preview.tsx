import { Bell, CalendarCheck, FileText } from "lucide-react"
import { ROLES } from "@/lib/roles"

const METRICS = [
  { label: "Medical documents", value: "24", icon: FileText },
  { label: "Upcoming appointments", value: "2", icon: CalendarCheck },
  { label: "Open follow-ups", value: "3", icon: Bell },
]

const ROWS = [
  { item: "Blood panel, March", from: "Northstar Lab", badge: "badge-ok", status: "Processed" },
  { item: "Cardiology prescription", from: "Dr. Meera S.", badge: "badge-info", status: "Processing" },
  { item: "Chest X-ray follow-up", from: "Northstar Lab", badge: "badge-warn", status: "Due soon" },
]

/** Static, decorative preview of the patient dashboard. */
export function HeroPreview() {
  const nav = ROLES.patient.primary.slice(0, 6)
  return (
    <div className="glass preview-frame" aria-hidden="true">
      <div className="preview-inner grid overflow-hidden md:grid-cols-[200px_1fr]">
        <div className="hidden flex-col gap-1 border-r border-line p-3 md:flex">
          <span className="font-display px-2 pb-3 pt-1 text-[15px] font-semibold">
            Trace <span className="text-cyan">Relay</span>
          </span>
          {nav.map((n, i) => (
            <span key={n.slug} className="nav-item !h-10 !text-[13.5px]" aria-current={i === 0 ? "page" : undefined}>
              <n.icon />
              <span className="truncate">{n.label}</span>
            </span>
          ))}
        </div>
        <div className="flex flex-col gap-5 p-5 sm:p-6">
          <div>
            <p className="t-section">Welcome back, Aarav</p>
            <p className="t-body">Your records and follow-ups, organized in one place.</p>
          </div>
          <div className="grid gap-3 sm:grid-cols-3">
            {METRICS.map((m) => (
              <div key={m.label} className="glass-secondary flex flex-col gap-3 p-4">
                <m.icon className="h-[18px] w-[18px] text-cyan" />
                <span className="t-metric">{m.value}</span>
                <span className="t-label">{m.label}</span>
              </div>
            ))}
          </div>
          <div className="table-scroll">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Document</th>
                  <th>Source</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {ROWS.map((r) => (
                  <tr key={r.item}>
                    <td>{r.item}</td>
                    <td>{r.from}</td>
                    <td>
                      <span className={`badge ${r.badge}`}>{r.status}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  )
}
