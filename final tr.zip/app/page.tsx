import { TraceLogin } from "@/components/trace-login"

export default function HomePage() {
  return <TraceLogin />
}
