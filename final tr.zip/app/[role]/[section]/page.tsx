import { notFound } from "next/navigation"
import { ROLES, isRole } from "@/lib/roles"
import { SECTIONS } from "@/lib/sections"
import { PageHeading, Panel } from "@/components/parts"

export function generateStaticParams() {
  return Object.values(ROLES).flatMap((r) =>
    [...r.primary, ...r.secondary].filter((i) => i.slug).map((i) => ({ role: r.key, section: i.slug })),
  )
}

export default async function SectionPage({ params }: { params: Promise<{ role: string; section: string }> }) {
  const { role, section } = await params
  if (!isRole(role)) notFound()
  const cfg = ROLES[role]
  const item = [...cfg.primary, ...cfg.secondary].find((i) => i.slug === section)
  if (!item) notFound()
  const spec = SECTIONS[role][section]

  return (
    <>
      <PageHeading eyebrow={cfg.label} title={item.label} description={spec?.description ?? "This section is not built yet."} />
      <Panel
        title="What this page covers"
        description={spec?.primaryAction ? `Main action: ${spec.primaryAction}.` : undefined}
      >
        <ul className="grid gap-3">
          {spec?.covers.map((c) => (
            <li key={c} className="t-body flex gap-3">
              <span className="mt-2 h-1.5 w-1.5 flex-none rounded-full bg-cyan" aria-hidden="true" />
              {c}
            </li>
          ))}
        </ul>
        <p className="t-label mt-6">Not connected to a backend yet, so nothing on this page can be saved or sent.</p>
      </Panel>
    </>
  )
}
