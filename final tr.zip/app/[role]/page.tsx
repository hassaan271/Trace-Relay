import { notFound } from "next/navigation"
import { isRole } from "@/lib/roles"
import { PatientDashboard } from "@/components/dashboards/patient"
import { DoctorDashboard } from "@/components/dashboards/doctor"
import { DiagnosticDashboard } from "@/components/dashboards/diagnostic"

export default async function RoleHome({ params }: { params: Promise<{ role: string }> }) {
  const { role } = await params
  if (!isRole(role)) notFound()
  if (role === "patient") return <PatientDashboard />
  if (role === "doctor") return <DoctorDashboard />
  return <DiagnosticDashboard />
}
