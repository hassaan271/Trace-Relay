import { notFound } from "next/navigation"
import { AppShell } from "@/components/app-shell"
import { ROLES, isRole } from "@/lib/roles"

export function generateStaticParams() {
  return Object.keys(ROLES).map((role) => ({ role }))
}

export default async function RoleLayout({
  children,
  params,
}: {
  children: React.ReactNode
  params: Promise<{ role: string }>
}) {
  const { role } = await params
  if (!isRole(role)) notFound()
  return <AppShell role={role}>{children}</AppShell>
}
