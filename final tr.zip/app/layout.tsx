import type { Metadata, Viewport } from "next"
import { Space_Grotesk } from "next/font/google"
import "@fontsource-variable/inter"
import "./globals.css"
import { MotionProvider } from "@/components/motion-provider"

const display = Space_Grotesk({ subsets: ["latin"], variable: "--font-space-grotesk", display: "swap" })

export const metadata: Metadata = {
  title: "TRACE RELAY",
  description: "Healthcare records, follow-ups, and clinical continuity in one place.",
}

export const viewport: Viewport = {
  themeColor: "#05080d",
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`dark motion ${display.variable}`} suppressHydrationWarning>
      <body>
        <MotionProvider />
        {children}
      </body>
    </html>
  )
}
