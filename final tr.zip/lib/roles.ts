import {
  Bell,
  Bot,
  Building2,
  Calendar,
  CalendarClock,
  ClipboardCheck,
  FileText,
  FlaskConical,
  FolderOpen,
  Home,
  LayoutDashboard,
  RefreshCcw,
  ScanLine,
  Settings,
  Stethoscope,
  Users,
  type LucideIcon,
} from "lucide-react"

export type RoleKey = "patient" | "doctor" | "diagnostic"

export type NavItem = { slug: string; label: string; icon: LucideIcon }

export type RoleConfig = {
  key: RoleKey
  label: string
  navLabel: string
  searchPlaceholder: string
  profile: { name: string; initials: string; role: string }
  primary: NavItem[]
  secondary: NavItem[]
}

export const ROLES: Record<RoleKey, RoleConfig> = {
  patient: {
    key: "patient",
    label: "Patient",
    navLabel: "Patient",
    searchPlaceholder: "Search records, reports, or appointments…",
    profile: { name: "Aarav R.", initials: "AR", role: "Patient" },
    primary: [
      { slug: "", label: "Overview", icon: Home },
      { slug: "records", label: "My Medical Records", icon: FileText },
      { slug: "assistant", label: "AI Health Assistant", icon: Bot },
      { slug: "appointments", label: "Appointments & Scans", icon: Calendar },
      { slug: "passports", label: "Clinical Loop Passports", icon: RefreshCcw },
      { slug: "shared-access", label: "Shared Access", icon: Users },
      { slug: "notifications", label: "Notifications", icon: Bell },
    ],
    secondary: [
      { slug: "settings", label: "Profile & Settings", icon: Settings },
    ],
  },
  doctor: {
    key: "doctor",
    label: "Doctor / Hospital",
    navLabel: "Clinician",
    searchPlaceholder: "Search patients, reports, or follow-ups…",
    profile: { name: "Dr. Meera S.", initials: "MS", role: "Physician" },
    primary: [
      { slug: "", label: "Overview", icon: LayoutDashboard },
      { slug: "patients", label: "Patients", icon: Users },
      { slug: "records", label: "Medical Records", icon: FolderOpen },
      { slug: "passports", label: "Clinical Loop Passports", icon: RefreshCcw },
      { slug: "review-queue", label: "Review Queue", icon: ClipboardCheck },
      { slug: "follow-up-tracking", label: "Follow-up Tracking", icon: CalendarClock },
      { slug: "notifications", label: "Notifications", icon: Bell },
    ],
    secondary: [
      { slug: "settings", label: "Hospital Settings", icon: Building2 },
    ],
  },
  diagnostic: {
    key: "diagnostic",
    label: "Diagnostic Centre",
    navLabel: "Diagnostics",
    searchPlaceholder: "Search patients, bookings, or reports…",
    profile: { name: "Northstar Lab", initials: "NL", role: "Diagnostic Centre" },
    primary: [
      { slug: "", label: "Overview", icon: LayoutDashboard },
      { slug: "bookings", label: "Appointments & Bookings", icon: CalendarClock },
      { slug: "scan-tracking", label: "Scan Tracking", icon: ScanLine },
      { slug: "reports", label: "Reports", icon: FlaskConical },
      { slug: "follow-up-queue", label: "Follow-up Queue", icon: Stethoscope },
      { slug: "notifications", label: "Notifications", icon: Bell },
    ],
    secondary: [
      { slug: "settings", label: "Centre Settings", icon: Building2 },
    ],
  },
}

export function isRole(value: string): value is RoleKey {
  return value in ROLES
}
