import type { RoleKey } from "@/lib/roles"

/** What each page is specified to contain. Used until a page is connected to real data. */
export type SectionSpec = { description: string; primaryAction?: string; covers: string[] }

export const SECTIONS: Record<RoleKey, Record<string, SectionSpec>> = {
  patient: {
    records: {
      description: "Upload reports and prescriptions once, then find them by keyword or date.",
      primaryAction: "Upload Record",
      covers: [
        "Records table: name, type, hospital or centre, report date, upload date, processing status",
        "Row actions: view, inspect details, share, download or print where permitted",
        "Upload form: file, document type, source, report date, notes, with validation and error states",
        "Search such as “blood reports from March”, pointing to the matching image",
      ],
    },
    assistant: {
      description: "Ask about your own records. Answers are grounded in the documents you have uploaded.",
      covers: [
        "Chat with message history, loading state and an empty state",
        "Source-document references with every answer",
        "Suggestions: blood reports from March, most recent prescription, open follow-ups, report for a previous scan",
        "Clear unavailable state when the AI service is not connected",
      ],
    },
    appointments: {
      description: "Appointments, scheduled investigations and completed scans in one list.",
      primaryAction: "View Appointments",
      covers: [
        "Booking or tracking ID, date and time, diagnostic centre, status",
        "Upcoming appointments, scheduled investigations and completed scans",
        "View details for every entry",
      ],
    },
    passports: {
      description: "Follow-up cases created from your reports, each with an owner and a status.",
      covers: [
        "Passport ID, original finding, required action, due date, responsible provider, status, last update",
        "Statuses: Open, Due Soon, Overdue, Awaiting Review, Completed",
        "Passport detail: original report, linked later reports, review history where permitted",
        "Read-only for patients. Reviewer controls stay with authorized clinicians",
      ],
    },
    "shared-access": {
      description: "Choose who can see your records, and take access back at any time.",
      primaryAction: "Grant Access",
      covers: [
        "Authorized doctor or organization, scope shared, status, expiry date",
        "Grant and revoke access, with confirmation before revoking",
        "QR code or link sharing for a doctor. View only unless you allow download",
        "No public links to private documents",
      ],
    },
    notifications: {
      description: "Reminders and updates about your care.",
      covers: [
        "Appointment reminders and follow-up due notices",
        "Newly available reports and access permission updates",
        "Read and unread states, with an empty state",
      ],
    },
    settings: {
      description: "Your profile, preferences and privacy.",
      covers: ["Profile and contact details", "Account and notification preferences", "Privacy and sharing settings"],
    },
  },
  doctor: {
    patients: {
      description: "Patients who have shared their records with you.",
      primaryAction: "Add or Link Patient",
      covers: [
        "Searchable list: patient, hospital identifier, latest activity, open follow-ups, record availability",
        "View patient, view authorized records, create or link a follow-up case",
        "Only patients who gave consent appear",
        "Patient detail: timeline from original finding to follow-up and later evidence",
      ],
    },
    records: {
      description: "Reports from patients who shared access with you.",
      primaryAction: "Upload Report",
      covers: [
        "Searchable table with filters for document type, patient and report date",
        "Processing status and source hospital or diagnostic centre",
        "View document and inspect extracted information",
      ],
    },
    passports: {
      description: "Every follow-up your hospital is tracking.",
      primaryAction: "Create Passport",
      covers: [
        "Passport ID, patient, original finding, required follow-up, due date, responsible party, status, last updated",
        "Filters: Open, Due Soon, Overdue, Awaiting Review, Completed",
        "Search by passport ID or patient",
        "Create form: patient, source report, finding, follow-up, due date, assignee, notes. Nothing is filled in by guesswork",
      ],
    },
    "review-queue": {
      description: "Evidence waiting for a clinician's decision.",
      covers: [
        "Passport ID, patient, required follow-up, candidate report, evidence excerpt, AI match explanation, status",
        "Open evidence, view original report, view passport",
        "Accept or reject a proposed match, or request further review",
        "Accepting a match does not close a passport. Uncertain cases stay open",
      ],
    },
    "follow-up-tracking": {
      description: "Upcoming, due today, overdue and completed follow-ups.",
      covers: ["Summary counts for each group", "Due dates, assigned parties and links to passports", "Sorting and filtering"],
    },
    notifications: {
      description: "Updates on your patients and cases.",
      covers: ["New reports and evidence on open passports", "Follow-ups due or overdue", "Read and unread states, with an empty state"],
    },
    settings: {
      description: "Hospital profile and access.",
      covers: ["Hospital profile", "Staff and organization membership", "Access permissions and notification preferences"],
    },
  },
  diagnostic: {
    bookings: {
      description: "Investigation bookings for your centre.",
      primaryAction: "New Booking",
      covers: [
        "Booking ID, patient, investigation, date and time, status, department",
        "Search, date filter and status filter",
        "View booking and update status when authorized",
        "Only the patient details a booking needs",
      ],
    },
    "scan-tracking": {
      description: "Follow each investigation from booking to report.",
      covers: [
        "Tracking ID, booking ID, patient, investigation, scheduled date, report availability",
        "Statuses: Scheduled, Checked In, In Progress, Completed, Report Available, Cancelled",
        "Details for every record",
      ],
    },
    reports: {
      description: "Reports your centre has produced and delivered.",
      primaryAction: "Upload Report",
      covers: [
        "Report ID, patient, investigation, date, report status, upload date, delivery status",
        "Upload with file validation and metadata, stored privately",
        "Associate a report with a booking, or with a candidate passport where authorized",
      ],
    },
    "follow-up-queue": {
      description: "Follow-up investigations requested by clinicians.",
      covers: [
        "Passport ID, patient, required investigation, due date, related booking or report, status",
        "Inspect a follow-up, coordinate the investigation, upload later evidence",
        "A completed test does not close a case. Closure stays with the clinical review",
      ],
    },
    notifications: {
      description: "Reminders and requests for your centre.",
      covers: ["Investigation reminders and pending report uploads", "Follow-up requests and booking changes", "Read and unread states, with an empty state"],
    },
    settings: {
      description: "Centre profile and services.",
      covers: ["Centre profile", "Departments or services", "Staff membership and notification preferences"],
    },
  },
}
