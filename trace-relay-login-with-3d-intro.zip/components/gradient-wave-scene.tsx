"use client"

import { useEffect, useRef } from "react"
import * as THREE from "three"
import gsap from "gsap"

/**
 * Live 3D "Gradient Wave" background.
 * A large, softly displaced plane whose slow swells are shaded with a smooth
 * three-tone gradient. Recoloured to Trace Relay's pale cyan / sky-blue tones
 * (light) and deep teal-navy (dark). The pointer gently lifts the surface and
 * shifts the camera; everything is eased so motion stays calm.
 * DPR capped, paused when the tab is hidden, near-static for reduced motion.
 */

type Palette = { hi: string; base: string; shade: string; fog: string; hiAmt: number }

const PALETTES: Record<"light" | "dark", Palette> = {
  light: { hi: "#f6fbfd", base: "#b7dbea", shade: "#86bcd6", fog: "#dbe7ee", hiAmt: 0.95 },
  dark: { hi: "#1d7a8f", base: "#0b3a4f", shade: "#062233", fog: "#061520", hiAmt: 0.55 },
}

const NOISE = /* glsl */ `
  vec3 mod289(vec3 x){ return x - floor(x * (1.0/289.0)) * 289.0; }
  vec4 mod289(vec4 x){ return x - floor(x * (1.0/289.0)) * 289.0; }
  vec4 permute(vec4 x){ return mod289(((x*34.0)+1.0)*x); }
  vec4 taylorInvSqrt(vec4 r){ return 1.79284291400159 - 0.85373472095314 * r; }
  float snoise(vec3 v){
    const vec2 C = vec2(1.0/6.0, 1.0/3.0);
    const vec4 D = vec4(0.0, 0.5, 1.0, 2.0);
    vec3 i = floor(v + dot(v, C.yyy));
    vec3 x0 = v - i + dot(i, C.xxx);
    vec3 g = step(x0.yzx, x0.xyz);
    vec3 l = 1.0 - g;
    vec3 i1 = min(g.xyz, l.zxy);
    vec3 i2 = max(g.xyz, l.zxy);
    vec3 x1 = x0 - i1 + C.xxx;
    vec3 x2 = x0 - i2 + C.yyy;
    vec3 x3 = x0 - D.yyy;
    i = mod289(i);
    vec4 p = permute(permute(permute(i.z + vec4(0.0, i1.z, i2.z, 1.0)) + i.y + vec4(0.0, i1.y, i2.y, 1.0)) + i.x + vec4(0.0, i1.x, i2.x, 1.0));
    float n_ = 0.142857142857;
    vec3 ns = n_ * D.wyz - D.xzx;
    vec4 j = p - 49.0 * floor(p * ns.z * ns.z);
    vec4 x_ = floor(j * ns.z);
    vec4 y_ = floor(j - 7.0 * x_);
    vec4 x = x_ * ns.x + ns.yyyy;
    vec4 y = y_ * ns.x + ns.yyyy;
    vec4 h = 1.0 - abs(x) - abs(y);
    vec4 b0 = vec4(x.xy, y.xy);
    vec4 b1 = vec4(x.zw, y.zw);
    vec4 s0 = floor(b0) * 2.0 + 1.0;
    vec4 s1 = floor(b1) * 2.0 + 1.0;
    vec4 sh = -step(h, vec4(0.0));
    vec4 a0 = b0.xzyw + s0.xzyw * sh.xxyy;
    vec4 a1 = b1.xzyw + s1.xzyw * sh.zzww;
    vec3 p0 = vec3(a0.xy, h.x);
    vec3 p1 = vec3(a0.zw, h.y);
    vec3 p2 = vec3(a1.xy, h.z);
    vec3 p3 = vec3(a1.zw, h.w);
    vec4 norm = taylorInvSqrt(vec4(dot(p0,p0), dot(p1,p1), dot(p2,p2), dot(p3,p3)));
    p0 *= norm.x; p1 *= norm.y; p2 *= norm.z; p3 *= norm.w;
    vec4 m = max(0.6 - vec4(dot(x0,x0), dot(x1,x1), dot(x2,x2), dot(x3,x3)), 0.0);
    m = m * m;
    return 42.0 * dot(m*m, vec4(dot(p0,x0), dot(p1,x1), dot(p2,x2), dot(p3,x3)));
  }
`

const VERT = /* glsl */ `
  uniform float uTime;
  uniform vec2 uPointer;
  uniform float uPointerAmt;
  varying vec3 vNormal;
  varying float vH;
  varying float vFade;
  ${NOISE}

  // long, slow ridges: stretched along x, tighter along z
  float height(vec2 p) {
    float t = uTime;
    float h = snoise(vec3(p.x * 0.055, p.y * 0.11, t * 0.10)) * 2.4;
    h += snoise(vec3(p.x * 0.11 + 4.0, p.y * 0.2, t * 0.16 + 7.0)) * 0.9;
    float d = distance(p, uPointer);
    h += exp(-d * d * 0.012) * sin(d * 0.55 - t * 1.1) * 0.55 * uPointerAmt;
    return h;
  }

  void main() {
    vec3 p = position;
    float e = 0.6;
    float h = height(p.xz);
    float hx = height(p.xz + vec2(e, 0.0));
    float hz = height(p.xz + vec2(0.0, e));
    vNormal = normalize(vec3(-(hx - h) / e * 1.9, 1.0, -(hz - h) / e * 1.9));
    p.y += h;
    vH = h;
    vFade = smoothstep(0.0, 1.0, 1.0 - abs(position.x) / 56.0)
          * smoothstep(0.0, 1.0, 1.0 - (-position.z) / 62.0)
          * smoothstep(0.0, 1.0, (position.z + 34.0) / 10.0);
    gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);
  }
`

const FRAG = /* glsl */ `
  precision mediump float;
  uniform vec3 uHi;
  uniform vec3 uBase;
  uniform vec3 uShade;
  uniform vec3 uFog;
  uniform float uHiAmt;
  varying vec3 vNormal;
  varying float vH;
  varying float vFade;

  void main() {
    vec3 n = normalize(vNormal);
    float lit = dot(n, normalize(vec3(-0.35, 0.85, 0.45))) * 0.5 + 0.5;
    float tone = smoothstep(0.38, 0.9, lit) * 0.8 + smoothstep(-1.6, 2.2, vH) * 0.2;
    vec3 col = mix(uShade, uBase, smoothstep(0.1, 0.6, tone));
    col = mix(col, uHi, smoothstep(0.58, 1.0, tone) * uHiAmt);
    col = mix(uFog, col, vFade);
    gl_FragColor = vec4(col, vFade);
    #include <colorspace_fragment>
  }
`

export default function GradientWaveScene({ theme }: { theme: "light" | "dark" }) {
  const hostRef = useRef<HTMLDivElement>(null)
  const apiRef = useRef<{ setTheme: (t: "light" | "dark", animate: boolean) => void } | null>(null)
  const themeRef = useRef(theme)
  themeRef.current = theme

  useEffect(() => {
    const host = hostRef.current
    if (!host) return

    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches
    let renderer: THREE.WebGLRenderer
    try {
      renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true, powerPreference: "high-performance" })
    } catch {
      return // the CSS gradient behind stays as the fallback
    }
    const dpr = Math.min(window.devicePixelRatio || 1, 1.5)
    renderer.setPixelRatio(dpr)
    renderer.setClearColor(0x000000, 0)
    host.appendChild(renderer.domElement)
    renderer.domElement.style.cssText = "display:block;width:100%;height:100%"

    const scene = new THREE.Scene()
    const camera = new THREE.PerspectiveCamera(50, 1, 0.1, 220)
    const camBase = new THREE.Vector3(0, 9, 20)
    camera.position.copy(camBase)
    camera.lookAt(0, 0, -8)

    const geo = new THREE.PlaneGeometry(130, 90, 200, 140)
    geo.rotateX(-Math.PI / 2)
    geo.translate(0, 0, -24)

    const pal0 = PALETTES[themeRef.current]
    const uniforms = {
      uTime: { value: 0 },
      uPointer: { value: new THREE.Vector2(0, -6) },
      uPointerAmt: { value: 0 },
      uHi: { value: new THREE.Color(pal0.hi) },
      uBase: { value: new THREE.Color(pal0.base) },
      uShade: { value: new THREE.Color(pal0.shade) },
      uFog: { value: new THREE.Color(pal0.fog) },
      uHiAmt: { value: pal0.hiAmt },
    }
    const mat = new THREE.ShaderMaterial({ uniforms, vertexShader: VERT, fragmentShader: FRAG, transparent: true, depthWrite: false })
    scene.add(new THREE.Mesh(geo, mat))

    // pointer / tilt: always eased, never snapped
    const target = { x: 0, y: 0 }
    const eased = { x: 0, y: 0 }
    const world = new THREE.Vector2(0, -6)
    let amtTarget = 0
    const onMove = (e: PointerEvent) => {
      target.x = (e.clientX / window.innerWidth) * 2 - 1
      target.y = (e.clientY / window.innerHeight) * 2 - 1
      amtTarget = reduced ? 0 : 1
    }
    const onLeave = () => { amtTarget = 0 }
    const onTilt = (e: DeviceOrientationEvent) => {
      if (e.gamma == null || e.beta == null) return
      target.x = Math.max(-1, Math.min(1, e.gamma / 30))
      target.y = Math.max(-1, Math.min(1, (e.beta - 45) / 30))
    }
    window.addEventListener("pointermove", onMove, { passive: true })
    document.addEventListener("pointerleave", onLeave)
    if (!reduced) window.addEventListener("deviceorientation", onTilt, { passive: true })

    const resize = () => {
      const w = host.clientWidth || window.innerWidth
      const h = host.clientHeight || window.innerHeight
      renderer.setSize(w, h, false)
      camera.aspect = w / h
      camera.fov = w / h < 0.8 ? 66 : 50
      camera.updateProjectionMatrix()
    }
    resize()
    const ro = new ResizeObserver(resize)
    ro.observe(host)

    const applyTheme = (t: "light" | "dark", animate: boolean) => {
      const p = PALETTES[t]
      const duration = animate ? 1.6 : 0
      const to = (c: THREE.Color, hex: string) => {
        const n = new THREE.Color(hex)
        gsap.to(c, { r: n.r, g: n.g, b: n.b, duration, ease: "sine.inOut", overwrite: true })
      }
      to(uniforms.uHi.value, p.hi)
      to(uniforms.uBase.value, p.base)
      to(uniforms.uShade.value, p.shade)
      to(uniforms.uFog.value, p.fog)
      gsap.to(uniforms.uHiAmt, { value: p.hiAmt, duration, ease: "sine.inOut", overwrite: true })
    }
    apiRef.current = { setTheme: applyTheme }
    applyTheme(themeRef.current, false)

    let last = performance.now()
    const delta = () => { const n = performance.now(); const d = (n - last) / 1000; last = n; return d }
    let raf = 0
    let running = true
    const timeScale = reduced ? 0.1 : 1
    const plane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0)
    const ray = new THREE.Raycaster()
    const hit = new THREE.Vector3()
    const ndc = new THREE.Vector2()

    const frame = () => {
      raf = requestAnimationFrame(frame)
      const dt = Math.min(delta(), 0.05)
      uniforms.uTime.value += dt * timeScale

      const k = 1 - Math.exp(-dt * 2.0)
      eased.x += (target.x - eased.x) * k
      eased.y += (target.y - eased.y) * k
      camera.position.x = camBase.x + eased.x * 3.5
      camera.position.y = camBase.y - eased.y * 1.4
      camera.lookAt(eased.x * 1.5, 0, -8)

      ndc.set(eased.x, -eased.y)
      ray.setFromCamera(ndc, camera)
      if (ray.ray.intersectPlane(plane, hit)) world.lerp(new THREE.Vector2(hit.x, hit.z), 1 - Math.exp(-dt * 3))
      uniforms.uPointer.value.copy(world)
      uniforms.uPointerAmt.value += (amtTarget - uniforms.uPointerAmt.value) * (1 - Math.exp(-dt * 1.5))

      renderer.render(scene, camera)
    }
    const start = () => { if (!running) { running = true; delta(); raf = requestAnimationFrame(frame) } }
    const stop = () => { running = false; cancelAnimationFrame(raf) }
    const onVis = () => (document.hidden ? stop() : start())
    document.addEventListener("visibilitychange", onVis)
    raf = requestAnimationFrame(frame)

    return () => {
      stop()
      document.removeEventListener("visibilitychange", onVis)
      window.removeEventListener("pointermove", onMove)
      document.removeEventListener("pointerleave", onLeave)
      window.removeEventListener("deviceorientation", onTilt)
      ro.disconnect()
      gsap.killTweensOf([uniforms.uHi.value, uniforms.uBase.value, uniforms.uShade.value, uniforms.uFog.value, uniforms.uHiAmt])
      geo.dispose(); mat.dispose(); renderer.dispose()
      renderer.domElement.remove()
      apiRef.current = null
    }
  }, [])

  useEffect(() => { apiRef.current?.setTheme(theme, true) }, [theme])

  return <div ref={hostRef} className="calm-scene-host" aria-hidden="true" />
}
