"use client"

import { useEffect, useRef } from "react"
import * as THREE from "three"
import gsap from "gsap"

/**
 * Calm 3D background: a slow, drifting field of soft light points shaped like
 * a gentle ocean swell, with a few blurred orbs floating behind it.
 * - Everything moves slowly and eases toward the pointer (no sudden motion)
 * - DPR capped, paused when hidden, nearly static with prefers-reduced-motion
 * - Colours follow the site's light / dark theme and cross-fade on switch
 */

type Palette = {
  deep: string // point colour in the troughs
  crest: string // point colour on the crests
  orbA: string
  orbB: string
  additive: boolean
  pointAlpha: number
  orbAlpha: number
}

const PALETTES: Record<"light" | "dark", Palette> = {
  dark: {
    deep: "#0a5f78",
    crest: "#4fe3f2",
    orbA: "#0b7a99",
    orbB: "#1b5fa8",
    additive: true,
    pointAlpha: 0.55,
    orbAlpha: 0.32,
  },
  light: {
    deep: "#5f9fb8",
    crest: "#0a8fa6",
    orbA: "#8cc9de",
    orbB: "#9db8e0",
    additive: false,
    pointAlpha: 0.5,
    orbAlpha: 0.42,
  },
}

const POINT_VERT = /* glsl */ `
  uniform float uTime;
  uniform vec2 uPointer;     // pointer in world xz
  uniform float uPointerAmt; // 0..1 fades in once the user moves
  uniform float uSize;
  varying float vH;
  varying float vFade;

  void main() {
    vec3 p = position;
    float t = uTime;

    // layered, slow swells
    float h = sin(p.x * 0.22 + t * 0.45) * 0.55
            + sin(p.z * 0.30 - t * 0.35) * 0.45
            + sin((p.x + p.z) * 0.14 + t * 0.25) * 0.7
            + sin(p.x * 0.55 - p.z * 0.4 + t * 0.6) * 0.12;

    // soft ripple that follows the cursor
    float d = distance(p.xz, uPointer);
    h += exp(-d * d * 0.035) * sin(d * 1.1 - t * 1.6) * 0.45 * uPointerAmt;

    p.y += h;
    vH = h;

    vec4 mv = modelViewMatrix * vec4(p, 1.0);
    gl_Position = projectionMatrix * mv;

    // fade out towards the far edge + far sides so the field has no hard border
    vFade = smoothstep(0.0, 1.0, 1.0 - abs(position.x) / 38.0)
          * smoothstep(0.0, 1.0, 1.0 - (-position.z) / 52.0)
          * smoothstep(0.0, 0.25, (position.z + 18.0) / 18.0);

    gl_PointSize = uSize * (46.0 / -mv.z) * (0.85 + 0.35 * smoothstep(-1.2, 1.4, h));
  }
`

const POINT_FRAG = /* glsl */ `
  precision mediump float;
  uniform vec3 uDeep;
  uniform vec3 uCrest;
  uniform float uAlpha;
  varying float vH;
  varying float vFade;

  void main() {
    vec2 c = gl_PointCoord - 0.5;
    float r = length(c);
    if (r > 0.5) discard;
    float soft = smoothstep(0.5, 0.0, r);
    vec3 col = mix(uDeep, uCrest, smoothstep(-0.9, 1.5, vH));
    gl_FragColor = vec4(col, soft * soft * uAlpha * vFade);
  }
`

const ORB_VERT = /* glsl */ `
  varying vec2 vUv;
  void main() {
    vUv = uv;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`

const ORB_FRAG = /* glsl */ `
  precision mediump float;
  uniform vec3 uColor;
  uniform float uAlpha;
  varying vec2 vUv;
  void main() {
    float r = length(vUv - 0.5) * 2.0;
    float a = smoothstep(1.0, 0.0, r);
    gl_FragColor = vec4(uColor, a * a * uAlpha);
  }
`

export default function CalmScene({ theme }: { theme: "light" | "dark" }) {
  const hostRef = useRef<HTMLDivElement>(null)
  const apiRef = useRef<{ setTheme: (t: "light" | "dark", animate: boolean) => void } | null>(null)
  const themeRef = useRef(theme)
  themeRef.current = theme

  useEffect(() => {
    const host = hostRef.current
    if (!host) return

    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches
    let renderer: THREE.WebGLRenderer
    try {
      renderer = new THREE.WebGLRenderer({ alpha: true, antialias: false, powerPreference: "high-performance" })
    } catch {
      return // CSS gradient behind stays as the fallback
    }

    const dprCap = 1.5
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, dprCap))
    renderer.setClearColor(0x000000, 0)
    host.appendChild(renderer.domElement)
    renderer.domElement.style.cssText = "display:block;width:100%;height:100%"

    const scene = new THREE.Scene()
    const camera = new THREE.PerspectiveCamera(52, 1, 0.1, 200)
    const camBase = new THREE.Vector3(0, 8.5, 16)
    camera.position.copy(camBase)
    camera.lookAt(0, 0, -8)

    // ---------- wave field ----------
    const COLS = 170
    const ROWS = 110
    const SPAN_X = 84
    const SPAN_Z = 64
    const positions = new Float32Array(COLS * ROWS * 3)
    let i = 0
    for (let zi = 0; zi < ROWS; zi++) {
      for (let xi = 0; xi < COLS; xi++) {
        // tiny jitter keeps it organic rather than a rigid grid
        const jx = (Math.random() - 0.5) * 0.22
        const jz = (Math.random() - 0.5) * 0.22
        positions[i++] = (xi / (COLS - 1) - 0.5) * SPAN_X + jx
        positions[i++] = 0
        positions[i++] = -(zi / (ROWS - 1)) * SPAN_Z + 12 + jz
      }
    }
    const geo = new THREE.BufferGeometry()
    geo.setAttribute("position", new THREE.BufferAttribute(positions, 3))

    const startPal = PALETTES[themeRef.current]
    const pointUniforms = {
      uTime: { value: 0 },
      uPointer: { value: new THREE.Vector2(0, -6) },
      uPointerAmt: { value: 0 },
      uSize: { value: 1.9 * Math.min(window.devicePixelRatio || 1, dprCap) },
      uDeep: { value: new THREE.Color(startPal.deep) },
      uCrest: { value: new THREE.Color(startPal.crest) },
      uAlpha: { value: startPal.pointAlpha },
    }
    const pointMat = new THREE.ShaderMaterial({
      uniforms: pointUniforms,
      vertexShader: POINT_VERT,
      fragmentShader: POINT_FRAG,
      transparent: true,
      depthWrite: false,
      blending: startPal.additive ? THREE.AdditiveBlending : THREE.NormalBlending,
    })
    const points = new THREE.Points(geo, pointMat)
    scene.add(points)

    // ---------- drifting orbs (depth) ----------
    const orbGeo = new THREE.PlaneGeometry(1, 1)
    const makeOrb = (color: string, alpha: number, scale: number, pos: [number, number, number]) => {
      const mat = new THREE.ShaderMaterial({
        uniforms: { uColor: { value: new THREE.Color(color) }, uAlpha: { value: alpha } },
        vertexShader: ORB_VERT,
        fragmentShader: ORB_FRAG,
        transparent: true,
        depthWrite: false,
        blending: THREE.NormalBlending,
      })
      const mesh = new THREE.Mesh(orbGeo, mat)
      mesh.scale.setScalar(scale)
      mesh.position.set(...pos)
      scene.add(mesh)
      return mesh
    }
    const orbs = [
      { mesh: makeOrb(startPal.orbA, startPal.orbAlpha, 38, [-18, 10, -42]), a: 0.9, ph: 0.0, key: "orbA" as const },
      { mesh: makeOrb(startPal.orbB, startPal.orbAlpha, 46, [22, 6, -52]), a: 0.7, ph: 2.1, key: "orbB" as const },
      { mesh: makeOrb(startPal.orbA, startPal.orbAlpha * 0.8, 26, [4, 14, -34]), a: 1.1, ph: 4.2, key: "orbA" as const },
    ]

    // ---------- interaction (everything is eased, never snapped) ----------
    const target = { x: 0, y: 0 } // normalised pointer -1..1
    const eased = { x: 0, y: 0 }
    const worldPointer = new THREE.Vector2(0, -6)
    let pointerAmtTarget = 0
    const onMove = (e: PointerEvent) => {
      target.x = (e.clientX / window.innerWidth) * 2 - 1
      target.y = (e.clientY / window.innerHeight) * 2 - 1
      pointerAmtTarget = reduced ? 0 : 1
    }
    const onLeave = () => { pointerAmtTarget = 0 }
    window.addEventListener("pointermove", onMove, { passive: true })
    document.addEventListener("pointerleave", onLeave)

    // gentle device tilt on phones
    const onTilt = (e: DeviceOrientationEvent) => {
      if (e.gamma == null || e.beta == null) return
      target.x = Math.max(-1, Math.min(1, e.gamma / 30))
      target.y = Math.max(-1, Math.min(1, (e.beta - 45) / 30))
    }
    if (!reduced) window.addEventListener("deviceorientation", onTilt, { passive: true })

    // ---------- sizing ----------
    const resize = () => {
      const w = host.clientWidth || window.innerWidth
      const h = host.clientHeight || window.innerHeight
      renderer.setSize(w, h, false)
      camera.aspect = w / h
      // keep the composition framed on tall / narrow screens
      camera.fov = w / h < 0.8 ? 66 : 52
      camera.updateProjectionMatrix()
    }
    resize()
    const ro = new ResizeObserver(resize)
    ro.observe(host)

    // ---------- theme cross-fade ----------
    const applyTheme = (t: "light" | "dark", animate: boolean) => {
      const pal = PALETTES[t]
      const dur = animate ? 1.6 : 0
      const toColor = (c: THREE.Color, hex: string) => {
        const to = new THREE.Color(hex)
        gsap.to(c, { r: to.r, g: to.g, b: to.b, duration: dur, ease: "sine.inOut", overwrite: true })
      }
      toColor(pointUniforms.uDeep.value, pal.deep)
      toColor(pointUniforms.uCrest.value, pal.crest)
      gsap.to(pointUniforms.uAlpha, { value: pal.pointAlpha, duration: dur, ease: "sine.inOut", overwrite: true })
      pointMat.blending = pal.additive ? THREE.AdditiveBlending : THREE.NormalBlending
      pointMat.needsUpdate = true
      orbs.forEach(o => {
        const m = o.mesh.material as THREE.ShaderMaterial
        toColor(m.uniforms.uColor.value, pal[o.key])
        gsap.to(m.uniforms.uAlpha, { value: pal.orbAlpha * (o.mesh.scale.x < 30 ? 0.8 : 1), duration: dur, ease: "sine.inOut", overwrite: true })
      })
    }
    apiRef.current = { setTheme: applyTheme }
    applyTheme(themeRef.current, false)

    // ---------- loop ----------
    let last = performance.now()
    const getDelta = () => { const n = performance.now(); const d = (n - last) / 1000; last = n; return d }
    let raf = 0
    let running = true
    const timeScale = reduced ? 0.12 : 1
    const raycastPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0)
    const ray = new THREE.Raycaster()
    const hit = new THREE.Vector3()
    const ndc = new THREE.Vector2()

    const frame = () => {
      raf = requestAnimationFrame(frame)
      const dt = Math.min(getDelta(), 0.05) // clamp so tab-switch never jumps
      pointUniforms.uTime.value += dt * timeScale * 0.8

      // exponential smoothing = frame-rate independent, buttery easing
      const k = 1 - Math.exp(-dt * 2.2)
      eased.x += (target.x - eased.x) * k
      eased.y += (target.y - eased.y) * k

      camera.position.x = camBase.x + eased.x * 3.2
      camera.position.y = camBase.y - eased.y * 1.6
      camera.lookAt(eased.x * 1.2, 0, -8)

      // map cursor onto the water plane for the soft ripple
      ndc.set(eased.x, -eased.y)
      ray.setFromCamera(ndc, camera)
      if (ray.ray.intersectPlane(raycastPlane, hit)) worldPointer.lerp(new THREE.Vector2(hit.x, hit.z), 1 - Math.exp(-dt * 3))
      pointUniforms.uPointer.value.copy(worldPointer)
      pointUniforms.uPointerAmt.value += (pointerAmtTarget - pointUniforms.uPointerAmt.value) * (1 - Math.exp(-dt * 1.5))

      const t = pointUniforms.uTime.value
      for (const o of orbs) {
        o.mesh.position.x += Math.sin(t * 0.18 * o.a + o.ph) * dt * 0.9
        o.mesh.position.y += Math.cos(t * 0.15 * o.a + o.ph) * dt * 0.5
      }

      renderer.render(scene, camera)
    }

    const start = () => { if (!running) { running = true; getDelta(); raf = requestAnimationFrame(frame) } }
    const stop = () => { running = false; cancelAnimationFrame(raf) }
    const onVis = () => (document.hidden ? stop() : start())
    document.addEventListener("visibilitychange", onVis)
    raf = requestAnimationFrame(frame)

    return () => {
      stop()
      document.removeEventListener("visibilitychange", onVis)
      window.removeEventListener("pointermove", onMove)
      document.removeEventListener("pointerleave", onLeave)
      window.removeEventListener("deviceorientation", onTilt)
      ro.disconnect()
      gsap.killTweensOf([pointUniforms.uDeep.value, pointUniforms.uCrest.value, pointUniforms.uAlpha])
      geo.dispose(); pointMat.dispose(); orbGeo.dispose()
      orbs.forEach(o => { gsap.killTweensOf((o.mesh.material as THREE.ShaderMaterial).uniforms.uColor.value); (o.mesh.material as THREE.Material).dispose() })
      renderer.dispose()
      renderer.domElement.remove()
      apiRef.current = null
    }
  }, [])

  useEffect(() => { apiRef.current?.setTheme(theme, true) }, [theme])

  return <div ref={hostRef} className="calm-scene-host" aria-hidden="true" />
}
