"use client"

import { useEffect, useRef, useState, type FormEvent } from "react"
import dynamic from "next/dynamic"
import { useTheme } from "next-themes"
import gsap from "gsap"
import Lenis from "lenis"
import { ArrowRight, Eye, EyeOff, Info, LockKeyhole, Moon, ShieldCheck, Sun, UserRound } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Field, FieldGroup, FieldLabel, FieldError } from "@/components/ui/field"
import { InputGroup, InputGroupAddon, InputGroupButton, InputGroupInput } from "@/components/ui/input-group"
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

// three.js is only needed in the browser; load it after first paint so the form appears instantly
const GradientWaveScene = dynamic(() => import("@/components/gradient-wave-scene"), { ssr: false })
import { TraceIntro } from "@/components/intro/trace-intro"

export function TraceLogin() {
  const { resolvedTheme, setTheme } = useTheme()
  const [mounted, setMounted] = useState(false)
  // cinematic intro: "intro" (playing) -> "handoff" (dissolving, login entering) -> "done" (overlay removed)
  const [phase, setPhase] = useState<"intro" | "handoff" | "done">("intro")
  const entered = phase !== "intro"
  const pageRef = useRef<HTMLDivElement>(null)
  const introRef = useRef<HTMLDivElement>(null)
  const tiltRef = useRef<HTMLDivElement>(null)
  const cardRef = useRef<HTMLElement>(null)

  useEffect(() => setMounted(true), [])

  // Lenis smooth scroll, driven by GSAP's ticker so both share one clock
  useEffect(() => {
    const lenis = new Lenis({ lerp: 0.085, smoothWheel: true })
    const tick = (time: number) => lenis.raf(time * 1000)
    gsap.ticker.add(tick)
    gsap.ticker.lagSmoothing(0)
    return () => {
      gsap.ticker.remove(tick)
      lenis.destroy()
    }
  }, [])

  // Entrance + calm interactive motion
  useEffect(() => {
    const page = pageRef.current
    if (!page || !entered) return
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches
    const fine = window.matchMedia("(hover: hover) and (pointer: fine)").matches

    const ctx = gsap.context(() => {
      const items = gsap.utils.toArray<HTMLElement>("[data-enter]")
      if (reduced) {
        gsap.set(items, { opacity: 1 })
        return
      }

      gsap.fromTo(
        items,
        { opacity: 0, y: 22, filter: "blur(8px)" },
        { opacity: 1, y: 0, filter: "blur(0px)", duration: 1.3, ease: "power3.out", stagger: 0.12, delay: 0.15, clearProps: "filter" },
      )
      gsap.fromTo(
        "[data-field]",
        { opacity: 0, y: 12 },
        { opacity: 1, y: 0, duration: 0.9, ease: "power2.out", stagger: 0.08, delay: 0.7 },
      )

      // a barely-there float on the card wrapper
      if (tiltRef.current) {
        gsap.to(tiltRef.current, { y: -6, duration: 5.5, ease: "sine.inOut", yoyo: true, repeat: -1 })
      }

      if (!fine || !cardRef.current || !introRef.current) return
      const card = cardRef.current
      const rotX = gsap.quickTo(card, "rotationX", { duration: 1.4, ease: "power3.out" })
      const rotY = gsap.quickTo(card, "rotationY", { duration: 1.4, ease: "power3.out" })
      const introX = gsap.quickTo(introRef.current, "x", { duration: 1.6, ease: "power3.out" })
      const introY = gsap.quickTo(introRef.current, "y", { duration: 1.6, ease: "power3.out" })
      gsap.set(card, { transformPerspective: 1200, transformOrigin: "50% 50%" })
      const glare = { x: 50, y: 0 }
      const applyGlare = () => {
        card.style.setProperty("--mx", `${glare.x}%`)
        card.style.setProperty("--my", `${glare.y}%`)
      }
      applyGlare()

      const onMove = (e: PointerEvent) => {
        const nx = (e.clientX / window.innerWidth) * 2 - 1
        const ny = (e.clientY / window.innerHeight) * 2 - 1
        rotY(nx * 4.5)
        rotX(-ny * 3.5)
        introX(nx * -10)
        introY(ny * -6)
        const r = card.getBoundingClientRect()
        gsap.to(glare, {
          x: ((e.clientX - r.left) / r.width) * 100,
          y: ((e.clientY - r.top) / r.height) * 100,
          duration: 1,
          ease: "power3.out",
          overwrite: true,
          onUpdate: applyGlare,
        })
      }
      window.addEventListener("pointermove", onMove, { passive: true })
      return () => window.removeEventListener("pointermove", onMove)
    }, page)
    return () => ctx.revert()
  }, [entered])

  const theme = resolvedTheme === "dark" ? "dark" : "light"

  return (
    <>
    {phase !== "done" && (
      <TraceIntro theme={theme} ready={mounted} onHandoff={() => setPhase((p) => (p === "intro" ? "handoff" : p))} onDone={() => setPhase("done")} />
    )}
    <div className="trace-page" ref={pageRef} inert={phase !== "done"}>
      <div className="trace-backdrop" aria-hidden="true" />
      <div className={`trace-scene ${mounted ? "is-ready" : ""}`} aria-hidden="true">
        {mounted && entered && <GradientWaveScene theme={theme} />}
      </div>
      <div className="trace-vignette" aria-hidden="true" />

      <header className="trace-header" data-enter>
        <a href="/" className="trace-wordmark" aria-label="Trace Relay home">Trace <span>Relay</span></a>
        <div className="header-right">
          <nav className="header-nav" aria-label="Main">
            <a href="/#features">Features</a>
            <a href="/#workspaces">Workspaces</a>
            <a href="/#faq">FAQ</a>
          </nav>
          <Button variant="ghost" size="icon" className="theme-toggle" aria-label="Toggle color theme" onClick={() => setTheme(theme === "dark" ? "light" : "dark")}>
            <Sun className="theme-sun" /><Moon className="theme-moon" />
          </Button>
        </div>
      </header>

      <main className="trace-main">
        <div className="login-intro" ref={introRef}>
          <span className="workspace-eyebrow" data-enter><span aria-hidden="true" />Patient, doctor and diagnostic centre in one app</span>
          <h1 data-enter>Welcome back,<br /><em>to your care journey</em></h1>
          <p data-enter>Keep every report, prescription and follow-up in one place,<br className="hidden sm:block" /> easy to find and easy to share with the next doctor.</p>
        </div>

        <div className="card-float" ref={tiltRef} data-enter>
          <SignInForm cardRef={cardRef} />
        </div>

        <p className="security-caption" data-enter><ShieldCheck size={15} aria-hidden="true" /> Secure access to your healthcare workspace.</p>
      </main>

      <footer className="trace-footer" data-enter>
        <p>© {new Date().getFullYear()} Trace Relay</p>
        <p>A little more connected. A lot more care.</p>
      </footer>
    </div>
    </>
  )
}

function SignInForm({ cardRef }: { cardRef: React.RefObject<HTMLElement | null> }) {
  const [username, setUsername] = useState("")
  const [suffix, setSuffix] = useState("patient")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [errors, setErrors] = useState<{ username?: string; password?: string }>({})
  const [unavailable, setUnavailable] = useState(false)

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const nextErrors = {
      username: username.trim().length >= 3 ? undefined : "Enter a username with at least 3 characters.",
      password: password ? undefined : "Enter your password.",
    }
    setErrors(nextErrors)
    setUnavailable(!nextErrors.username && !nextErrors.password)
    if (nextErrors.username) document.getElementById("username")?.focus()
    else if (nextErrors.password) document.getElementById("password")?.focus()
  }

  return (
    <section className="login-card" ref={cardRef} aria-labelledby="form-title">
      <span className="card-sheen" aria-hidden="true" />
      <div className="form-heading" data-field>
        <div className="lock-tile" aria-hidden="true"><LockKeyhole size={20} strokeWidth={1.6} /></div>
        <h2 id="form-title">Sign in to your account</h2>
        <p>Pick up where your care journey left off.</p>
      </div>
      <form onSubmit={handleSubmit} noValidate className="flex flex-col gap-6">
        <FieldGroup className="gap-5">
          <Field data-invalid={!!errors.username} data-field className="gap-2">
            <FieldLabel htmlFor="username">Username</FieldLabel>
            <div className="username-row">
              <InputGroup className="trace-input username-input">
                <InputGroupInput id="username" name="username" type="text" autoComplete="username" placeholder="your username" required value={username} onChange={event => { setUsername(event.target.value); setUnavailable(false) }} aria-invalid={!!errors.username} aria-describedby={errors.username ? "username-error" : undefined} />
                <InputGroupAddon><UserRound aria-hidden="true" /></InputGroupAddon>
              </InputGroup>
              <Select value={suffix} onValueChange={value => { setSuffix(value); setUnavailable(false) }}>
                <SelectTrigger className="suffix-select" aria-label="Account type"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="dr">.dr</SelectItem>
                  <SelectItem value="patient">.patient</SelectItem>
                  <SelectItem value="org">.org</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {errors.username && <FieldError id="username-error">{errors.username}</FieldError>}
          </Field>
          <Field data-invalid={!!errors.password} data-field className="gap-2">
            <div className="password-label"><FieldLabel htmlFor="password">Password</FieldLabel><span className="unavailable-link" title="Password recovery is not connected yet" aria-disabled="true">Forgot password?</span></div>
            <InputGroup className="trace-input">
              <InputGroupInput id="password" name="password" type={showPassword ? "text" : "password"} autoComplete="current-password" placeholder="Enter your password" required value={password} onChange={event => { setPassword(event.target.value); setUnavailable(false) }} aria-invalid={!!errors.password} aria-describedby={errors.password ? "password-error" : undefined} />
              <InputGroupAddon><LockKeyhole aria-hidden="true" /></InputGroupAddon>
              <InputGroupAddon align="inline-end"><InputGroupButton size="icon-sm" className="password-toggle" aria-label={showPassword ? "Hide password" : "Show password"} aria-pressed={showPassword} onClick={() => setShowPassword(!showPassword)}>{showPassword ? <EyeOff /> : <Eye />}</InputGroupButton></InputGroupAddon>
            </InputGroup>
            {errors.password && <FieldError id="password-error">{errors.password}</FieldError>}
          </Field>
        </FieldGroup>
        {unavailable && <Alert><Info className="size-4" /><AlertTitle>Authentication not connected</AlertTitle><AlertDescription>This template has no sign-in service yet. No credentials have been sent or saved.</AlertDescription></Alert>}
        <Button type="submit" data-field className="sign-in-button" aria-describedby="connection-note">Sign in <ArrowRight data-icon="inline-end" /></Button>
      </form>
      <div className="account-caption" data-field><span>Don&apos;t have an account?</span> <span className="unavailable-link" aria-disabled="true" title="Account creation is not connected yet">Create an account</span></div>
      <p id="connection-note" className="connection-note" data-field>Preview only · Sign-in, recovery and registration are not connected.</p>
    </section>
  )
}
