"use client"

import { useCallback, useEffect, useRef, useState } from "react"
import dynamic from "next/dynamic"
import { ArrowRight } from "lucide-react"

// three.js is loaded only when the intro actually runs (never for reduced-motion / data-saver visitors)
const TraceIntroScene = dynamic(() => import("@/components/intro/trace-intro-scene"), { ssr: false })

const CAPTIONS = [
  { tag: "Trace Relay", title: "From first scan to a closed follow-up", body: "Follow one report across the whole care journey." },
  { tag: "01 · Diagnostic centre", title: "A scan becomes a report", body: "Bookings, scans and reports are tracked from booking to upload." },
  { tag: "02 · Patient", title: "Every record in one place", body: "The report lands with the patient, who decides who sees it." },
  { tag: "03 · Doctor", title: "Review, then close the loop", body: "A clinician reviews the evidence and closes the follow-up." },
] as const

type Props = {
  theme: "light" | "dark"
  /** theme is only known after mount; the scene waits for it */
  ready: boolean
  /** the login page can start entering now (overlay is beginning to dissolve) */
  onHandoff: () => void
  /** overlay finished fading and can be removed */
  onDone: () => void
}

export function TraceIntro({ theme, ready, onHandoff, onDone }: Props) {
  const [enabled, setEnabled] = useState<boolean | null>(null)
  const [step, setStep] = useState(0)
  const [leaving, setLeaving] = useState<"none" | "slow" | "fast">("none")
  const leavingRef = useRef(false)
  const progressRef = useRef<HTMLSpanElement>(null)
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null)
  const cb = useRef({ onHandoff, onDone })
  cb.current = { onHandoff, onDone }

  const leave = useCallback((mode: "slow" | "fast") => {
    if (leavingRef.current) return
    leavingRef.current = true
    setLeaving(mode)
    cb.current.onHandoff()
    timer.current = setTimeout(() => cb.current.onDone(), mode === "slow" ? 1300 : 650)
  }, [])

  // reduced motion / data saver: no intro at all, straight to the login page
  useEffect(() => {
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches
    const saver = (navigator as Navigator & { connection?: { saveData?: boolean } }).connection?.saveData === true
    if (reduced || saver) {
      leavingRef.current = true
      cb.current.onHandoff()
      cb.current.onDone()
      return
    }
    setEnabled(true)
  }, [])

  // Esc skips from anywhere
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") leave("fast") }
    window.addEventListener("keydown", onKey)
    return () => {
      window.removeEventListener("keydown", onKey)
      if (timer.current) clearTimeout(timer.current)
    }
  }, [leave])

  const cap = CAPTIONS[step]

  return (
    <div className={`trace-intro ${leaving !== "none" ? `is-leaving is-${leaving}` : ""}`} role="region" aria-label="Trace Relay introduction">
      <div className="trace-intro-backdrop" aria-hidden="true" />
      {enabled && ready && (
        <TraceIntroScene
          theme={theme}
          progressRef={progressRef}
          onStep={setStep}
          onHandoff={() => leave("slow")}
          onFail={() => leave("fast")}
        />
      )}
      <div className="trace-intro-vignette" aria-hidden="true" />

      <div className="intro-top">
        <span className="trace-wordmark" aria-hidden="true">Trace <span>Relay</span></span>
        <button type="button" className="intro-skip" onClick={() => leave("fast")}>
          Skip intro <ArrowRight aria-hidden="true" size={15} />
        </button>
      </div>

      <div className="intro-bottom">
        <div className="intro-caption" key={step} aria-live="polite">
          <span className="workspace-eyebrow"><span aria-hidden="true" />{cap.tag}</span>
          <h2>{cap.title}</h2>
          <p>{cap.body}</p>
        </div>
        <div className="intro-progress" aria-hidden="true">
          <i className={step >= 1 ? "on" : ""} /><i className={step >= 2 ? "on" : ""} /><i className={step >= 3 ? "on" : ""} />
          <b><span ref={progressRef} /></b>
        </div>
      </div>
    </div>
  )
}
