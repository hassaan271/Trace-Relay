"use client"

import { useEffect, useRef } from "react"
import * as THREE from "three"
import { RoundedBoxGeometry } from "three/examples/jsm/geometries/RoundedBoxGeometry.js"

/**
 * TRACE RELAY: cinematic 3D intro.
 *
 *   Diagnostic centre  ->  Patient  ->  Doctor
 *   scan + report          records      review + closed follow-up
 *
 * Everything on screen is a pure function of one clock `T` (seconds), so the
 * camera, the travelling report / share token and the closing loop can never
 * drift apart, and pausing (hidden tab) or finishing is trivial.
 *
 * Look and feel is read from the login page's own CSS tokens (--background,
 * --primary, --brand-ink, --card, --foreground) so it follows light / dark and
 * matches the glass + hairline-cyan language of the rest of the site.
 *
 * Performance: one renderer, no post-processing, DPR capped, adaptive pixel
 * ratio if frames run long, paused while the tab is hidden, everything disposed
 * on unmount.
 */

export const INTRO_DURATION = 13.8 // seconds until the final frame
export const HANDOFF_AT = 12.4 // login starts entering here; the overlay cross-fades out

type Props = {
  theme: "light" | "dark"
  /** 0 = title, 1 = diagnostic centre, 2 = patient, 3 = doctor */
  onStep: (step: number) => void
  onHandoff: () => void
  onFail: () => void
  progressRef: React.RefObject<HTMLElement | null>
}

/* ───────────────────────── helpers ───────────────────────── */

const clamp01 = (x: number) => Math.min(1, Math.max(0, x))
const smooth = (x: number) => { const t = clamp01(x); return t * t * (3 - 2 * t) }
const smoother = (x: number) => { const t = clamp01(x); return t * t * t * (t * (t * 6 - 15) + 10) }
/** eased 0..1 progress of T inside [a, b] */
const seg = (T: number, a: number, b: number) => smooth((T - a) / (b - a))
const lerp = (a: number, b: number, t: number) => a + (b - a) * t

/** Read an `H S% L%` token (the login page's format), a hex/rgb token (the marketing site's), or fall back. */
function token(names: string[], fallback: string): THREE.Color {
  const style = getComputedStyle(document.documentElement)
  for (const n of names) {
    const v = style.getPropertyValue(n).trim()
    if (!v) continue
    const m = v.match(/^([\d.]+)(?:deg)?[\s,]+([\d.]+)%[\s,]+([\d.]+)%/)
    if (m) return new THREE.Color().setHSL(+m[1] / 360, +m[2] / 100, +m[3] / 100, THREE.SRGBColorSpace)
    try {
      return new THREE.Color(v)
    } catch {
      /* try the next token */
    }
  }
  return new THREE.Color(fallback)
}

function rr(g: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  g.beginPath()
  g.moveTo(x + r, y)
  g.arcTo(x + w, y, x + w, y + h, r)
  g.arcTo(x + w, y + h, x, y + h, r)
  g.arcTo(x, y + h, x, y, r)
  g.arcTo(x, y, x + w, y, r)
  g.closePath()
}

const css = (c: THREE.Color) => `#${c.getHexString(THREE.SRGBColorSpace)}`

/* ───────────────────────── shaders ───────────────────────── */

const GRID_VS = /* glsl */ `
  varying vec3 vW;
  void main() {
    vec4 w = modelMatrix * vec4(position, 1.0);
    vW = w.xyz;
    gl_Position = projectionMatrix * viewMatrix * w;
  }
`
const GRID_FS = /* glsl */ `
  precision mediump float;
  uniform vec3 uColor;
  uniform float uAlpha;
  varying vec3 vW;
  void main() {
    vec2 g = vW.xz / 2.0;
    vec2 w = fwidth(g);
    vec2 a = abs(fract(g - 0.5) - 0.5) / max(w, vec2(0.0001));
    float line = 1.0 - min(min(a.x, a.y), 1.0);
    float d = length((vW.xz - vec2(-1.0, -14.0)) * vec2(0.8, 0.55));
    float fade = smoothstep(38.0, 6.0, d);
    gl_FragColor = vec4(uColor, line * fade * uAlpha);
  }
`

const TUBE_VS = /* glsl */ `
  varying float vU;
  void main() {
    vU = uv.x;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`
const TUBE_FS = /* glsl */ `
  precision mediump float;
  uniform vec3 uColor;
  uniform float uAlpha;
  uniform float uHead;
  varying float vU;
  void main() {
    if (vU > uHead) discard;
    float d = uHead - vU;
    float pulse = smoothstep(0.16, 0.0, d);
    gl_FragColor = vec4(uColor, uAlpha * (0.34 + 0.66 * pulse));
  }
`

const DUST_VS = /* glsl */ `
  attribute vec3 aSeed;
  uniform float uTime;
  uniform float uScale;
  varying float vA;
  void main() {
    vec3 p = position;
    p.y += sin(uTime * 0.25 + aSeed.x * 30.0) * 0.5 + uTime * 0.06 * (0.3 + aSeed.z);
    p.y = mod(p.y, 14.0);
    p.x += sin(uTime * 0.12 + aSeed.y * 20.0) * 0.6;
    vec4 mv = modelViewMatrix * vec4(p, 1.0);
    gl_Position = projectionMatrix * mv;
    gl_PointSize = clamp((0.05 + aSeed.z * 0.1) * uScale / max(-mv.z, 0.1), 1.0, 6.0);
    vA = (0.25 + 0.75 * aSeed.z) * (0.55 + 0.45 * sin(uTime * 0.7 + aSeed.x * 40.0));
  }
`
const DUST_FS = /* glsl */ `
  precision mediump float;
  uniform vec3 uColor;
  uniform float uK;
  varying float vA;
  void main() {
    float d = length(gl_PointCoord - 0.5);
    gl_FragColor = vec4(uColor, smoothstep(0.5, 0.0, d) * vA * uK);
  }
`

/* ───────────────────────── scene ───────────────────────── */

export default function TraceIntroScene({ theme, onStep, onHandoff, onFail, progressRef }: Props) {
  const hostRef = useRef<HTMLDivElement>(null)
  const cb = useRef({ onStep, onHandoff, onFail })
  cb.current = { onStep, onHandoff, onFail }
  const themeRef = useRef(theme)

  useEffect(() => {
    const host = hostRef.current
    if (!host) return
    let disposed = false
    let teardown: (() => void) | null = null

    // Canvas textures use the page fonts; give them a moment to be ready, never block on them.
    const fontsReady = Promise.race([
      Promise.all([document.fonts?.load('600 20px "Inter Variable"'), document.fonts?.load('600 20px "Space Grotesk Variable"')]).catch(() => null),
      new Promise((r) => setTimeout(r, 700)),
    ])
    fontsReady.then(() => {
      if (!disposed) teardown = build(host, themeRef.current === "dark", cb, progressRef)
    })
    return () => {
      disposed = true
      teardown?.()
    }
  }, [progressRef])

  return <div ref={hostRef} className="intro-canvas-host" aria-hidden="true" />
}

function build(
  host: HTMLDivElement,
  dark: boolean,
  cbRef: React.MutableRefObject<{ onStep: (s: number) => void; onHandoff: () => void; onFail: () => void }>,
  progressRef: React.RefObject<HTMLElement | null>,
): () => void {
  /* ── renderer ── */
  const rawDpr = window.devicePixelRatio || 1
  let renderer: THREE.WebGLRenderer
  try {
    renderer = new THREE.WebGLRenderer({ antialias: rawDpr < 2, alpha: true, powerPreference: "high-performance" })
  } catch {
    cbRef.current.onFail()
    return () => {}
  }
  const small = window.innerWidth < 700
  let pixelRatio = Math.min(rawDpr, small ? 1.5 : 1.75)
  renderer.setPixelRatio(pixelRatio)
  renderer.setClearColor(0x000000, 0)
  renderer.domElement.style.cssText = "display:block;width:100%;height:100%"
  host.appendChild(renderer.domElement)
  let lost = false
  const onLost = (e: Event) => { e.preventDefault(); lost = true; cbRef.current.onFail() }
  renderer.domElement.addEventListener("webglcontextlost", onLost)

  /* ── palette from the page tokens ── */
  const bg = token(["--background", "--bg"], dark ? "#061520" : "#d5e2ea")
  const card = token(["--card", "--surface"], dark ? "#0e2430" : "#f2f7f9")
  const fg = token(["--foreground", "--text"], dark ? "#e8eff6" : "#0b2230")
  const cyan = token(["--primary", "--cyan"], dark ? "#00e0f0" : "#00b8cc")
  const ink = token(["--brand-ink", "--cyan"], dark ? "#00e0f0" : "#007c91")
  const blue = new THREE.Color(dark ? "#168bff" : "#1170d6")
  const glowBlend = dark ? THREE.AdditiveBlending : THREE.NormalBlending

  const scene = new THREE.Scene()
  scene.fog = new THREE.Fog(bg, 34, 105)
  const camera = new THREE.PerspectiveCamera(48, 1, 0.1, 160)

  const disposables: { dispose(): void }[] = []
  const track = <T extends { dispose(): void }>(o: T): T => { disposables.push(o); return o }

  /* ── lights ── */
  scene.add(new THREE.AmbientLight(0xffffff, dark ? 0.9 : 1.5))
  scene.add(new THREE.HemisphereLight(dark ? 0x7fd8ff : 0xffffff, dark ? 0x04101a : 0x9fb9c8, dark ? 0.8 : 0.9))
  const key = new THREE.DirectionalLight(0xffffff, dark ? 1.6 : 2.2)
  key.position.set(-6, 12, 9)
  scene.add(key)
  const rim = new THREE.DirectionalLight(blue, dark ? 2.0 : 0.8)
  rim.position.set(8, 5, -12)
  scene.add(rim)
  const pointer = new THREE.PointLight(cyan, dark ? 38 : 14, 15, 1.6)
  scene.add(pointer)

  /* ── shared materials ── */
  const glass = track(new THREE.MeshStandardMaterial({
    color: dark ? new THREE.Color("#143e52") : card, transparent: true, opacity: dark ? 0.46 : 0.62,
    roughness: 0.28, metalness: 0.12, depthWrite: false,
  }))
  const glassSolid = track(new THREE.MeshStandardMaterial({
    color: dark ? new THREE.Color("#0f3446") : new THREE.Color("#e6f1f6"), roughness: 0.4, metalness: 0.2, flatShading: true,
  }))
  const lineMat = track(new THREE.LineBasicMaterial({ color: ink, transparent: true, opacity: dark ? 0.95 : 0.75 }))
  const glowSolid = track(new THREE.MeshBasicMaterial({ color: cyan }))
  const glowSoft = track(new THREE.MeshBasicMaterial({ color: cyan, transparent: true, opacity: dark ? 0.35 : 0.3, depthWrite: false, blending: glowBlend, side: THREE.DoubleSide }))

  const edges = (mesh: THREE.Mesh, angle = 28) => {
    const eg = track(new THREE.EdgesGeometry(mesh.geometry, angle))
    mesh.add(new THREE.LineSegments(eg, lineMat))
    return mesh
  }
  const panel = (w: number, h: number, d: number, mat: THREE.Material = glass, r = 0.06) => {
    const geo = track(new RoundedBoxGeometry(w, h, d, 2, Math.min(r, w / 3, h / 3, d / 3)))
    return edges(new THREE.Mesh(geo, mat), 40)
  }

  /* ── textures ── */
  const halo = (() => {
    const c = document.createElement("canvas"); c.width = c.height = 128
    const g = c.getContext("2d")!
    const gr = g.createRadialGradient(64, 64, 0, 64, 64, 64)
    gr.addColorStop(0, "rgba(255,255,255,1)"); gr.addColorStop(0.25, "rgba(255,255,255,.45)"); gr.addColorStop(1, "rgba(255,255,255,0)")
    g.fillStyle = gr; g.fillRect(0, 0, 128, 128)
    return track(new THREE.CanvasTexture(c))
  })()
  const makeHalo = (size: number, color: THREE.Color, opacity: number) => {
    const s = new THREE.Sprite(track(new THREE.SpriteMaterial({ map: halo, color, transparent: true, opacity, depthWrite: false, blending: glowBlend })))
    s.scale.setScalar(size)
    return s
  }

  const paper = dark ? "#0a2230" : "#f8fcfe"
  const text = dark ? "#cfe3ee" : "#15384a"
  const mkTex = (c: HTMLCanvasElement) => {
    const t = track(new THREE.CanvasTexture(c))
    t.colorSpace = THREE.SRGBColorSpace
    t.anisotropy = 4
    return t
  }

  const docTexture = (title: string, sub: string, withImage: boolean) => {
    const c = document.createElement("canvas"); c.width = 256; c.height = 340
    const g = c.getContext("2d")!
    g.fillStyle = paper; rr(g, 4, 4, 248, 332, 18); g.fill()
    g.strokeStyle = css(ink); g.globalAlpha = 0.85; g.lineWidth = 3; g.stroke(); g.globalAlpha = 1
    g.fillStyle = css(cyan); rr(g, 20, 20, 38, 38, 11); g.fill()
    g.fillStyle = dark ? "#04141c" : "#ffffff"; g.fillRect(36, 28, 6, 22); g.fillRect(28, 36, 22, 6)
    g.fillStyle = text; g.font = '600 21px "Inter Variable", system-ui, sans-serif'; g.textBaseline = "middle"; g.fillText(title, 70, 34)
    g.globalAlpha = 0.6; g.font = '400 14px "Inter Variable", system-ui, sans-serif'; g.fillText(sub, 70, 54); g.globalAlpha = 1
    let y = 84
    if (withImage) {
      const gr = g.createLinearGradient(0, y, 0, y + 100)
      gr.addColorStop(0, css(cyan)); gr.addColorStop(1, css(blue))
      g.globalAlpha = 0.9; g.fillStyle = gr; rr(g, 20, y, 216, 100, 10); g.fill()
      g.globalAlpha = 0.5; g.strokeStyle = "#fff"; g.lineWidth = 2
      g.beginPath(); g.ellipse(128, y + 50, 42, 34, 0, 0, Math.PI * 2); g.stroke()
      g.beginPath(); g.ellipse(128, y + 50, 20, 16, 0, 0, Math.PI * 2); g.stroke(); g.globalAlpha = 1
      y += 118
    }
    for (let i = 0; y < 316; i++, y += 24) {
      g.globalAlpha = 0.22; g.fillStyle = text
      rr(g, 20, y, i % 3 === 2 ? 120 : 216, 9, 4); g.fill()
    }
    return mkTex(c)
  }

  const qrTexture = () => {
    const c = document.createElement("canvas"); c.width = c.height = 192
    const g = c.getContext("2d")!
    g.fillStyle = paper; rr(g, 4, 4, 184, 184, 18); g.fill()
    g.strokeStyle = css(ink); g.lineWidth = 3; g.stroke()
    const n = 13, s = 11, ox = 24, oy = 24
    let seed = 7
    const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647)
    g.fillStyle = text
    for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
      const finder = (x < 4 && y < 4) || (x > n - 5 && y < 4) || (x < 4 && y > n - 5)
      if (!finder && rnd() > 0.52) g.fillRect(ox + x * s, oy + y * s, s - 1, s - 1)
    }
    for (const [fx, fy] of [[0, 0], [n - 4, 0], [0, n - 4]]) {
      g.fillStyle = text; g.fillRect(ox + fx * s, oy + fy * s, 4 * s - 1, 4 * s - 1)
      g.fillStyle = paper; g.fillRect(ox + fx * s + 5, oy + fy * s + 5, 4 * s - 11, 4 * s - 11)
      g.fillStyle = css(cyan); g.fillRect(ox + fx * s + 12, oy + fy * s + 12, 4 * s - 25, 4 * s - 25)
    }
    return mkTex(c)
  }

  /** Doctor-side dashboard mock, styled after the site's workspace preview. */
  const dashTexture = (closed: boolean) => {
    const W = 1024, H = 600
    const c = document.createElement("canvas"); c.width = W; c.height = H
    const g = c.getContext("2d")!
    g.fillStyle = dark ? "#07151e" : "#f4f9fb"; g.fillRect(0, 0, W, H)
    g.fillStyle = dark ? "#0b1d29" : "#e9f2f6"; g.fillRect(0, 0, 210, H)
    g.fillStyle = text; g.font = '600 24px "Space Grotesk Variable", "Inter Variable", sans-serif'; g.textBaseline = "middle"
    g.fillText("Trace", 24, 40); g.fillStyle = css(ink); g.fillText("Relay", 98, 40)
    const nav = ["Overview", "Patients", "Passports", "Review queue", "Reports"]
    nav.forEach((n, i) => {
      const y = 86 + i * 52
      if (i === 2) {
        const gr = g.createLinearGradient(14, 0, 196, 0)
        gr.addColorStop(0, css(cyan)); gr.addColorStop(1, "rgba(0,0,0,0)")
        g.globalAlpha = 0.28; g.fillStyle = gr; rr(g, 14, y, 182, 40, 12); g.fill(); g.globalAlpha = 1
        g.strokeStyle = css(cyan); g.globalAlpha = 0.6; g.lineWidth = 1.5; rr(g, 14, y, 182, 40, 12); g.stroke(); g.globalAlpha = 1
      }
      g.fillStyle = text; g.globalAlpha = i === 2 ? 1 : 0.6; g.font = '500 17px "Inter Variable", sans-serif'; g.fillText(n, 48, y + 21); g.globalAlpha = 1
      g.fillStyle = css(cyan); g.globalAlpha = 0.8; g.beginPath(); g.arc(30, y + 20, 4, 0, 7); g.fill(); g.globalAlpha = 1
    })
    g.fillStyle = text; g.font = '600 30px "Space Grotesk Variable", "Inter Variable", sans-serif'
    g.fillText("Follow-up review", 250, 52)
    g.globalAlpha = 0.6; g.font = '400 17px "Inter Variable", sans-serif'; g.fillText("Patients who shared access, with open passports.", 250, 86); g.globalAlpha = 1
    const metrics: [string, string][] = [["Shared patients", "18"], ["Open follow-ups", closed ? "2" : "3"], ["To review", closed ? "0" : "1"]]
    metrics.forEach(([l, v], i) => {
      const x = 250 + i * 252
      g.fillStyle = dark ? "rgba(20,48,64,.75)" : "rgba(255,255,255,.9)"; rr(g, x, 120, 232, 118, 16); g.fill()
      g.strokeStyle = dark ? "rgba(190,225,245,.16)" : "rgba(40,80,110,.18)"; g.lineWidth = 1.5; g.stroke()
      g.fillStyle = text; g.font = '650 44px "Space Grotesk Variable", "Inter Variable", sans-serif'; g.fillText(v, x + 20, 170)
      g.globalAlpha = 0.6; g.font = '400 16px "Inter Variable", sans-serif'; g.fillText(l, x + 20, 214); g.globalAlpha = 1
    })
    const rows: [string, string, string, string][] = [
      ["Blood panel, March", "Northstar Lab", "Processed", "#35c9a1"],
      ["Cardiology prescription", "Dr. Meera S.", "Processing", css(cyan)],
      ["Chest X-ray follow-up", "Northstar Lab", closed ? "Closed" : "In review", closed ? "#35c9a1" : css(blue)],
    ]
    g.font = '500 14px "Inter Variable", sans-serif'; g.fillStyle = text; g.globalAlpha = 0.5
    g.fillText("DOCUMENT", 262, 282); g.fillText("SOURCE", 560, 282); g.fillText("STATUS", 800, 282); g.globalAlpha = 1
    rows.forEach((r, i) => {
      const y = 304 + i * 64
      const hot = i === 2
      if (hot) { g.fillStyle = css(cyan); g.globalAlpha = closed ? 0.16 : 0.08; g.fillRect(240, y, 760, 56); g.globalAlpha = 1 }
      g.strokeStyle = dark ? "rgba(190,225,245,.12)" : "rgba(40,80,110,.14)"; g.lineWidth = 1; g.beginPath(); g.moveTo(240, y + 56); g.lineTo(1000, y + 56); g.stroke()
      g.fillStyle = text; g.font = '500 19px "Inter Variable", sans-serif'; g.fillText(r[0], 262, y + 28)
      g.globalAlpha = 0.65; g.font = '400 18px "Inter Variable", sans-serif'; g.fillText(r[1], 560, y + 28); g.globalAlpha = 1
      g.fillStyle = r[3]; g.globalAlpha = 0.18; rr(g, 796, y + 14, 150, 30, 9); g.fill(); g.globalAlpha = 1
      g.beginPath(); g.arc(814, y + 29, 4.5, 0, 7); g.fill()
      g.font = '500 16px "Inter Variable", sans-serif'; g.fillText(r[2], 828, y + 30)
    })
    return mkTex(c)
  }

  /* ── ground grid + dust ── */
  const gridMat = track(new THREE.ShaderMaterial({
    vertexShader: GRID_VS, fragmentShader: GRID_FS, transparent: true, depthWrite: false,
    uniforms: { uColor: { value: ink }, uAlpha: { value: dark ? 0.2 : 0.2 } },
  }))
  const ground = new THREE.Mesh(track(new THREE.PlaneGeometry(190, 190)), gridMat)
  ground.rotation.x = -Math.PI / 2
  ground.position.y = -0.02
  scene.add(ground)

  const dustCount = small ? 260 : 520
  const dustGeo = track(new THREE.BufferGeometry())
  {
    const pos = new Float32Array(dustCount * 3), seed = new Float32Array(dustCount * 3)
    for (let i = 0; i < dustCount; i++) {
      pos.set([(Math.random() - 0.5) * 44, Math.random() * 14, 18 - Math.random() * 64], i * 3)
      seed.set([Math.random(), Math.random(), Math.random()], i * 3)
    }
    dustGeo.setAttribute("position", new THREE.BufferAttribute(pos, 3))
    dustGeo.setAttribute("aSeed", new THREE.BufferAttribute(seed, 3))
  }
  const dustMat = track(new THREE.ShaderMaterial({
    vertexShader: DUST_VS, fragmentShader: DUST_FS, transparent: true, depthWrite: false, blending: glowBlend,
    uniforms: { uTime: { value: 0 }, uScale: { value: 600 }, uColor: { value: dark ? cyan.clone().lerp(new THREE.Color("#ffffff"), 0.35) : ink }, uK: { value: dark ? 0.85 : 0.55 } },
  }))
  const dust = new THREE.Points(dustGeo, dustMat)
  dust.frustumCulled = false
  scene.add(dust)

  /* ── figure builder (patient / doctor) ── */
  const figure = (scale: number, badge: boolean) => {
    const g = new THREE.Group()
    const body = edges(new THREE.Mesh(track(new THREE.CapsuleGeometry(0.55, 1.15, 3, 10)), glassSolid), 20)
    body.position.y = 1.55
    const head = edges(new THREE.Mesh(track(new THREE.IcosahedronGeometry(0.42, 1)), glassSolid), 20)
    head.position.y = 2.95
    g.add(body, head)
    const core = makeHalo(1.6, cyan, 0.55); core.position.set(0, 1.7, 0.2)
    g.add(core)
    if (badge) {
      const a = new THREE.Mesh(track(new THREE.BoxGeometry(0.16, 0.5, 0.06)), glowSolid)
      const b = new THREE.Mesh(track(new THREE.BoxGeometry(0.5, 0.16, 0.06)), glowSolid)
      a.position.set(0, 1.75, 0.57); b.position.copy(a.position)
      g.add(a, b)
    }
    g.scale.setScalar(scale)
    return { g, core }
  }

  const platform = (w: number, d: number) => {
    const p = panel(w, 0.22, d, glass, 0.1)
    p.position.y = 0.11
    return p
  }

  /* ════════ Station A: diagnostic centre ════════ */
  const A = new THREE.Group(); A.position.set(-5.5, 0, 0)
  A.add(platform(7.4, 6.4))
  // building with a lit window grid and a cross sign
  const towers: [number, number, number, number, number][] = [[-2.3, 2.25, -1.9, 2.2, 4.5], [0.1, 1.45, -2.0, 2.2, 2.9], [2.45, 1.8, -1.9, 1.9, 3.6]]
  towers.forEach(([x, y, z, w, h]) => { const t = panel(w, h, 2.0, glass, 0.08); t.position.set(x, y + 0.2, z); A.add(t) })
  {
    const wins = track(new THREE.InstancedMesh(track(new THREE.PlaneGeometry(0.26, 0.15)), glowSolid, 40))
    const m = new THREE.Matrix4(); const col = new THREE.Color(); let n = 0
    let seed = 11; const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647)
    towers.forEach(([x, y, z, w, h]) => {
      const cols = Math.max(2, Math.floor(w / 0.7)), rows = Math.floor(h / 0.7)
      for (let r = 0; r < rows && n < 40; r++) for (let c = 0; c < cols && n < 40; c++) {
        if (rnd() < 0.3) continue
        m.setPosition(x - w / 2 + (c + 0.5) * (w / cols), y + 0.2 - h / 2 + (r + 0.65) * (h / rows), z + 1.02)
        wins.setMatrixAt(n, m)
        wins.setColorAt(n, col.copy(rnd() > 0.5 ? cyan : blue).multiplyScalar(0.5 + rnd() * 0.7))
        n++
      }
    })
    wins.count = n; wins.instanceMatrix.needsUpdate = true; if (wins.instanceColor) wins.instanceColor.needsUpdate = true
    A.add(wins)
  }
  const sign = new THREE.Group(); sign.position.set(-2.3, 5.2, -1.9)
  sign.add(new THREE.Mesh(track(new THREE.BoxGeometry(0.22, 0.8, 0.12)), glowSolid), new THREE.Mesh(track(new THREE.BoxGeometry(0.8, 0.22, 0.12)), glowSolid))
  const signHalo = makeHalo(3.4, cyan, 0.5); sign.add(signHalo)
  A.add(sign)
  // CT-style scanner: housing ring, inner light ring, sliding bed
  const scanner = new THREE.Group(); scanner.position.set(0.4, 2.0, 0.2)
  const housing = edges(new THREE.Mesh(track(new THREE.TorusGeometry(1.3, 0.5, 14, 56)), glassSolid), 30)
  const inner = new THREE.Mesh(track(new THREE.TorusGeometry(0.82, 0.035, 8, 72)), glowSolid); inner.position.z = 0.52
  const spin = new THREE.Mesh(track(new THREE.TorusGeometry(1.3, 0.55, 3, 24, Math.PI * 0.5)), glowSoft)
  scanner.add(housing, inner, spin)
  const scanDisc = new THREE.Mesh(track(new THREE.CircleGeometry(0.8, 48)), glowSoft)
  scanner.add(scanDisc)
  A.add(scanner)
  const bed = new THREE.Group()
  const bedTop = panel(1.1, 0.12, 4.4, glass, 0.05)
  const lying = edges(new THREE.Mesh(track(new THREE.CapsuleGeometry(0.26, 0.85, 3, 8)), glassSolid), 20)
  lying.rotation.x = Math.PI / 2; lying.position.set(0, 0.3, 0.1)
  bed.add(bedTop, lying); A.add(bed)

  /* ════════ Station B: patient ════════ */
  const B = new THREE.Group(); B.position.set(3.5, 0, -15)
  {
    const base = edges(new THREE.Mesh(track(new THREE.CylinderGeometry(3.5, 3.5, 0.2, 64)), glass), 40); base.position.y = 0.1
    const ring = new THREE.Mesh(track(new THREE.TorusGeometry(3.1, 0.025, 6, 96)), glowSolid); ring.rotation.x = Math.PI / 2; ring.position.y = 0.22
    B.add(base, ring)
  }
  const patient = figure(1, false); B.add(patient.g)
  const orbit = new THREE.Group(); orbit.position.y = 0; B.add(orbit)
  const cardTexA = docTexture("Blood panel", "Northstar Lab", false)
  const cardTexB = docTexture("Prescription", "Dr. Meera S.", false)
  const cardTexC = docTexture("Chest X-ray", "Northstar Lab", true)
  const slots: THREE.Mesh[] = []
  const cardGeo = track(new THREE.PlaneGeometry(0.95, 1.26))
  for (let i = 0; i < 6; i++) {
    const m = new THREE.Mesh(cardGeo, track(new THREE.MeshBasicMaterial({ map: [cardTexA, cardTexB, cardTexC][i % 3], transparent: true, side: THREE.DoubleSide })))
    const a = (i / 6) * Math.PI * 2
    m.position.set(Math.cos(a) * 2.5, 1.7 + Math.sin(i * 1.7) * 0.45, Math.sin(a) * 2.5)
    m.rotation.y = -a + Math.PI / 2
    const frame = new THREE.LineSegments(track(new THREE.EdgesGeometry(cardGeo)), lineMat); m.add(frame)
    slots.push(m); orbit.add(m)
  }
  const landSlot = slots[5]
  const reportTex = docTexture("Scan report", "CT · Chest", true)
  const reportSlotMat = landSlot.material as THREE.MeshBasicMaterial
  reportSlotMat.map = reportTex
  landSlot.visible = false
  // ECG ribbon above the patient
  const ecgN = 90
  const ecgPos = new Float32Array(ecgN * 3)
  const ecgGeo = track(new THREE.BufferGeometry()); ecgGeo.setAttribute("position", new THREE.BufferAttribute(ecgPos, 3))
  const ecg = new THREE.Line(ecgGeo, track(new THREE.LineBasicMaterial({ color: cyan, transparent: true, opacity: 0.95 })))
  ecg.position.set(0, 4.35, 0); ecg.frustumCulled = false
  B.add(ecg)
  const patientBeacon = makeHalo(5, cyan, 0.0); patientBeacon.position.set(0, 1.8, 0); B.add(patientBeacon)

  /* ════════ Station C: doctor ════════ */
  const C = new THREE.Group(); C.position.set(-2.5, 0, -30)
  C.add(platform(8.4, 5))
  const screen = panel(5.4, 3.2, 0.14, glass, 0.08); screen.position.set(1.2, 2.75, -0.6)
  const dashBefore = dashTexture(false), dashAfter = dashTexture(true)
  const dashMat = track(new THREE.MeshBasicMaterial({ map: dashBefore, toneMapped: false }))
  const dash = new THREE.Mesh(track(new THREE.PlaneGeometry(5.1, 2.99)), dashMat); dash.position.z = 0.085
  screen.add(dash)
  const stand = panel(0.3, 1.2, 0.3, glassSolid, 0.05); stand.position.set(1.2, 0.8, -0.6)
  C.add(screen, stand)
  const doctor = figure(1.08, true); doctor.g.position.set(-2.5, 0, 0.7); C.add(doctor.g)
  // closing loop: an arc that draws itself around the screen and the doctor
  const LOOP_N = 160
  const loopPts: THREE.Vector3[] = []
  for (let i = 0; i <= LOOP_N; i++) {
    const a = -Math.PI / 2 + (i / LOOP_N) * Math.PI * 2
    loopPts.push(new THREE.Vector3(Math.cos(a) * 4.5 - 0.3, 2.9 + Math.sin(a) * 3.1, 0.5))
  }
  const loopGeo = track(new THREE.BufferGeometry().setFromPoints(loopPts))
  const loopMat = track(new THREE.LineBasicMaterial({ color: cyan, transparent: true, opacity: 1 }))
  const loop = new THREE.Line(loopGeo, loopMat); loop.frustumCulled = false; loopGeo.setDrawRange(0, 0)
  const loopGlowMat = track(new THREE.LineBasicMaterial({ color: cyan, transparent: true, opacity: dark ? 0.35 : 0.25, blending: glowBlend }))
  const loopGlow = new THREE.Line(loopGeo, loopGlowMat); loopGlow.scale.setScalar(1.012); loopGlow.frustumCulled = false
  C.add(loop, loopGlow)
  const loopHead = makeHalo(1.1, cyan, 0.9); loopHead.visible = false; C.add(loopHead)
  const badgeC = new THREE.Group(); badgeC.position.set(-0.3, 6.15, 0.5); badgeC.scale.setScalar(0)
  {
    const disc = new THREE.Mesh(track(new THREE.CircleGeometry(0.46, 40)), glowSolid)
    const tick = new THREE.Mesh(track(new THREE.TubeGeometry(new THREE.CatmullRomCurve3([new THREE.Vector3(-0.2, 0.0, 0.02), new THREE.Vector3(-0.06, -0.14, 0.02), new THREE.Vector3(0.22, 0.16, 0.02)], false, "catmullrom", 0), 12, 0.045, 6)), track(new THREE.MeshBasicMaterial({ color: bg })))
    badgeC.add(disc, tick, makeHalo(2.4, cyan, 0.6))
  }
  C.add(badgeC)

  scene.add(A, B, C)
  const stations = [A, B, C]

  /* ── relay paths (world space) ── */
  const curve1 = new THREE.CatmullRomCurve3([
    new THREE.Vector3(-5.1, 2.35, 2.2), new THREE.Vector3(-2.6, 4.0, -3.5), new THREE.Vector3(0.4, 3.5, -9.5), new THREE.Vector3(2.0, 2.9, -12.6), new THREE.Vector3(3.5, 2.6, -13.2),
  ])
  const curve2 = new THREE.CatmullRomCurve3([
    new THREE.Vector3(4.2, 2.6, -15.2), new THREE.Vector3(6.2, 3.7, -19.5), new THREE.Vector3(2.6, 4.2, -24.5), new THREE.Vector3(-0.4, 3.6, -27.6), new THREE.Vector3(-1.3, 2.9, -29.5),
  ])
  const makeRelay = (curve: THREE.CatmullRomCurve3) => {
    const mk = (r: number, alpha: number, seg = 6) => {
      const mat = track(new THREE.ShaderMaterial({
        vertexShader: TUBE_VS, fragmentShader: TUBE_FS, transparent: true, depthWrite: false, blending: glowBlend,
        uniforms: { uColor: { value: cyan }, uAlpha: { value: alpha }, uHead: { value: 0 } },
      }))
      const mesh = new THREE.Mesh(track(new THREE.TubeGeometry(curve, 120, r, seg, false)), mat)
      scene.add(mesh)
      return mat
    }
    return [mk(0.03, dark ? 0.95 : 0.9), mk(0.13, dark ? 0.22 : 0.16, 8)]
  }
  const relay1 = makeRelay(curve1), relay2 = makeRelay(curve2)

  // packets: scan report (A -> B) and share token (B -> C)
  const packet = (tex: THREE.Texture, w: number, h: number) => {
    const g = new THREE.Group()
    const m = new THREE.Mesh(track(new THREE.PlaneGeometry(w, h)), track(new THREE.MeshBasicMaterial({ map: tex, transparent: true, side: THREE.DoubleSide })))
    m.add(new THREE.LineSegments(track(new THREE.EdgesGeometry(m.geometry)), lineMat))
    g.add(m, makeHalo(w * 3.4, cyan, 0.7))
    g.visible = false
    scene.add(g)
    return { g, m }
  }
  const report = packet(reportTex, 0.95, 1.26)
  const share = packet(qrTexture(), 0.9, 0.9)
  const tmp = new THREE.Vector3(), tmp2 = new THREE.Vector3()

  /* ── camera rig: keyframes (t, position, look-at) ── */
  type K = { t: number; p: [number, number, number]; l: [number, number, number] }
  const keys: K[] = [
    { t: 0.0, p: [9.5, 6.6, 15.5], l: [-1.2, 1.6, -13] },
    { t: 2.1, p: [-0.6, 3.2, 9.4], l: [-5.2, 1.7, 0.4] },
    { t: 4.2, p: [-2.4, 2.9, 7.2], l: [-5.0, 2.0, 0.6] },
    { t: 5.7, p: [3.6, 3.9, -4.0], l: [2.2, 2.6, -11.0] },
    { t: 6.7, p: [8.4, 3.2, -8.0], l: [3.6, 2.0, -15.0] },
    { t: 8.4, p: [7.0, 2.7, -9.4], l: [3.5, 2.2, -15.2] },
    { t: 9.8, p: [4.4, 3.8, -20.0], l: [-0.8, 2.9, -29.0] },
    { t: 10.8, p: [3.2, 3.2, -21.0], l: [-1.6, 3.0, -30.0] },
    { t: 12.4, p: [2.6, 3.0, -22.6], l: [-1.8, 3.2, -30.0] },
    { t: 13.8, p: [14, 8.5, -3.0], l: [-0.6, 2.0, -17] },
  ]
  const posCurve = new THREE.CatmullRomCurve3(keys.map((k) => new THREE.Vector3(...k.p)), false, "catmullrom", 0.5)
  const lookCurve = new THREE.CatmullRomCurve3(keys.map((k) => new THREE.Vector3(...k.l)), false, "catmullrom", 0.5)
  const camParam = (T: number) => {
    if (T <= keys[0].t) return 0
    for (let i = 0; i < keys.length - 1; i++) {
      if (T <= keys[i + 1].t) return (i + smoother((T - keys[i].t) / (keys[i + 1].t - keys[i].t))) / (keys.length - 1)
    }
    return 1
  }
  const camBase = new THREE.Vector3(), camLook = new THREE.Vector3()

  /* ── resize ── */
  let aspect = 1
  const resize = () => {
    const w = host.clientWidth || window.innerWidth, h = host.clientHeight || window.innerHeight
    renderer.setSize(w, h, false)
    aspect = w / h
    camera.aspect = aspect
    camera.fov = aspect < 0.8 ? 64 : 48
    camera.setViewOffset(w, h, 0, h * (aspect < 0.8 ? 0.1 : 0.075), w, h) // nudges the picture up, clear of the captions
    camera.updateProjectionMatrix()
    dustMat.uniforms.uScale.value = h * 0.5 * pixelRatio
  }
  resize()
  const ro = new ResizeObserver(resize)
  ro.observe(host)

  /* ── pointer: eased parallax, never snapped ── */
  const target = { x: 0, y: 0 }, eased = { x: 0, y: 0 }
  const onMove = (e: PointerEvent) => {
    target.x = (e.clientX / window.innerWidth) * 2 - 1
    target.y = (e.clientY / window.innerHeight) * 2 - 1
  }
  const onTilt = (e: DeviceOrientationEvent) => {
    if (e.gamma == null || e.beta == null) return
    target.x = Math.max(-1, Math.min(1, e.gamma / 30))
    target.y = Math.max(-1, Math.min(1, (e.beta - 45) / 30))
  }
  window.addEventListener("pointermove", onMove, { passive: true })
  window.addEventListener("deviceorientation", onTilt, { passive: true })

  /* ── per-frame state ── */
  let T = 0
  let step = -1
  let handedOff = false
  let last = performance.now()
  let raf = 0
  let running = true
  let slow = 0
  let degraded = 0
  let started = false
  const wallStart = performance.now()

  const stepAt = (t: number) => (t < 1.9 ? 0 : t < 5.5 ? 1 : t < 9.4 ? 2 : 3)

  const update = (dt: number) => {
    // clock
    T = Math.min(T + dt, INTRO_DURATION)
    dustMat.uniforms.uTime.value += dt

    // camera
    const u = camParam(T)
    posCurve.getPoint(u, camBase); lookCurve.getPoint(u, camLook)
    if (aspect < 1) { tmp.copy(camBase).sub(camLook).multiplyScalar(1 + (1 - aspect) * 0.55); camBase.copy(camLook).add(tmp) } // portrait: pull back so the stage still fits
    const k = 1 - Math.exp(-dt * 2.2)
    eased.x += (target.x - eased.x) * k
    eased.y += (target.y - eased.y) * k
    camBase.x += Math.sin(T * 0.45) * 0.05; camBase.y += Math.sin(T * 0.37 + 1) * 0.04
    camera.position.copy(camBase)
    camera.lookAt(camLook)
    camera.translateX(eased.x * 1.1)
    camera.translateY(-eased.y * 0.6)
    camera.rotateY(-eased.x * 0.025)
    camera.rotateX(-eased.y * 0.015)
    tmp.set(eased.x * 3.2, -eased.y * 2.0, -4).applyMatrix4(camera.matrixWorld)
    pointer.position.copy(tmp)
    stations.forEach((s, i) => { s.rotation.y = eased.x * 0.07 * (i % 2 ? -1 : 1) })

    // A: scanner + bed + report
    const slideIn = seg(T, 2.3, 3.2) - seg(T, 3.7, 4.4)
    bed.position.set(0.4, 1.3, lerp(2.3, 0.35, slideIn))
    const scanning = smooth((slideIn - 0.9) * 10)
    spin.rotation.z = T * 3.2
    spin.visible = true
    ;(spin.material as THREE.MeshBasicMaterial).opacity = (dark ? 0.12 : 0.1) + scanning * (dark ? 0.55 : 0.4)
    scanDisc.position.z = lerp(-0.25, 0.25, 0.5 + 0.5 * Math.sin(T * 6))
    ;(scanDisc.material as THREE.MeshBasicMaterial).opacity = scanning * (dark ? 0.32 : 0.28)
    signHalo.material.opacity = 0.35 + 0.2 * Math.sin(T * 2.2)

    // relay 1 draws itself as the report travels
    const f1 = seg(T, 4.5, 6.9)
    for (const m of relay1) m.uniforms.uHead.value = f1 * 1.04
    const pop = seg(T, 3.8, 4.5)
    if (T > 3.8 && T < 7.6) {
      report.g.visible = true
      curve1.getPoint(Math.min(f1, 0.9999), tmp)
      const land = seg(T, 6.7, 7.5)
      landSlot.updateWorldMatrix(true, false)
      landSlot.getWorldPosition(tmp2)
      report.g.position.copy(tmp).lerp(tmp2, land)
      report.g.position.y += (1 - f1) * pop * 0.0 + (1 - pop) * -0.9
      report.g.quaternion.copy(camera.quaternion)
      report.g.scale.setScalar(lerp(0.01, 1, pop) * lerp(1, 0.97, land))
    } else report.g.visible = false
    landSlot.visible = T >= 7.5
    const landed = seg(T, 7.5, 8.2)
    landSlot.scale.setScalar(1 + (1 - landed) * 0.25 + Math.sin(T * 6) * 0.015 * (T > 7.5 && T < 8.6 ? 1 : 0))

    // B: orbiting records, ECG, beacon
    orbit.rotation.y = T * 0.28
    for (const c of slots) c.lookAt(camera.position)
    const hr = seg(T, 5.6, 7.0)
    for (let i = 0; i < ecgN; i++) {
      const x = (i / (ecgN - 1) - 0.5) * 3.2
      const ph = ((i / ecgN) * 3 - T * 0.9) % 1
      const p = ph < 0 ? ph + 1 : ph
      let y = 0
      if (p > 0.35 && p < 0.4) y = (p - 0.35) / 0.05 * 0.7
      else if (p >= 0.4 && p < 0.46) y = 0.7 - (p - 0.4) / 0.06 * 1.2
      else if (p >= 0.46 && p < 0.5) y = -0.5 + (p - 0.46) / 0.04 * 0.5
      ecgPos[i * 3] = x; ecgPos[i * 3 + 1] = y * 0.5 * hr; ecgPos[i * 3 + 2] = 0
    }
    ecgGeo.attributes.position.needsUpdate = true
    ecg.quaternion.copy(camera.quaternion)
    ecg.quaternion.premultiply(B.quaternion.clone().invert())
    patientBeacon.material.opacity = (0.15 + 0.45 * seg(T, 7.3, 8.0)) * (0.7 + 0.3 * Math.sin(T * 3)) * (T > 9.6 ? 1 - seg(T, 9.6, 10.6) : 1)
    patient.core.material.opacity = 0.4 + 0.25 * Math.sin(T * 2)

    // relay 2 + share token
    const f2 = seg(T, 8.6, 10.9)
    for (const m of relay2) m.uniforms.uHead.value = f2 * 1.04
    if (T > 8.2 && T < 11.6) {
      share.g.visible = true
      const emit = seg(T, 8.2, 8.9)
      curve2.getPoint(Math.min(f2, 0.9999), tmp)
      const land = seg(T, 10.8, 11.5)
      tmp2.set(-1.3, 2.75, -30.35)
      share.g.position.copy(tmp).lerp(tmp2, land)
      if (f2 < 0.01) share.g.position.lerp(tmp.set(3.5, 2.2, -15), 1 - emit)
      share.g.quaternion.copy(camera.quaternion)
      share.g.scale.setScalar(lerp(0.01, 1, emit) * lerp(1, 0.3, land))
      share.g.children[0].visible = land < 0.97
      share.g.children[1].visible = land < 0.97
    } else share.g.visible = false
    dashMat.map = T >= 11.2 ? dashAfter : dashBefore

    // C: loop closes, badge pops
    const lp = seg(T, 10.9, 12.5)
    const count = Math.floor(lp * LOOP_N)
    loopGeo.setDrawRange(0, count > 1 ? count + 1 : 0)
    if (count > 1) {
      loopHead.visible = lp < 0.999
      loopHead.position.copy(loopPts[Math.min(count, LOOP_N)])
    } else loopHead.visible = false
    const bp = smoother((T - 12.0) / 0.9)
    badgeC.scale.setScalar(bp * (1 + 0.12 * Math.sin(clamp01((T - 12.0) / 0.9) * Math.PI)))
    doctor.core.material.opacity = 0.4 + 0.3 * seg(T, 10.9, 12.4)

    // chrome
    const s = stepAt(T)
    if (s !== step) { step = s; cbRef.current.onStep(s) }
    if (progressRef.current) progressRef.current.style.transform = `scaleX(${(T / INTRO_DURATION).toFixed(4)})`
    if (!handedOff && T >= HANDOFF_AT) { handedOff = true; cbRef.current.onHandoff() }
  }

  const frame = () => {
    raf = requestAnimationFrame(frame)
    if (lost) return
    const now = performance.now()
    const raw = (now - last) / 1000
    last = now
    const dt = Math.min(raw, 0.05)
    update(dt)
    renderer.render(scene, camera)
    if (!started) { started = true; host.dataset.ready = "true" }
    // weak device: never let the film hold the login page for more than ~22s of wall-clock time
    if (!handedOff && now - wallStart > 22000) { handedOff = true; cbRef.current.onHandoff() }

    // adaptive quality: step the pixel ratio down if frames keep running long
    slow = raw > 0.034 ? slow + 1 : Math.max(0, slow - 1)
    if (slow > 40 && degraded < 2 && pixelRatio > 1) {
      degraded++; slow = 0
      pixelRatio = Math.max(1, pixelRatio * 0.78)
      renderer.setPixelRatio(pixelRatio)
      resize()
    }
  }
  const start = () => { if (!running) { running = true; last = performance.now(); raf = requestAnimationFrame(frame) } }
  const stop = () => { running = false; cancelAnimationFrame(raf) }
  const onVis = () => (document.hidden ? stop() : start())
  document.addEventListener("visibilitychange", onVis)
  update(0)
  raf = requestAnimationFrame(frame)

  // dev-only hook: jump to a moment in the film (visual QA); stripped from production builds
  if (process.env.NODE_ENV !== "production") (host as HTMLDivElement & { __seek?: (t: number) => void }).__seek = (t: number) => { T = Math.max(0, t - 0.0001); update(0.0001); renderer.render(scene, camera) }

  return () => {
    stop()
    document.removeEventListener("visibilitychange", onVis)
    window.removeEventListener("pointermove", onMove)
    window.removeEventListener("deviceorientation", onTilt)
    renderer.domElement.removeEventListener("webglcontextlost", onLost)
    ro.disconnect()
    scene.traverse((o) => {
      const m = o as THREE.Mesh
      if (m.geometry) m.geometry.dispose?.()
    })
    disposables.forEach((d) => d.dispose())
    renderer.dispose()
    renderer.domElement.remove()
  }
}
