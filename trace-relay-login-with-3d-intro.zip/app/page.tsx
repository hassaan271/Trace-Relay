import { TraceLogin } from "@/components/trace-login"

export default function Home() {
  return <TraceLogin />
}
