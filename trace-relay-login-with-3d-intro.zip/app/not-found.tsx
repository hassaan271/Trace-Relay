import Link from "next/link"

export default function NotFound() {
  return (
    <main className="trace-page flex items-center justify-center px-6">
      <section className="login-card text-center">
        <p className="workspace-eyebrow justify-center"><span aria-hidden="true" /> Trace Relay</p>
        <h1 className="mt-4 text-2xl font-semibold">Page not found</h1>
        <p className="mt-3 text-sm text-muted-foreground">The page you requested does not exist.</p>
        <Link className="mt-6 inline-flex h-11 items-center rounded-lg bg-primary px-5 text-sm font-semibold text-primary-foreground" href="/">
          Return home
        </Link>
      </section>
    </main>
  )
}
